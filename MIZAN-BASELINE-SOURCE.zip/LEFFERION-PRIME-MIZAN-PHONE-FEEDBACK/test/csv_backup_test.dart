import 'package:flutter_test/flutter_test.dart';
import 'package:lefferion_prime_mizan/services/csv_backup_service.dart';

import 'test_support.dart';

void main() {
  test('CSV dışa ve içe aktarma tam state ilişkisini korur', () {
    const service = CsvBackupService();
    final state = comprehensiveState();
    final csv = service.exportState(state);
    final restored = service.importState(csv);

    expect(restored.toJson(), state.toJson());
    expect(csv, contains('bank_debt'));
    expect(csv, contains('personal_corporate_debt'));
    expect(csv, contains('subscription'));
    expect(csv, contains('rent_installment'));
    expect(csv, contains('expense'));
  });

  test('geçersiz CSV mevcut state olarak kabul edilmez', () {
    const service = CsvBackupService();
    expect(() => service.importState('a,b,c\n1,2,3'), throwsFormatException);
  });
}
