import 'package:flutter_test/flutter_test.dart';
import 'package:lefferion_prime_mizan/models/mizan_models.dart';
import 'package:lefferion_prime_mizan/services/reminder_engine.dart';

import 'test_support.dart';

void main() {
  test(
    'bildirim saatleri cihaz yerel takviminde 09.00 ve 18.00 olarak kurulur',
    () {
      final now = DateTime(2026, 7, 19, 8, 15);
      final state = comprehensiveState(reference: now);
      final plan = const ReminderPlanBuilder().build(state: state, now: now);
      final paymentReminders = plan
          .where((item) => item.kind == ReminderKind.payment)
          .toList(growable: false);

      expect(paymentReminders, isNotEmpty);
      expect(
        paymentReminders.every(
          (item) => item.scheduledAt.hour == 9 || item.scheduledAt.hour == 18,
        ),
        isTrue,
      );
      expect(
        paymentReminders.every((item) => item.scheduledAt.minute == 0),
        isTrue,
      );
      expect(
        paymentReminders.every((item) => item.scheduledAt.isAfter(now)),
        isTrue,
      );
    },
  );

  test('hatırlatma planı state veya ödeme geçmişini değiştirmez', () {
    final now = DateTime(2026, 7, 19, 8);
    final state = comprehensiveState(reference: now);
    final before = state.toJson();
    final beforePaymentCount = paymentCount(state);

    const ReminderPlanBuilder().build(state: state, now: now);

    expect(state.toJson(), before);
    expect(paymentCount(state), beforePaymentCount);
  });

  test('bütün açık kayıt türleri için benzersiz bildirim kimliği oluşur', () {
    final now = DateTime(2026, 7, 19, 8);
    final plan = const ReminderPlanBuilder().build(
      state: comprehensiveState(reference: now),
      now: now,
    );
    final paymentReminders = plan
        .where((item) => item.kind == ReminderKind.payment)
        .toList(growable: false);
    final ids = paymentReminders.map((item) => item.id).toSet();
    final sourceIds = paymentReminders.map((item) => item.sourceId).toSet();

    expect(ids.length, paymentReminders.length);
    expect(
      sourceIds,
      containsAll(<String>[
        'bank-debt-1',
        'personal-debt-1',
        'bill-1',
        'subscription-1',
        'rent-1',
      ]),
    );
  });

  test('tamamlanan veya arşivlenen kayıt için bildirim oluşmaz', () {
    final now = DateTime(2026, 7, 19, 8);
    final state = MizanState(
      people: [
        PersonAccount(
          id: 'p',
          name: 'Kişi',
          bills: [
            BillEntry(
              id: 'paid',
              kind: BillKind.water,
              institutionName: 'Kurum',
              amount: 100,
              dueDate: now.add(const Duration(days: 2)),
              payments: [
                PaymentRecord(id: 'payment', amount: 100, paidAt: now),
              ],
            ),
            BillEntry(
              id: 'archived',
              kind: BillKind.phone,
              institutionName: 'Kurum',
              amount: 100,
              dueDate: now.add(const Duration(days: 2)),
              isArchived: true,
            ),
          ],
        ),
      ],
      expenseCategories: const [],
      expenses: const [],
      notificationSlots: const [],
    );
    final plan = const ReminderPlanBuilder().build(state: state, now: now);
    expect(plan, isEmpty);
  });
}
