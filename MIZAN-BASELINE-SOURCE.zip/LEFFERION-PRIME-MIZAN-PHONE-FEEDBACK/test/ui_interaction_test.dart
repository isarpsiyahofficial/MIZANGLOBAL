import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:lefferion_prime_mizan/controllers/mizan_controller.dart';
import 'package:lefferion_prime_mizan/main.dart';
import 'package:lefferion_prime_mizan/models/mizan_models.dart';

import 'test_support.dart';

Future<MizanController> _pump(
  WidgetTester tester,
  MizanState state, {
  Size size = const Size(412, 915),
}) async {
  tester.view.physicalSize = size;
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);
  final controller = MizanController(
    MemoryStore(state),
    scheduler: SpyScheduler(),
  );
  await controller.load();
  await tester.pumpWidget(MizanApp(controller: controller));
  await tester.pumpAndSettle();
  expect(tester.takeException(), isNull);
  return controller;
}

Future<void> _tapNavigation(WidgetTester tester, IconData icon) async {
  final navigation = find.byType(NavigationBar);
  final rail = find.byType(NavigationRail);
  final root = navigation.evaluate().isNotEmpty ? navigation : rail;
  final target = find.descendant(of: root, matching: find.byIcon(icon));
  expect(target, findsOneWidget);
  await tester.tap(target);
  await tester.pumpAndSettle();
}

Future<void> _scrollTap(WidgetTester tester, String text) async {
  final target = find.text(text);
  await tester.scrollUntilVisible(
    target,
    220,
    scrollable: find.byType(Scrollable).first,
  );
  await tester.pumpAndSettle();
  await tester.tap(target);
  await tester.pumpAndSettle();
}

void main() {
  testWidgets('Kalan toplam borç kartı bölüm detaylarını açar', (tester) async {
    await _pump(tester, comprehensiveState(reference: DateTime.now()));
    await tester.tap(find.text('Kalan toplam borç'));
    await tester.pumpAndSettle();

    expect(find.text('Kalan toplam borç detayı'), findsOneWidget);
    expect(find.text('Banka borçları'), findsOneWidget);
    expect(find.text('Kişisel ve kurumsal borçlar'), findsOneWidget);
    expect(find.text('Faturalar'), findsOneWidget);
    expect(find.text('Abonelikler'), findsOneWidget);
    expect(find.text('Kira ve taksitler'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Kritik ödemeye dokununca doğru kayıt ayrıntısı açılır', (
    tester,
  ) async {
    await _pump(tester, comprehensiveState(reference: DateTime.now()));
    await _scrollTap(tester, 'Kart borcu');

    expect(find.text('Kalan borç'), findsOneWidget);
    final paymentHistory = find.text('Ödeme geçmişi');
    await tester.scrollUntilVisible(
      paymentHistory,
      220,
      scrollable: find.byType(Scrollable).last,
    );
    expect(paymentHistory, findsOneWidget);
    expect(find.text('Ödeme ekle'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Kayıtlar ekranı kişiyi ve beş grubu açık biçimde ayırır', (
    tester,
  ) async {
    await _pump(tester, comprehensiveState(reference: DateTime.now()));
    await _tapNavigation(tester, Icons.people_alt_outlined);

    expect(find.text('Kayıt sahibi'), findsOneWidget);
    for (final title in const [
      'Banka Borçları',
      'Kişisel ve Kurumsal Borçlar',
      'Faturalar',
      'Abonelikler',
      'Kira ve Taksitler',
    ]) {
      final target = find.text(title);
      await tester.scrollUntilVisible(
        target,
        220,
        scrollable: find.byType(Scrollable).first,
      );
      expect(target, findsOneWidget);
    }
    expect(tester.takeException(), isNull);
  });

  testWidgets('Ayarlar ekranında tehlikeli sıfırlama ve pil menüsü yoktur', (
    tester,
  ) async {
    await _pump(tester, MizanState.empty());
    await _tapNavigation(tester, Icons.settings_outlined);

    expect(find.text('Pil optimizasyonu'), findsNothing);
    expect(find.textContaining('örnek kayıtlarla sıfırla'), findsNothing);
    final exportButton = find.text('CSV yedeğini dışa aktar');
    await tester.scrollUntilVisible(
      exportButton,
      220,
      scrollable: find.byType(Scrollable).first,
    );
    expect(exportButton, findsOneWidget);
    expect(find.text('CSV yedeğini geri yükle'), findsOneWidget);
    expect(find.text('Anlık yerel kayıt'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Giderler ve Raporlar ilk bakışta sade başlıklarla açılır', (
    tester,
  ) async {
    await _pump(tester, comprehensiveState(reference: DateTime.now()));
    await _tapNavigation(tester, Icons.shopping_bag_outlined);
    expect(find.text('Giderler'), findsWidgets);
    expect(find.text('Bugün'), findsOneWidget);
    expect(find.text('Bu ay'), findsWidgets);
    expect(find.text('Tarih aralığı'), findsOneWidget);
    expect(find.byType(ExpansionTile), findsNothing);

    await _tapNavigation(tester, Icons.bar_chart_outlined);
    expect(find.text('Rapor kapsamı'), findsOneWidget);
    final combinedReport = find.text(
      'Bu ay gerçekleşen toplam ödeme-gider raporu',
    );
    await tester.scrollUntilVisible(
      combinedReport,
      220,
      scrollable: find.byType(Scrollable).first,
    );
    expect(combinedReport, findsOneWidget);
    final actualPayments = find.text('Bu ay yapılan ödemeler');
    await tester.scrollUntilVisible(
      actualPayments,
      220,
      scrollable: find.byType(Scrollable).first,
    );
    expect(actualPayments, findsOneWidget);
    expect(find.byType(ExpansionTile), findsNothing);
    final distribution = find.text('Kalan ödeme yükünün dağılımı');
    await tester.scrollUntilVisible(
      distribution,
      220,
      scrollable: find.byType(Scrollable).first,
    );
    expect(distribution, findsOneWidget);
    final expenseDistribution = find.text('Gider dağılımı');
    await tester.scrollUntilVisible(
      expenseDistribution,
      220,
      scrollable: find.byType(Scrollable).first,
    );
    expect(expenseDistribution, findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('yeni kişisel borç ve abonelik formları doğru alanları açar', (
    tester,
  ) async {
    await _pump(
      tester,
      MizanState(
        people: const [PersonAccount(id: 'p', name: 'Kişi')],
        expenseCategories: const [],
        expenses: const [],
        notificationSlots: defaultNotificationSlots,
      ),
      size: const Size(500, 1200),
    );
    await _tapNavigation(tester, Icons.people_alt_outlined);

    await _scrollTap(tester, 'Kişisel ve Kurumsal Borçlar');
    await tester.tap(find.text('Kişisel / kurumsal borç ekle'));
    await tester.pumpAndSettle();
    expect(find.text('Alacaklı türü'), findsOneWidget);
    expect(find.text('Borç başlığı'), findsOneWidget);
    expect(find.text('Son ödeme tarihi'), findsOneWidget);
    await tester.tap(find.text('Vazgeç'));
    await tester.pumpAndSettle();

    await _scrollTap(tester, 'Abonelikler');
    await tester.tap(find.text('Abonelik ekle'));
    await tester.pumpAndSettle();
    expect(find.text('Abonelik türü'), findsOneWidget);
    expect(find.text('Sıradaki ödeme tarihi'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('kişi işlemleri kişi detayları alanında toplanır', (
    tester,
  ) async {
    await _pump(tester, comprehensiveState(reference: DateTime.now()));
    await _tapNavigation(tester, Icons.people_alt_outlined);

    expect(find.text('Kişiyi düzenle'), findsNothing);
    expect(find.text('Kişiyi sil'), findsNothing);
    await tester.tap(find.text('Kişi detaylarını aç'));
    await tester.pumpAndSettle();

    expect(find.text('Kişi detayları'), findsOneWidget);
    final detailScrollable = find.byType(Scrollable).last;
    final bankRecord = find.text('Kart borcu');
    await tester.scrollUntilVisible(
      bankRecord,
      220,
      scrollable: detailScrollable,
    );
    expect(bankRecord, findsOneWidget);
    final personalRecord = find.text('Senet ödemesi');
    await tester.scrollUntilVisible(
      personalRecord,
      220,
      scrollable: detailScrollable,
    );
    expect(personalRecord, findsOneWidget);
    final editPerson = find.text('Kişiyi düzenle');
    await tester.scrollUntilVisible(
      editPerson,
      220,
      scrollable: detailScrollable,
    );
    expect(editPerson, findsOneWidget);
    final deletePerson = find.text('Kişiyi sil');
    await tester.scrollUntilVisible(
      deletePerson,
      120,
      scrollable: detailScrollable,
    );
    expect(deletePerson, findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('banka borcu formu tarih yöntemi seçtirir', (tester) async {
    final state = comprehensiveState(reference: DateTime.now());
    final controller = await _pump(tester, state, size: const Size(500, 1200));
    await _tapNavigation(tester, Icons.people_alt_outlined);
    final bankTitle = find.text('Kullanıcının bankası');
    await tester.scrollUntilVisible(
      bankTitle,
      220,
      scrollable: find.byType(Scrollable).first,
    );
    expect(bankTitle, findsOneWidget);
    final bankActions = find.byTooltip('Banka grubu işlemleri');
    await tester.ensureVisible(bankActions);
    await tester.tap(bankActions);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Borç ekle'));
    await tester.pumpAndSettle();
    expect(find.text('Borç ürünü ekle'), findsOneWidget);

    expect(find.text('Ödeme tarihi yöntemi'), findsOneWidget);
    expect(find.text('Son ödeme tarihi'), findsWidgets);
    await tester.tap(find.text('Son ödeme tarihi').first);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Her ayın belirli günü').last);
    await tester.pumpAndSettle();
    expect(find.text('Her ayın kaçıncı günü?'), findsOneWidget);
    expect(controller.state.people.single.banks.single.products, hasLength(1));
    expect(tester.takeException(), isNull);
  });
}
