from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def require(condition: bool, message: str, failures: list[str]) -> None:
    if not condition:
        failures.append(message)


def require_all(text: str, tokens: list[str], label: str, failures: list[str]) -> None:
    missing = [token for token in tokens if token not in text]
    require(not missing, f"{label}: {', '.join(missing)}", failures)


def main() -> int:
    failures: list[str] = []
    pubspec = read("pubspec.yaml")
    models = read("lib/models/mizan_models.dart")
    controller = read("lib/controllers/mizan_controller.dart")
    people = read("lib/screens/people_screen.dart")
    forms = read("lib/screens/record_form_dialogs.dart")
    expenses = read("lib/screens/expenses_screen.dart")
    dashboard = read("lib/screens/dashboard_screen.dart")
    reports = read("lib/screens/reports_screen.dart")
    settings = read("lib/screens/settings_screen.dart")
    store = read("lib/services/local_store.dart")
    csv_backup = read("lib/services/csv_backup_service.dart")
    notifications = read("lib/services/notification_service.dart")
    reminders = read("lib/services/reminder_engine.dart")
    scaffold = read("lib/widgets/responsive_scaffold.dart")
    workflow = read(".github/workflows/android-release.yml")
    android_config = read("tools/configure_android.py")
    requirements = read("docs/REQUIREMENTS_250_PLUS.md")
    all_tests = "\n".join(
        path.read_text(encoding="utf-8")
        for path in (ROOT / "test").glob("*_test.dart")
    )

    require_all(
        workflow,
        [
            "flutter create . --platforms=android",
            "tools/configure_android.py",
            "flutter analyze --fatal-warnings",
            "flutter test --reporter expanded",
            "flutter build apk --release",
            "actions/upload-artifact@v4",
        ],
        "CI/build adımları eksik",
        failures,
    )
    require_all(
        android_config,
        [
            "LEFFERION PRIME - MIZAN",
            "POST_NOTIFICATIONS",
            "RECEIVE_BOOT_COMPLETED",
            "SCHEDULE_EXACT_ALARM",
            "ScheduledNotificationBootReceiver",
        ],
        "Android yapılandırması eksik",
        failures,
    )
    require("assets/brand/lefferion-prime-logo.png" in pubspec, "Logo asset yolu eksik", failures)
    require("flutter_local_notifications" in pubspec, "Yerel bildirim paketi eksik", failures)
    require("path_provider" in pubspec, "Dosya tabanlı yerel kayıt paketi eksik", failures)
    require("file_picker" in pubspec and "csv:" in pubspec, "CSV yedek paketleri eksik", failures)
    require("android_intent_plus" not in pubspec, "Gereksiz pil ayarı bağımlılığı kaldırılmadı", failures)

    require_all(
        models,
        [
            "class PaymentRecord",
            "class DebtProduct",
            "class PersonalDebtEntry",
            "class SubscriptionEntry",
            "class BillEntry",
            "class RentEntry",
            "class DueScheduleItem",
            "enum CreditorType", "enum DebtDueMode",
            "enum PaymentFrequency",
            "personalDebts",
            "subscriptions",
            "recordReferencesAt",
            "bankDebtTotal", "actualPaymentTotals", "dueAmountAt",
            "personalCorporateDebtTotal",
            "subscriptionTotal",
            "factory MizanState.empty()",
        ],
        "Genişletilmiş veri modeli eksik",
        failures,
    )
    require_all(
        controller,
        [
            "addPerson(", "updatePerson(", "deletePerson(",
            "addBankGroup(", "addDebtProduct(",
            "addPersonalDebt(", "updatePersonalDebt(", "deletePersonalDebt(",
            "addBill(", "addSubscription(", "updateSubscription(",
            "addRent(", "addPayment(", "updatePayment(", "deletePayment(",
            "addNote(", "deleteNote(",
            "addExpenseCategory(", "deleteExpenseCategory(",
            "addExpense(", "updateExpense(", "deleteExpense(",
            "ONAYLIYORUM", "restoreFromBackup(",
            "requestNotificationPermissions(", "rescheduleNotifications(",
            "allowStorageRecovery", "_storageReady", "_validateState(",
        ],
        "Controller akışları eksik",
        failures,
    )
    require_all(
        store,
        [
            "mizan_state.json",
            "mizan_state.backup.json",
            "mizan_state.tmp.json",
            "writeAsString(encoded, flush: true)",
            "_tryRead(temporary)",
            "_tryRead(primary)",
            "StoreLoadSource.backup",
            "MizanState.empty()",
        ],
        "Yerel atomik kayıt/yedek kurtarma eksik",
        failures,
    )
    require_all(
        csv_backup,
        [
            "MIZAN_CSV_BACKUP",
            "personal_corporate_debt",
            "subscription",
            "rent_installment",
            "snapshot",
            "MizanState.fromJson",
        ],
        "CSV yedekleme eksik",
        failures,
    )
    require_all(
        notifications,
        [
            "requestNotificationsPermission",
            "requestExactAlarmsPermission",
            "canScheduleExactNotifications",
            "zonedSchedule",
            "cancelAllPendingNotifications",
            "TZDateTime",
        ],
        "Android bildirim katmanı eksik",
        failures,
    )
    require("openBatteryOptimizationSettings" not in notifications, "Pil optimizasyonu yönlendirmesi kaldırılmadı", failures)
    require_all(
        reminders,
        [
            "subtract(const Duration(days: 5))",
            "add(const Duration(days: 5))",
            "for (final hour in const [9, 18])",
            "record.type.name",
            "stableNotificationId",
            "repeatsDaily: true",
        ],
        "Bildirim planı eksik",
        failures,
    )

    require_all(
        forms,
        [
            "showPersonForm", "showBankForm", "showDebtForm",
            "showPersonalDebtForm", "showBillForm", "showSubscriptionForm",
            "showRentForm", "showPaymentForm", "Alacaklı türü",
            "Çek numarası", "Senet numarası", "Sıradaki ödeme tarihi", "Ödeme tarihi yöntemi", "Her ayın kaçıncı günü?",
        ],
        "Form akışları eksik",
        failures,
    )
    require_all(
        people,
        [
            "Kayıt sahibi", "Kişi detayları", "Kişi detaylarını aç", "Banka Borçları", "Kişisel ve Kurumsal Borçlar",
            "Faturalar", "Abonelikler", "Kira ve Taksitler",
            "showRecordDetails", "Ödeme geçmişi", "RecordNotesPanel",
        ],
        "Kayıtlar ekranı eksik",
        failures,
    )
    require_all(expenses, ["Bugün", "Bu ay", "Tarih aralığı", "ONAYLIYORUM", "updateExpense", "deleteExpense"], "Gider ekranı eksik", failures)
    require("ExpansionTile(" not in expenses, "Gider ekranındaki gri blok riski kaldırılmadı", failures)
    require_all(dashboard, ["Kalan toplam borç detayı", "Kritik ödemeler", "showRecordDetails", "Önümüzdeki 7 gün"], "Ana sayfa detayları eksik", failures)
    require_all(reports, ["Rapor kapsamı", "Gerçekleşen ödemeler", "Bu ay yapılan ödemeler", "Bu ay gerçekleşen toplam ödeme-gider raporu", "Kalan ödeme yükünün dağılımı", "Gider dağılımı"], "Sade rapor ekranı eksik", failures)
    require("ExpansionTile(" not in reports, "Rapor ekranındaki gri blok riski kaldırılmadı", failures)
    require_all(settings, ["Bildirim iznini yeniden iste", "CSV yedeğini dışa aktar", "CSV yedeğini geri yükle", "Anlık yerel kayıt"], "Ayarlar/yedek ekranı eksik", failures)
    require("Pil optimizasyonu" not in settings, "Pil optimizasyonu butonu kaldırılmadı", failures)
    require("örnek kayıtlarla sıfırla" not in settings.lower(), "Tehlikeli örnek sıfırlama alanı kaldırılmadı", failures)
    require_all(scaffold, ["NavigationRail", "NavigationBar", "SafeArea", "LayoutBuilder"], "Responsive gezinme eksik", failures)

    require_all(
        all_tests,
        [
            "MizanState.empty()", "paymentCount", "StoreLoadSource.backup",
            "ReminderPlanBuilder", "CSV", "physicalSize",
            "textScaleFactorTestValue", "ONAYLIYORUM",
            "kendi kendine ödeme", "Kalan toplam borç", "Kişi detayları", "Her ayın belirli günü", "sıradaki ödeme tutarını",
        ],
        "Kritik otomatik test kapsamı eksik",
        failures,
    )

    numbered = re.findall(r"^\d{3}\.", requirements, flags=re.MULTILINE)
    require(len(numbered) >= 250, f"Ana gereksinim sayısı 250 altında: {len(numbered)}", failures)

    if failures:
        print("Mizan yapısal doğrulaması başarısız:")
        for failure in failures:
            print(f"- {failure}")
        return 1

    print(
        f"Mizan yapısal doğrulaması geçti; {len(numbered)} ana gereksinim takip ediliyor. "
        "Davranış, responsive, CSV ve bildirim değişmezlik testleri ayrıca çalıştırılmalıdır."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
