import 'package:flutter/foundation.dart';

import '../core/formatters.dart';
import '../models/mizan_models.dart';
import '../services/local_store.dart';
import '../services/notification_service.dart';

class MizanController extends ChangeNotifier {
  MizanController(
    this._store, {
    this._scheduler = const NoopReminderScheduler(),
  });

  final MizanStore _store;
  final ReminderScheduler _scheduler;

  MizanState _state = MizanState.empty();
  bool _isReady = false;
  bool _isBusy = false;
  bool _storageReady = false;
  String? _lastError;
  String? _loadMessage;
  NotificationHealth _notificationHealth = const NotificationHealth();

  MizanState get state => _state;
  bool get isReady => _isReady;
  bool get isBusy => _isBusy;
  bool get storageReady => _storageReady;
  String? get lastError => _lastError;
  String? get loadMessage => _loadMessage;
  NotificationHealth get notificationHealth => _notificationHealth;

  Future<void> load() async {
    _isBusy = true;
    notifyListeners();

    String? notificationWarning;
    try {
      await _scheduler.initialize();
      _notificationHealth = await _scheduler.requestPermissions();
    } on Object catch (error) {
      notificationWarning =
          'Bildirim izni veya zamanlama servisi açılamadı: ${_friendlyError(error)}';
    }

    try {
      final result = await _store.load();
      _state = result.state;
      _storageReady = true;
      _loadMessage = result.message;
      _lastError = notificationWarning;

      try {
        await _scheduler.reschedule(_state);
        _notificationHealth = await _scheduler.health();
      } on Object catch (error) {
        _lastError =
            'Kayıtlar açıldı ancak bildirimler planlanamadı: ${_friendlyError(error)}';
      }
    } on Object catch (error) {
      _storageReady = false;
      _state = MizanState.empty();
      _lastError =
          '${_friendlyError(error)} Mevcut kayıt dosyaları korunuyor; CSV yedeği geri yüklenmeden yeni kayıt yazılmayacak.';
    } finally {
      _isBusy = false;
      _isReady = true;
      notifyListeners();
    }
  }

  Future<void> _commit(
    MizanState next, {
    bool reschedule = true,
    bool allowStorageRecovery = false,
  }) async {
    if (!_storageReady && !allowStorageRecovery) {
      throw StateError(
        'Yerel kayıt alanı güvenli biçimde açılamadı. Mevcut dosyaları korumak için yeni veri yazımı durduruldu.',
      );
    }
    _isBusy = true;
    _lastError = null;
    notifyListeners();
    try {
      _validateState(next);
      await _store.save(next);
      _state = next;
      _storageReady = true;
      if (reschedule) {
        try {
          await _scheduler.reschedule(next);
          _notificationHealth = await _scheduler.health();
        } on Object catch (error) {
          _lastError =
              'Kayıt yapıldı ancak bildirimler yenilenemedi: ${_friendlyError(error)}';
        }
      }
    } on Object catch (error) {
      _lastError = _friendlyError(error);
      rethrow;
    } finally {
      _isBusy = false;
      notifyListeners();
    }
  }

  void clearMessages() {
    _lastError = null;
    _loadMessage = null;
    notifyListeners();
  }

  Future<void> addPerson(String name) async {
    final clean = _requiredText(name, 'Kişi adı', 80);
    await _commit(
      _state.copyWith(
        people: [
          ..._state.people,
          PersonAccount(id: newId('person'), name: clean),
        ],
      ),
    );
  }

  Future<void> updatePerson({
    required String personId,
    required String name,
  }) async {
    final clean = _requiredText(name, 'Kişi adı', 80);
    _person(personId);
    await _commit(
      _state.copyWith(
        people: _state.people
            .map(
              (person) =>
                  person.id == personId ? person.copyWith(name: clean) : person,
            )
            .toList(growable: false),
      ),
    );
  }

  Future<void> deletePerson(String personId) async {
    _person(personId);
    await _commit(
      _state.copyWith(
        people: _state.people.where((person) => person.id != personId).toList(),
      ),
    );
  }

  Future<void> addBankGroup({
    required String personId,
    required String userWrittenName,
  }) async {
    final clean = _requiredText(userWrittenName, 'Banka adı', 100);
    final person = _person(personId);
    _ensureUniqueBankName(person, clean);
    await _commit(
      _replacePerson(
        person.copyWith(
          banks: [
            ...person.banks,
            BankGroup(id: newId('bank'), userWrittenName: clean),
          ],
        ),
      ),
    );
  }

  Future<void> updateBankGroup({
    required String personId,
    required String bankId,
    required String userWrittenName,
  }) async {
    final clean = _requiredText(userWrittenName, 'Banka adı', 100);
    final person = _person(personId);
    _bank(person, bankId);
    _ensureUniqueBankName(person, clean, excludingId: bankId);
    await _commit(
      _replacePerson(
        person.copyWith(
          banks: person.banks
              .map(
                (bank) => bank.id == bankId
                    ? bank.copyWith(userWrittenName: clean)
                    : bank,
              )
              .toList(growable: false),
        ),
      ),
    );
  }

  Future<void> deleteBankGroup({
    required String personId,
    required String bankId,
  }) async {
    final person = _person(personId);
    _bank(person, bankId);
    await _commit(
      _replacePerson(
        person.copyWith(
          banks: person.banks.where((bank) => bank.id != bankId).toList(),
        ),
      ),
    );
  }

  Future<void> addDebtProduct({
    required String personId,
    required String bankId,
    required DebtKind kind,
    required String title,
    required double totalAmount,
    required double monthlyAmount,
    required DateTime dueDate,
    DebtDueMode dueMode = DebtDueMode.fixedDate,
    int? dueDayOfMonth,
    String customKindName = '',
    int? installmentCount,
    int? currentInstallment,
    double? limit,
    double? usedLimit,
    String description = '',
  }) async {
    final person = _person(personId);
    final bank = _bank(person, bankId);
    final debt = _buildDebt(
      id: newId('debt'),
      kind: kind,
      title: title,
      totalAmount: totalAmount,
      monthlyAmount: monthlyAmount,
      dueDate: dueDate,
      dueMode: dueMode,
      dueDayOfMonth: dueDayOfMonth,
      customKindName: customKindName,
      installmentCount: installmentCount,
      currentInstallment: currentInstallment,
      limit: limit,
      usedLimit: usedLimit,
      description: description,
    );
    await _commit(
      _replaceBank(person, bank.copyWith(products: [...bank.products, debt])),
    );
  }

  Future<void> updateDebtProduct({
    required String personId,
    required String bankId,
    required String debtId,
    required DebtKind kind,
    required String title,
    required double totalAmount,
    required double monthlyAmount,
    required DateTime dueDate,
    DebtDueMode dueMode = DebtDueMode.fixedDate,
    int? dueDayOfMonth,
    String customKindName = '',
    int? installmentCount,
    int? currentInstallment,
    double? limit,
    double? usedLimit,
    String description = '',
  }) async {
    final person = _person(personId);
    final bank = _bank(person, bankId);
    final existing = _debt(bank, debtId);
    final replacement = _buildDebt(
      id: existing.id,
      kind: kind,
      title: title,
      totalAmount: totalAmount,
      monthlyAmount: monthlyAmount,
      dueDate: dueDate,
      dueMode: dueMode,
      dueDayOfMonth: dueDayOfMonth,
      customKindName: customKindName,
      installmentCount: installmentCount,
      currentInstallment: currentInstallment,
      limit: limit,
      usedLimit: usedLimit,
      description: description,
      isArchived: existing.isArchived,
      payments: existing.payments,
      notes: existing.notes,
    );
    if (replacement.totalAmount < replacement.paidAmount) {
      throw ArgumentError(
        'Toplam borç, daha önce ödenen tutardan düşük olamaz.',
      );
    }
    await _commit(
      _replaceBank(
        person,
        bank.copyWith(
          products: bank.products
              .map((item) => item.id == debtId ? replacement : item)
              .toList(growable: false),
        ),
      ),
    );
  }

  Future<void> deleteDebtProduct({
    required String personId,
    required String bankId,
    required String debtId,
  }) async {
    final person = _person(personId);
    final bank = _bank(person, bankId);
    _debt(bank, debtId);
    await _commit(
      _replaceBank(
        person,
        bank.copyWith(
          products: bank.products.where((item) => item.id != debtId).toList(),
        ),
      ),
    );
  }

  Future<void> setDebtArchived({
    required String personId,
    required String bankId,
    required String debtId,
    required bool archived,
  }) async {
    final person = _person(personId);
    final bank = _bank(person, bankId);
    _debt(bank, debtId);
    await _commit(
      _replaceBank(
        person,
        bank.copyWith(
          products: bank.products
              .map(
                (item) => item.id == debtId
                    ? item.copyWith(isArchived: archived)
                    : item,
              )
              .toList(growable: false),
        ),
      ),
    );
  }

  Future<void> addPersonalDebt({
    required String personId,
    required CreditorType creditorType,
    required String title,
    required String creditorName,
    required double totalAmount,
    required DateTime debtDate,
    required DateTime dueDate,
    required PaymentFrequency frequency,
    bool isInstallment = false,
    int? installmentCount,
    int? currentInstallment,
    double monthlyAmount = 0,
    int? customFrequencyDays,
    String description = '',
    String chequeNumber = '',
    String issuerName = '',
    String bankInfo = '',
    String promissoryNoteNumber = '',
    int? documentCount,
    int? currentDocument,
    List<DueScheduleItem> schedule = const [],
  }) async {
    final person = _person(personId);
    final debt = _buildPersonalDebt(
      id: newId('personal-debt'),
      creditorType: creditorType,
      title: title,
      creditorName: creditorName,
      totalAmount: totalAmount,
      debtDate: debtDate,
      dueDate: dueDate,
      frequency: frequency,
      isInstallment: isInstallment,
      installmentCount: installmentCount,
      currentInstallment: currentInstallment,
      monthlyAmount: monthlyAmount,
      customFrequencyDays: customFrequencyDays,
      description: description,
      chequeNumber: chequeNumber,
      issuerName: issuerName,
      bankInfo: bankInfo,
      promissoryNoteNumber: promissoryNoteNumber,
      documentCount: documentCount,
      currentDocument: currentDocument,
      schedule: schedule,
    );
    await _commit(
      _replacePerson(
        person.copyWith(personalDebts: [...person.personalDebts, debt]),
      ),
    );
  }

  Future<void> updatePersonalDebt({
    required String personId,
    required String debtId,
    required CreditorType creditorType,
    required String title,
    required String creditorName,
    required double totalAmount,
    required DateTime debtDate,
    required DateTime dueDate,
    required PaymentFrequency frequency,
    bool isInstallment = false,
    int? installmentCount,
    int? currentInstallment,
    double monthlyAmount = 0,
    int? customFrequencyDays,
    String description = '',
    String chequeNumber = '',
    String issuerName = '',
    String bankInfo = '',
    String promissoryNoteNumber = '',
    int? documentCount,
    int? currentDocument,
    List<DueScheduleItem> schedule = const [],
  }) async {
    final person = _person(personId);
    final existing = _personalDebt(person, debtId);
    final replacement = _buildPersonalDebt(
      id: existing.id,
      creditorType: creditorType,
      title: title,
      creditorName: creditorName,
      totalAmount: totalAmount,
      debtDate: debtDate,
      dueDate: dueDate,
      frequency: frequency,
      isInstallment: isInstallment,
      installmentCount: installmentCount,
      currentInstallment: currentInstallment,
      monthlyAmount: monthlyAmount,
      customFrequencyDays: customFrequencyDays,
      description: description,
      chequeNumber: chequeNumber,
      issuerName: issuerName,
      bankInfo: bankInfo,
      promissoryNoteNumber: promissoryNoteNumber,
      documentCount: documentCount,
      currentDocument: currentDocument,
      schedule: schedule,
      isArchived: existing.isArchived,
      payments: existing.payments,
      notes: existing.notes,
    );
    if (replacement.totalAmount < replacement.paidAmount) {
      throw ArgumentError(
        'Toplam borç, daha önce ödenen tutardan düşük olamaz.',
      );
    }
    await _commit(
      _replacePerson(
        person.copyWith(
          personalDebts: person.personalDebts
              .map((item) => item.id == debtId ? replacement : item)
              .toList(growable: false),
        ),
      ),
    );
  }

  Future<void> deletePersonalDebt({
    required String personId,
    required String debtId,
  }) async {
    final person = _person(personId);
    _personalDebt(person, debtId);
    await _commit(
      _replacePerson(
        person.copyWith(
          personalDebts: person.personalDebts
              .where((item) => item.id != debtId)
              .toList(growable: false),
        ),
      ),
    );
  }

  Future<void> setPersonalDebtArchived({
    required String personId,
    required String debtId,
    required bool archived,
  }) async {
    final person = _person(personId);
    _personalDebt(person, debtId);
    await _commit(
      _replacePerson(
        person.copyWith(
          personalDebts: person.personalDebts
              .map(
                (item) => item.id == debtId
                    ? item.copyWith(isArchived: archived)
                    : item,
              )
              .toList(growable: false),
        ),
      ),
    );
  }

  Future<void> addBill({
    required String personId,
    required BillKind kind,
    required String institutionName,
    required double amount,
    required DateTime dueDate,
    String subscriberNumber = '',
    String contractNumber = '',
    String description = '',
  }) async {
    final person = _person(personId);
    final bill = _buildBill(
      id: newId('bill'),
      kind: kind,
      institutionName: institutionName,
      amount: amount,
      dueDate: dueDate,
      subscriberNumber: subscriberNumber,
      contractNumber: contractNumber,
      description: description,
    );
    await _commit(
      _replacePerson(person.copyWith(bills: [...person.bills, bill])),
    );
  }

  Future<void> updateBill({
    required String personId,
    required String billId,
    required BillKind kind,
    required String institutionName,
    required double amount,
    required DateTime dueDate,
    String subscriberNumber = '',
    String contractNumber = '',
    String description = '',
  }) async {
    final person = _person(personId);
    final existing = _bill(person, billId);
    final replacement = _buildBill(
      id: existing.id,
      kind: kind,
      institutionName: institutionName,
      amount: amount,
      dueDate: dueDate,
      subscriberNumber: subscriberNumber,
      contractNumber: contractNumber,
      description: description,
      isArchived: existing.isArchived,
      payments: existing.payments,
      notes: existing.notes,
    );
    if (replacement.amount < replacement.paidAmount) {
      throw ArgumentError(
        'Fatura tutarı, daha önce ödenen tutardan düşük olamaz.',
      );
    }
    await _commit(
      _replacePerson(
        person.copyWith(
          bills: person.bills
              .map((item) => item.id == billId ? replacement : item)
              .toList(growable: false),
        ),
      ),
    );
  }

  Future<void> deleteBill({
    required String personId,
    required String billId,
  }) async {
    final person = _person(personId);
    _bill(person, billId);
    await _commit(
      _replacePerson(
        person.copyWith(
          bills: person.bills.where((item) => item.id != billId).toList(),
        ),
      ),
    );
  }

  Future<void> setBillArchived({
    required String personId,
    required String billId,
    required bool archived,
  }) async {
    final person = _person(personId);
    _bill(person, billId);
    await _commit(
      _replacePerson(
        person.copyWith(
          bills: person.bills
              .map(
                (item) => item.id == billId
                    ? item.copyWith(isArchived: archived)
                    : item,
              )
              .toList(growable: false),
        ),
      ),
    );
  }

  Future<void> addSubscription({
    required String personId,
    required SubscriptionKind kind,
    required String title,
    required String providerName,
    required double amount,
    required PaymentFrequency frequency,
    required DateTime nextDueDate,
    String customKindName = '',
    int? customFrequencyDays,
    String subscriberNumber = '',
    String contractNumber = '',
    String description = '',
  }) async {
    final person = _person(personId);
    final subscription = _buildSubscription(
      id: newId('subscription'),
      kind: kind,
      title: title,
      providerName: providerName,
      amount: amount,
      frequency: frequency,
      nextDueDate: nextDueDate,
      customKindName: customKindName,
      customFrequencyDays: customFrequencyDays,
      subscriberNumber: subscriberNumber,
      contractNumber: contractNumber,
      description: description,
    );
    await _commit(
      _replacePerson(
        person.copyWith(subscriptions: [...person.subscriptions, subscription]),
      ),
    );
  }

  Future<void> updateSubscription({
    required String personId,
    required String subscriptionId,
    required SubscriptionKind kind,
    required String title,
    required String providerName,
    required double amount,
    required PaymentFrequency frequency,
    required DateTime nextDueDate,
    String customKindName = '',
    int? customFrequencyDays,
    String subscriberNumber = '',
    String contractNumber = '',
    String description = '',
  }) async {
    final person = _person(personId);
    final existing = _subscription(person, subscriptionId);
    final replacement = _buildSubscription(
      id: existing.id,
      kind: kind,
      title: title,
      providerName: providerName,
      amount: amount,
      frequency: frequency,
      nextDueDate: nextDueDate,
      customKindName: customKindName,
      customFrequencyDays: customFrequencyDays,
      subscriberNumber: subscriberNumber,
      contractNumber: contractNumber,
      description: description,
      isArchived: existing.isArchived,
      payments: existing.payments,
      notes: existing.notes,
    );
    await _commit(
      _replacePerson(
        person.copyWith(
          subscriptions: person.subscriptions
              .map((item) => item.id == subscriptionId ? replacement : item)
              .toList(growable: false),
        ),
      ),
    );
  }

  Future<void> deleteSubscription({
    required String personId,
    required String subscriptionId,
  }) async {
    final person = _person(personId);
    _subscription(person, subscriptionId);
    await _commit(
      _replacePerson(
        person.copyWith(
          subscriptions: person.subscriptions
              .where((item) => item.id != subscriptionId)
              .toList(growable: false),
        ),
      ),
    );
  }

  Future<void> setSubscriptionArchived({
    required String personId,
    required String subscriptionId,
    required bool archived,
  }) async {
    final person = _person(personId);
    _subscription(person, subscriptionId);
    await _commit(
      _replacePerson(
        person.copyWith(
          subscriptions: person.subscriptions
              .map(
                (item) => item.id == subscriptionId
                    ? item.copyWith(isArchived: archived)
                    : item,
              )
              .toList(growable: false),
        ),
      ),
    );
  }

  Future<void> addRent({
    required String personId,
    required String title,
    required double amount,
    required int paymentDay,
    required String receiverName,
    required DateTime dueDate,
    String iban = '',
    DateTime? contractStart,
    DateTime? contractEnd,
    DateTime? increaseDate,
    int? installmentCount,
    int? currentInstallment,
    String description = '',
  }) async {
    final person = _person(personId);
    final rent = _buildRent(
      id: newId('rent'),
      title: title,
      amount: amount,
      paymentDay: paymentDay,
      receiverName: receiverName,
      dueDate: dueDate,
      iban: iban,
      contractStart: contractStart,
      contractEnd: contractEnd,
      increaseDate: increaseDate,
      installmentCount: installmentCount,
      currentInstallment: currentInstallment,
      description: description,
    );
    await _commit(
      _replacePerson(person.copyWith(rents: [...person.rents, rent])),
    );
  }

  Future<void> updateRent({
    required String personId,
    required String rentId,
    required String title,
    required double amount,
    required int paymentDay,
    required String receiverName,
    required DateTime dueDate,
    String iban = '',
    DateTime? contractStart,
    DateTime? contractEnd,
    DateTime? increaseDate,
    int? installmentCount,
    int? currentInstallment,
    String description = '',
  }) async {
    final person = _person(personId);
    final existing = _rent(person, rentId);
    final replacement = _buildRent(
      id: existing.id,
      title: title,
      amount: amount,
      paymentDay: paymentDay,
      receiverName: receiverName,
      dueDate: dueDate,
      iban: iban,
      contractStart: contractStart,
      contractEnd: contractEnd,
      increaseDate: increaseDate,
      installmentCount: installmentCount,
      currentInstallment: currentInstallment,
      description: description,
      isArchived: existing.isArchived,
      payments: existing.payments,
      notes: existing.notes,
    );
    if (replacement.amount < replacement.paidAmount) {
      throw ArgumentError(
        'Kira/taksit tutarı, daha önce ödenen tutardan düşük olamaz.',
      );
    }
    await _commit(
      _replacePerson(
        person.copyWith(
          rents: person.rents
              .map((item) => item.id == rentId ? replacement : item)
              .toList(growable: false),
        ),
      ),
    );
  }

  Future<void> deleteRent({
    required String personId,
    required String rentId,
  }) async {
    final person = _person(personId);
    _rent(person, rentId);
    await _commit(
      _replacePerson(
        person.copyWith(
          rents: person.rents.where((item) => item.id != rentId).toList(),
        ),
      ),
    );
  }

  Future<void> setRentArchived({
    required String personId,
    required String rentId,
    required bool archived,
  }) async {
    final person = _person(personId);
    _rent(person, rentId);
    await _commit(
      _replacePerson(
        person.copyWith(
          rents: person.rents
              .map(
                (item) => item.id == rentId
                    ? item.copyWith(isArchived: archived)
                    : item,
              )
              .toList(growable: false),
        ),
      ),
    );
  }

  Future<void> addPayment({
    required String personId,
    required RecordType type,
    required String sourceId,
    required double amount,
    required DateTime paidAt,
    String note = '',
    String method = '',
  }) async {
    _positiveAmount(amount, 'Ödeme tutarı');
    final person = _person(personId);
    final appliesToDueDate = type == RecordType.subscription
        ? _subscription(person, sourceId).nextDueDate
        : null;
    final payment = PaymentRecord(
      id: newId('payment'),
      amount: amount,
      paidAt: paidAt,
      note: _optionalText(note, 'Ödeme notu', 240),
      method: _optionalText(method, 'Ödeme yöntemi', 80),
      appliesToDueDate: appliesToDueDate,
    );
    await _commit(
      _replacePerson(_personWithPayment(person, type, sourceId, payment)),
    );
  }

  Future<void> updatePayment({
    required String personId,
    required RecordType type,
    required String sourceId,
    required String paymentId,
    required double amount,
    required DateTime paidAt,
    String note = '',
    String method = '',
  }) async {
    _positiveAmount(amount, 'Ödeme tutarı');
    final person = _person(personId);
    final existingPayment = _paymentFor(person, type, sourceId, paymentId);
    final replacement = PaymentRecord(
      id: paymentId,
      amount: amount,
      paidAt: paidAt,
      note: _optionalText(note, 'Ödeme notu', 240),
      method: _optionalText(method, 'Ödeme yöntemi', 80),
      appliesToDueDate: existingPayment.appliesToDueDate,
    );
    await _commit(
      _replacePerson(
        _personWithUpdatedPayment(
          person,
          type,
          sourceId,
          paymentId,
          replacement,
        ),
      ),
    );
  }

  Future<void> deletePayment({
    required String personId,
    required RecordType type,
    required String sourceId,
    required String paymentId,
  }) async {
    final person = _person(personId);
    await _commit(
      _replacePerson(_personWithoutPayment(person, type, sourceId, paymentId)),
    );
  }

  Future<void> addNote({
    required String personId,
    required RecordType type,
    required String sourceId,
    required String text,
  }) async {
    final person = _person(personId);
    final note = RecordNote(
      id: newId('note'),
      text: _requiredText(text, 'Not', 240),
      createdAt: DateTime.now(),
    );
    await _commit(
      _replacePerson(_personWithNote(person, type, sourceId, note)),
    );
  }

  Future<void> deleteNote({
    required String personId,
    required RecordType type,
    required String sourceId,
    required String noteId,
  }) async {
    final person = _person(personId);
    await _commit(
      _replacePerson(_personWithoutNote(person, type, sourceId, noteId)),
    );
  }

  Future<void> addExpenseCategory(String name) async {
    final clean = _requiredText(name, 'Kategori adı', 60);
    _ensureUniqueCategoryName(clean);
    await _commit(
      _state.copyWith(
        expenseCategories: [
          ..._state.expenseCategories,
          ExpenseCategory(id: newId('category'), name: clean),
        ],
      ),
      reschedule: false,
    );
  }

  Future<void> renameExpenseCategory({
    required String categoryId,
    required String name,
  }) async {
    final clean = _requiredText(name, 'Kategori adı', 60);
    _category(categoryId);
    _ensureUniqueCategoryName(clean, excludingId: categoryId);
    await _commit(
      _state.copyWith(
        expenseCategories: _state.expenseCategories
            .map(
              (item) =>
                  item.id == categoryId ? item.copyWith(name: clean) : item,
            )
            .toList(growable: false),
      ),
      reschedule: false,
    );
  }

  Future<void> deleteExpenseCategory({
    required String categoryId,
    required String confirmation,
  }) async {
    _category(categoryId);
    if (confirmation.trim() != 'ONAYLIYORUM') {
      throw ArgumentError(
        'Kategori silmek için tam olarak ONAYLIYORUM yazılmalı.',
      );
    }
    await _commit(
      _state.copyWith(
        expenseCategories: _state.expenseCategories
            .where((item) => item.id != categoryId)
            .toList(),
        expenses: _state.expenses
            .where((item) => item.categoryId != categoryId)
            .toList(),
      ),
      reschedule: false,
    );
  }

  Future<void> addExpense({
    required String categoryId,
    required String name,
    required double quantity,
    required double unitPrice,
    required DateTime spentAt,
    String note = '',
  }) async {
    _category(categoryId);
    final item = _buildExpense(
      id: newId('expense'),
      categoryId: categoryId,
      name: name,
      quantity: quantity,
      unitPrice: unitPrice,
      spentAt: spentAt,
      note: note,
    );
    await _commit(
      _state.copyWith(expenses: [item, ..._state.expenses]),
      reschedule: false,
    );
  }

  Future<void> updateExpense({
    required String expenseId,
    required String categoryId,
    required String name,
    required double quantity,
    required double unitPrice,
    required DateTime spentAt,
    String note = '',
  }) async {
    _expense(expenseId);
    _category(categoryId);
    final replacement = _buildExpense(
      id: expenseId,
      categoryId: categoryId,
      name: name,
      quantity: quantity,
      unitPrice: unitPrice,
      spentAt: spentAt,
      note: note,
    );
    await _commit(
      _state.copyWith(
        expenses: _state.expenses
            .map((item) => item.id == expenseId ? replacement : item)
            .toList(growable: false),
      ),
      reschedule: false,
    );
  }

  Future<void> deleteExpense(String expenseId) async {
    _expense(expenseId);
    await _commit(
      _state.copyWith(
        expenses: _state.expenses
            .where((item) => item.id != expenseId)
            .toList(),
      ),
      reschedule: false,
    );
  }

  Future<void> restoreFromBackup(MizanState restored) async {
    await _commit(
      restored.copyWith(schemaVersion: currentSchemaVersion),
      allowStorageRecovery: true,
    );
    _loadMessage = 'CSV yedeği doğrulandı ve geri yüklendi.';
    notifyListeners();
  }

  Future<void> setNotificationsEnabled(bool enabled) async {
    await _commit(_state.copyWith(notificationsEnabled: enabled));
  }

  Future<void> updateNotificationSlot({
    required String slotId,
    int? hour,
    int? minute,
    String? message,
    bool? enabled,
  }) async {
    final index = _state.notificationSlots.indexWhere(
      (item) => item.id == slotId,
    );
    if (index < 0) {
      throw ArgumentError('Bildirim ayarı bulunamadı.');
    }
    final current = _state.notificationSlots[index];
    final cleanMessage = message == null
        ? current.message
        : _requiredText(message, 'Bildirim mesajı', 160);
    final nextHour = hour ?? current.hour;
    final nextMinute = minute ?? current.minute;
    if (nextHour < 0 || nextHour > 23 || nextMinute < 0 || nextMinute > 59) {
      throw ArgumentError('Bildirim saati geçersiz.');
    }
    await _commit(
      _state.copyWith(
        notificationSlots: _state.notificationSlots
            .map(
              (item) => item.id == slotId
                  ? item.copyWith(
                      hour: nextHour,
                      minute: nextMinute,
                      message: cleanMessage,
                      enabled: enabled,
                    )
                  : item,
            )
            .toList(growable: false),
      ),
    );
  }

  Future<void> requestNotificationPermissions() async {
    _isBusy = true;
    notifyListeners();
    try {
      _notificationHealth = await _scheduler.requestPermissions();
      await _scheduler.reschedule(_state);
      _notificationHealth = await _scheduler.health();
      _lastError = null;
    } on Object catch (error) {
      _lastError = _friendlyError(error);
    } finally {
      _isBusy = false;
      notifyListeners();
    }
  }

  Future<void> refreshNotificationHealth() async {
    try {
      _notificationHealth = await _scheduler.health();
      notifyListeners();
    } on Object catch (error) {
      _lastError = _friendlyError(error);
      notifyListeners();
    }
  }

  Future<void> rescheduleNotifications() async {
    try {
      await _scheduler.reschedule(_state);
      _notificationHealth = await _scheduler.health();
      _lastError = null;
    } on Object catch (error) {
      _lastError = _friendlyError(error);
    }
    notifyListeners();
  }

  MizanState _replacePerson(PersonAccount replacement) {
    return _state.copyWith(
      people: _state.people
          .map((person) => person.id == replacement.id ? replacement : person)
          .toList(growable: false),
    );
  }

  MizanState _replaceBank(PersonAccount person, BankGroup replacement) {
    return _replacePerson(
      person.copyWith(
        banks: person.banks
            .map((bank) => bank.id == replacement.id ? replacement : bank)
            .toList(growable: false),
      ),
    );
  }

  PersonAccount _personWithPayment(
    PersonAccount person,
    RecordType type,
    String sourceId,
    PaymentRecord payment,
  ) {
    switch (type) {
      case RecordType.debt:
        for (final bank in person.banks) {
          final index = bank.products.indexWhere((item) => item.id == sourceId);
          if (index < 0) {
            continue;
          }
          final record = bank.products[index];
          if (payment.amount > record.remainingAmount) {
            throw ArgumentError('Ödeme kalan borçtan büyük olamaz.');
          }
          return person.copyWith(
            banks: person.banks
                .map(
                  (item) => item.id == bank.id
                      ? item.copyWith(
                          products: item.products
                              .map(
                                (product) => product.id == sourceId
                                    ? product.copyWith(
                                        payments: [
                                          payment,
                                          ...product.payments,
                                        ],
                                      )
                                    : product,
                              )
                              .toList(),
                        )
                      : item,
                )
                .toList(),
          );
        }
        throw ArgumentError('Borç kaydı bulunamadı.');
      case RecordType.personalDebt:
        final record = _personalDebt(person, sourceId);
        if (payment.amount > record.remainingAmount) {
          throw ArgumentError('Ödeme kalan borçtan büyük olamaz.');
        }
        return person.copyWith(
          personalDebts: person.personalDebts
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(payments: [payment, ...item.payments])
                    : item,
              )
              .toList(growable: false),
        );
      case RecordType.bill:
        final record = _bill(person, sourceId);
        if (payment.amount > record.remainingAmount) {
          throw ArgumentError('Ödeme kalan fatura tutarından büyük olamaz.');
        }
        return person.copyWith(
          bills: person.bills
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(payments: [payment, ...item.payments])
                    : item,
              )
              .toList(),
        );
      case RecordType.subscription:
        final record = _subscription(person, sourceId);
        if (payment.amount > record.remainingAmount) {
          throw ArgumentError(
            'Ödeme aboneliğin bu dönem kalan tutarından büyük olamaz.',
          );
        }
        final payments = [payment, ...record.payments];
        final cyclePaid = payments
            .where(
              (item) =>
                  item.appliesToDueDate != null &&
                  dateOnly(item.appliesToDueDate!) ==
                      dateOnly(record.nextDueDate),
            )
            .fold<double>(0.0, (sum, item) => sum + item.amount);
        final nextDate = cyclePaid + 0.001 >= record.amount
            ? _advanceDueDate(
                record.nextDueDate,
                record.frequency,
                record.customFrequencyDays,
              )
            : record.nextDueDate;
        return person.copyWith(
          subscriptions: person.subscriptions
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(payments: payments, nextDueDate: nextDate)
                    : item,
              )
              .toList(growable: false),
        );
      case RecordType.rent:
        final record = _rent(person, sourceId);
        if (payment.amount > record.remainingAmount) {
          throw ArgumentError(
            'Ödeme kalan kira/taksit tutarından büyük olamaz.',
          );
        }
        return person.copyWith(
          rents: person.rents
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(payments: [payment, ...item.payments])
                    : item,
              )
              .toList(),
        );
    }
  }

  PersonAccount _personWithUpdatedPayment(
    PersonAccount person,
    RecordType type,
    String sourceId,
    String paymentId,
    PaymentRecord replacement,
  ) {
    List<PaymentRecord> replace(List<PaymentRecord> payments, double total) {
      final existing = payments.where((item) => item.id == paymentId).toList();
      if (existing.isEmpty) {
        throw ArgumentError('Ödeme kaydı bulunamadı.');
      }
      final paidWithout = payments
          .where((item) => item.id != paymentId)
          .fold<double>(0, (sum, item) => sum + item.amount);
      if (paidWithout + replacement.amount > total + 0.001) {
        throw ArgumentError('Güncellenen ödeme toplam tutarı aşamaz.');
      }
      return payments
          .map((item) => item.id == paymentId ? replacement : item)
          .toList(growable: false);
    }

    switch (type) {
      case RecordType.debt:
        for (final bank in person.banks) {
          if (!bank.products.any((item) => item.id == sourceId)) {
            continue;
          }
          return person.copyWith(
            banks: person.banks
                .map(
                  (item) => item.id == bank.id
                      ? item.copyWith(
                          products: item.products
                              .map(
                                (product) => product.id == sourceId
                                    ? product.copyWith(
                                        payments: replace(
                                          product.payments,
                                          product.totalAmount,
                                        ),
                                      )
                                    : product,
                              )
                              .toList(),
                        )
                      : item,
                )
                .toList(),
          );
        }
        throw ArgumentError('Borç kaydı bulunamadı.');
      case RecordType.personalDebt:
        final debt = _personalDebt(person, sourceId);
        return person.copyWith(
          personalDebts: person.personalDebts
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(
                        payments: replace(item.payments, debt.totalAmount),
                      )
                    : item,
              )
              .toList(growable: false),
        );
      case RecordType.bill:
        final bill = _bill(person, sourceId);
        return person.copyWith(
          bills: person.bills
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(
                        payments: replace(item.payments, bill.amount),
                      )
                    : item,
              )
              .toList(),
        );
      case RecordType.subscription:
        final subscription = _subscription(person, sourceId);
        return person.copyWith(
          subscriptions: person.subscriptions
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(
                        payments: replace(item.payments, subscription.amount),
                      )
                    : item,
              )
              .toList(growable: false),
        );
      case RecordType.rent:
        final rent = _rent(person, sourceId);
        return person.copyWith(
          rents: person.rents
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(
                        payments: replace(item.payments, rent.amount),
                      )
                    : item,
              )
              .toList(),
        );
    }
  }

  PersonAccount _personWithoutPayment(
    PersonAccount person,
    RecordType type,
    String sourceId,
    String paymentId,
  ) {
    switch (type) {
      case RecordType.debt:
        for (final bank in person.banks) {
          if (!bank.products.any((item) => item.id == sourceId)) {
            continue;
          }
          return person.copyWith(
            banks: person.banks
                .map(
                  (item) => item.id == bank.id
                      ? item.copyWith(
                          products: item.products
                              .map(
                                (product) => product.id == sourceId
                                    ? product.copyWith(
                                        payments: product.payments
                                            .where(
                                              (payment) =>
                                                  payment.id != paymentId,
                                            )
                                            .toList(),
                                      )
                                    : product,
                              )
                              .toList(),
                        )
                      : item,
                )
                .toList(),
          );
        }
        throw ArgumentError('Borç kaydı bulunamadı.');
      case RecordType.personalDebt:
        _personalDebt(person, sourceId);
        return person.copyWith(
          personalDebts: person.personalDebts
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(
                        payments: item.payments
                            .where((payment) => payment.id != paymentId)
                            .toList(growable: false),
                      )
                    : item,
              )
              .toList(growable: false),
        );
      case RecordType.bill:
        _bill(person, sourceId);
        return person.copyWith(
          bills: person.bills
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(
                        payments: item.payments
                            .where((payment) => payment.id != paymentId)
                            .toList(),
                      )
                    : item,
              )
              .toList(),
        );
      case RecordType.subscription:
        _subscription(person, sourceId);
        return person.copyWith(
          subscriptions: person.subscriptions
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(
                        payments: item.payments
                            .where((payment) => payment.id != paymentId)
                            .toList(growable: false),
                      )
                    : item,
              )
              .toList(growable: false),
        );
      case RecordType.rent:
        _rent(person, sourceId);
        return person.copyWith(
          rents: person.rents
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(
                        payments: item.payments
                            .where((payment) => payment.id != paymentId)
                            .toList(),
                      )
                    : item,
              )
              .toList(),
        );
    }
  }

  PersonAccount _personWithNote(
    PersonAccount person,
    RecordType type,
    String sourceId,
    RecordNote note,
  ) {
    switch (type) {
      case RecordType.debt:
        for (final bank in person.banks) {
          if (!bank.products.any((item) => item.id == sourceId)) continue;
          return person.copyWith(
            banks: person.banks
                .map(
                  (item) => item.id == bank.id
                      ? item.copyWith(
                          products: item.products
                              .map(
                                (product) => product.id == sourceId
                                    ? product.copyWith(
                                        notes: [note, ...product.notes],
                                      )
                                    : product,
                              )
                              .toList(),
                        )
                      : item,
                )
                .toList(),
          );
        }
        throw ArgumentError('Borç kaydı bulunamadı.');
      case RecordType.personalDebt:
        _personalDebt(person, sourceId);
        return person.copyWith(
          personalDebts: person.personalDebts
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(notes: [note, ...item.notes])
                    : item,
              )
              .toList(growable: false),
        );
      case RecordType.bill:
        _bill(person, sourceId);
        return person.copyWith(
          bills: person.bills
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(notes: [note, ...item.notes])
                    : item,
              )
              .toList(),
        );
      case RecordType.subscription:
        _subscription(person, sourceId);
        return person.copyWith(
          subscriptions: person.subscriptions
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(notes: [note, ...item.notes])
                    : item,
              )
              .toList(growable: false),
        );
      case RecordType.rent:
        _rent(person, sourceId);
        return person.copyWith(
          rents: person.rents
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(notes: [note, ...item.notes])
                    : item,
              )
              .toList(),
        );
    }
  }

  PersonAccount _personWithoutNote(
    PersonAccount person,
    RecordType type,
    String sourceId,
    String noteId,
  ) {
    switch (type) {
      case RecordType.debt:
        for (final bank in person.banks) {
          if (!bank.products.any((item) => item.id == sourceId)) {
            continue;
          }
          return person.copyWith(
            banks: person.banks
                .map(
                  (item) => item.id == bank.id
                      ? item.copyWith(
                          products: item.products
                              .map(
                                (product) => product.id == sourceId
                                    ? product.copyWith(
                                        notes: product.notes
                                            .where((note) => note.id != noteId)
                                            .toList(),
                                      )
                                    : product,
                              )
                              .toList(),
                        )
                      : item,
                )
                .toList(),
          );
        }
        throw ArgumentError('Borç kaydı bulunamadı.');
      case RecordType.personalDebt:
        _personalDebt(person, sourceId);
        return person.copyWith(
          personalDebts: person.personalDebts
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(
                        notes: item.notes
                            .where((note) => note.id != noteId)
                            .toList(growable: false),
                      )
                    : item,
              )
              .toList(growable: false),
        );
      case RecordType.bill:
        _bill(person, sourceId);
        return person.copyWith(
          bills: person.bills
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(
                        notes: item.notes
                            .where((note) => note.id != noteId)
                            .toList(),
                      )
                    : item,
              )
              .toList(),
        );
      case RecordType.subscription:
        _subscription(person, sourceId);
        return person.copyWith(
          subscriptions: person.subscriptions
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(
                        notes: item.notes
                            .where((note) => note.id != noteId)
                            .toList(growable: false),
                      )
                    : item,
              )
              .toList(growable: false),
        );
      case RecordType.rent:
        _rent(person, sourceId);
        return person.copyWith(
          rents: person.rents
              .map(
                (item) => item.id == sourceId
                    ? item.copyWith(
                        notes: item.notes
                            .where((note) => note.id != noteId)
                            .toList(),
                      )
                    : item,
              )
              .toList(),
        );
    }
  }

  DebtProduct _buildDebt({
    required String id,
    required DebtKind kind,
    required String title,
    required double totalAmount,
    required double monthlyAmount,
    required DateTime dueDate,
    DebtDueMode dueMode = DebtDueMode.fixedDate,
    int? dueDayOfMonth,
    String customKindName = '',
    int? installmentCount,
    int? currentInstallment,
    double? limit,
    double? usedLimit,
    String description = '',
    bool isArchived = false,
    List<PaymentRecord> payments = const [],
    List<RecordNote> notes = const [],
  }) {
    final cleanTitle = _requiredText(title, 'Borç başlığı', 100);
    _positiveAmount(totalAmount, 'Toplam borç');
    _nonNegativeAmount(monthlyAmount, 'Aylık tutar');
    if (dueMode == DebtDueMode.monthlyDay) {
      if (dueDayOfMonth == null || dueDayOfMonth < 1 || dueDayOfMonth > 31) {
        throw ArgumentError('Aylık ödeme günü 1 ile 31 arasında olmalıdır.');
      }
      if (monthlyAmount <= 0) {
        throw ArgumentError(
          'Her ayın belirli günü seçildiğinde aylık tutar girilmelidir.',
        );
      }
    }
    if (kind == DebtKind.custom) {
      _requiredText(customKindName, 'Özel borç türü', 60);
    }
    _validateInstallments(installmentCount, currentInstallment);
    if (limit != null) {
      _nonNegativeAmount(limit, 'Limit');
    }
    if (usedLimit != null) {
      _nonNegativeAmount(usedLimit, 'Kullanılan limit');
    }
    if (limit != null && usedLimit != null && usedLimit > limit) {
      throw ArgumentError('Kullanılan limit toplam limiti aşamaz.');
    }
    return DebtProduct(
      id: id,
      kind: kind,
      title: cleanTitle,
      customKindName: _optionalText(customKindName, 'Özel borç türü', 60),
      totalAmount: totalAmount,
      monthlyAmount: monthlyAmount,
      dueDate: dateOnly(dueDate),
      dueMode: dueMode,
      dueDayOfMonth: dueMode == DebtDueMode.monthlyDay ? dueDayOfMonth : null,
      installmentCount: installmentCount,
      currentInstallment: currentInstallment,
      limit: limit,
      usedLimit: usedLimit,
      description: _optionalText(description, 'Açıklama', 240),
      isArchived: isArchived,
      payments: payments,
      notes: notes,
    );
  }

  PersonalDebtEntry _buildPersonalDebt({
    required String id,
    required CreditorType creditorType,
    required String title,
    required String creditorName,
    required double totalAmount,
    required DateTime debtDate,
    required DateTime dueDate,
    required PaymentFrequency frequency,
    bool isInstallment = false,
    int? installmentCount,
    int? currentInstallment,
    double monthlyAmount = 0,
    int? customFrequencyDays,
    String description = '',
    String chequeNumber = '',
    String issuerName = '',
    String bankInfo = '',
    String promissoryNoteNumber = '',
    int? documentCount,
    int? currentDocument,
    List<DueScheduleItem> schedule = const [],
    bool isArchived = false,
    List<PaymentRecord> payments = const [],
    List<RecordNote> notes = const [],
  }) {
    _positiveAmount(totalAmount, 'Toplam borç');
    _nonNegativeAmount(monthlyAmount, 'Düzenli ödeme tutarı');
    if (dueDate.isBefore(debtDate)) {
      throw ArgumentError('Son ödeme tarihi borç tarihinden önce olamaz.');
    }
    if (isInstallment) {
      _validateInstallments(installmentCount, currentInstallment);
      if (monthlyAmount <= 0) {
        throw ArgumentError('Taksitli borçta ödeme tutarı girilmelidir.');
      }
    }
    if (frequency == PaymentFrequency.custom &&
        (customFrequencyDays == null || customFrequencyDays <= 0)) {
      throw ArgumentError('Özel ödeme aralığı gün olarak girilmelidir.');
    }
    if (creditorType == CreditorType.cheque && chequeNumber.trim().isEmpty) {
      throw ArgumentError('Çek numarası boş bırakılamaz.');
    }
    if (creditorType == CreditorType.promissoryNote &&
        promissoryNoteNumber.trim().isEmpty) {
      throw ArgumentError('Senet numarası boş bırakılamaz.');
    }
    if (documentCount != null || currentDocument != null) {
      _validateInstallments(documentCount, currentDocument);
    }
    final normalizedSchedule = schedule
        .map(
          (item) => item.copyWith(
            amount: _normalizedPositive(item.amount, 'Ödeme planı tutarı'),
            dueDate: dateOnly(item.dueDate),
          ),
        )
        .toList(growable: false);
    return PersonalDebtEntry(
      id: id,
      creditorType: creditorType,
      title: _requiredText(title, 'Borç başlığı', 100),
      creditorName: _requiredText(creditorName, 'Alacaklı adı', 100),
      totalAmount: totalAmount,
      debtDate: dateOnly(debtDate),
      dueDate: dateOnly(dueDate),
      frequency: frequency,
      isInstallment: isInstallment,
      installmentCount: installmentCount,
      currentInstallment: currentInstallment,
      monthlyAmount: monthlyAmount,
      customFrequencyDays: customFrequencyDays,
      description: _optionalText(description, 'Açıklama', 240),
      chequeNumber: _optionalText(chequeNumber, 'Çek numarası', 80),
      issuerName: _optionalText(issuerName, 'Düzenleyen', 100),
      bankInfo: _optionalText(bankInfo, 'Banka bilgisi', 100),
      promissoryNoteNumber: _optionalText(
        promissoryNoteNumber,
        'Senet numarası',
        80,
      ),
      documentCount: documentCount,
      currentDocument: currentDocument,
      schedule: normalizedSchedule,
      isArchived: isArchived,
      payments: payments,
      notes: notes,
    );
  }

  SubscriptionEntry _buildSubscription({
    required String id,
    required SubscriptionKind kind,
    required String title,
    required String providerName,
    required double amount,
    required PaymentFrequency frequency,
    required DateTime nextDueDate,
    String customKindName = '',
    int? customFrequencyDays,
    String subscriberNumber = '',
    String contractNumber = '',
    String description = '',
    bool isArchived = false,
    List<PaymentRecord> payments = const [],
    List<RecordNote> notes = const [],
  }) {
    _positiveAmount(amount, 'Abonelik tutarı');
    if (kind == SubscriptionKind.custom) {
      _requiredText(customKindName, 'Abonelik türü', 60);
    }
    if (frequency == PaymentFrequency.oneTime) {
      throw ArgumentError('Abonelik ödeme sıklığı tek ödeme olamaz.');
    }
    if (frequency == PaymentFrequency.custom &&
        (customFrequencyDays == null || customFrequencyDays <= 0)) {
      throw ArgumentError('Özel ödeme aralığı gün olarak girilmelidir.');
    }
    return SubscriptionEntry(
      id: id,
      kind: kind,
      title: _requiredText(title, 'Abonelik başlığı', 100),
      providerName: _requiredText(providerName, 'Sağlayıcı adı', 100),
      amount: amount,
      frequency: frequency,
      nextDueDate: dateOnly(nextDueDate),
      customKindName: _optionalText(customKindName, 'Abonelik türü', 60),
      customFrequencyDays: customFrequencyDays,
      subscriberNumber: _optionalText(subscriberNumber, 'Abone numarası', 60),
      contractNumber: _optionalText(contractNumber, 'Sözleşme numarası', 60),
      description: _optionalText(description, 'Açıklama', 240),
      isArchived: isArchived,
      payments: payments,
      notes: notes,
    );
  }

  BillEntry _buildBill({
    required String id,
    required BillKind kind,
    required String institutionName,
    required double amount,
    required DateTime dueDate,
    String subscriberNumber = '',
    String contractNumber = '',
    String description = '',
    bool isArchived = false,
    List<PaymentRecord> payments = const [],
    List<RecordNote> notes = const [],
  }) {
    _positiveAmount(amount, 'Fatura tutarı');
    return BillEntry(
      id: id,
      kind: kind,
      institutionName: _requiredText(institutionName, 'Kurum adı', 100),
      subscriberNumber: _optionalText(subscriberNumber, 'Abone numarası', 60),
      contractNumber: _optionalText(contractNumber, 'Sözleşme numarası', 60),
      amount: amount,
      dueDate: dateOnly(dueDate),
      description: _optionalText(description, 'Açıklama', 240),
      isArchived: isArchived,
      payments: payments,
      notes: notes,
    );
  }

  RentEntry _buildRent({
    required String id,
    required String title,
    required double amount,
    required int paymentDay,
    required String receiverName,
    required DateTime dueDate,
    String iban = '',
    DateTime? contractStart,
    DateTime? contractEnd,
    DateTime? increaseDate,
    int? installmentCount,
    int? currentInstallment,
    String description = '',
    bool isArchived = false,
    List<PaymentRecord> payments = const [],
    List<RecordNote> notes = const [],
  }) {
    _positiveAmount(amount, 'Kira/taksit tutarı');
    if (paymentDay < 1 || paymentDay > 31) {
      throw ArgumentError('Ödeme günü 1 ile 31 arasında olmalı.');
    }
    _validateInstallments(installmentCount, currentInstallment);
    if (contractStart != null &&
        contractEnd != null &&
        contractEnd.isBefore(contractStart)) {
      throw ArgumentError('Sözleşme bitişi başlangıçtan önce olamaz.');
    }
    return RentEntry(
      id: id,
      title: _requiredText(title, 'Kira/taksit başlığı', 100),
      amount: amount,
      paymentDay: paymentDay,
      receiverName: _requiredText(receiverName, 'Alıcı adı', 100),
      iban: _optionalText(iban, 'IBAN', 40),
      dueDate: dateOnly(dueDate),
      contractStart: contractStart == null ? null : dateOnly(contractStart),
      contractEnd: contractEnd == null ? null : dateOnly(contractEnd),
      increaseDate: increaseDate == null ? null : dateOnly(increaseDate),
      installmentCount: installmentCount,
      currentInstallment: currentInstallment,
      description: _optionalText(description, 'Açıklama', 240),
      isArchived: isArchived,
      payments: payments,
      notes: notes,
    );
  }

  ExpenseItem _buildExpense({
    required String id,
    required String categoryId,
    required String name,
    required double quantity,
    required double unitPrice,
    required DateTime spentAt,
    String note = '',
  }) {
    _positiveAmount(quantity, 'Adet');
    _nonNegativeAmount(unitPrice, 'Birim fiyat');
    return ExpenseItem(
      id: id,
      categoryId: categoryId,
      name: _requiredText(name, 'Gider adı', 100),
      quantity: quantity,
      unitPrice: unitPrice,
      spentAt: dateOnly(spentAt),
      note: _optionalText(note, 'Gider notu', 240),
    );
  }

  void _validateState(MizanState state) {
    final ids = <String>{};
    void addId(String id, String type) {
      if (id.trim().isEmpty || !ids.add(id)) {
        throw StateError('$type kayıt kimliği geçersiz veya tekrarlı.');
      }
    }

    for (final person in state.people) {
      addId(person.id, 'Kişi');
      _requiredText(person.name, 'Kişi adı', 80);
      for (final bank in person.banks) {
        addId(bank.id, 'Banka');
        _requiredText(bank.userWrittenName, 'Banka adı', 100);
        for (final debt in bank.products) {
          addId(debt.id, 'Borç');
          if (debt.paidAmount > debt.totalAmount + 0.001) {
            throw StateError('Bir borç kaydında ödeme toplamı borcu aşıyor.');
          }
          for (final payment in debt.payments) {
            addId(payment.id, 'Ödeme');
          }
          for (final note in debt.notes) {
            addId(note.id, 'Not');
          }
        }
      }
      for (final debt in person.personalDebts) {
        addId(debt.id, 'Kişisel/kurumsal borç');
        if (debt.paidAmount > debt.totalAmount + 0.001) {
          throw StateError('Bir kişisel borçta ödeme toplamı borcu aşıyor.');
        }
        for (final scheduleItem in debt.schedule) {
          addId(scheduleItem.id, 'Ödeme planı');
        }
        for (final payment in debt.payments) {
          addId(payment.id, 'Ödeme');
        }
        for (final note in debt.notes) {
          addId(note.id, 'Not');
        }
      }
      for (final bill in person.bills) {
        addId(bill.id, 'Fatura');
        if (bill.paidAmount > bill.amount + 0.001) {
          throw StateError('Bir fatura kaydında ödeme toplamı tutarı aşıyor.');
        }
        for (final payment in bill.payments) {
          addId(payment.id, 'Ödeme');
        }
        for (final note in bill.notes) {
          addId(note.id, 'Not');
        }
      }
      for (final subscription in person.subscriptions) {
        addId(subscription.id, 'Abonelik');
        for (final payment in subscription.payments) {
          addId(payment.id, 'Ödeme');
        }
        for (final note in subscription.notes) {
          addId(note.id, 'Not');
        }
      }
      for (final rent in person.rents) {
        addId(rent.id, 'Kira');
        if (rent.paidAmount > rent.amount + 0.001) {
          throw StateError('Bir kira kaydında ödeme toplamı tutarı aşıyor.');
        }
        for (final payment in rent.payments) {
          addId(payment.id, 'Ödeme');
        }
        for (final note in rent.notes) {
          addId(note.id, 'Not');
        }
      }
    }
    final categoryIds = <String>{};
    for (final category in state.expenseCategories) {
      addId(category.id, 'Kategori');
      categoryIds.add(category.id);
    }
    for (final expense in state.expenses) {
      addId(expense.id, 'Gider');
      if (!categoryIds.contains(expense.categoryId)) {
        throw StateError('Bir gider kaydı bulunmayan kategoriye bağlı.');
      }
    }
  }

  PersonAccount _person(String id) => _state.people.firstWhere(
    (item) => item.id == id,
    orElse: () => throw ArgumentError('Kişi bulunamadı.'),
  );

  BankGroup _bank(PersonAccount person, String id) => person.banks.firstWhere(
    (item) => item.id == id,
    orElse: () => throw ArgumentError('Banka kaydı bulunamadı.'),
  );

  DebtProduct _debt(BankGroup bank, String id) => bank.products.firstWhere(
    (item) => item.id == id,
    orElse: () => throw ArgumentError('Borç kaydı bulunamadı.'),
  );

  PersonalDebtEntry _personalDebt(PersonAccount person, String id) =>
      person.personalDebts.firstWhere(
        (item) => item.id == id,
        orElse: () => throw ArgumentError('Kişisel/kurumsal borç bulunamadı.'),
      );

  SubscriptionEntry _subscription(PersonAccount person, String id) =>
      person.subscriptions.firstWhere(
        (item) => item.id == id,
        orElse: () => throw ArgumentError('Abonelik kaydı bulunamadı.'),
      );

  BillEntry _bill(PersonAccount person, String id) => person.bills.firstWhere(
    (item) => item.id == id,
    orElse: () => throw ArgumentError('Fatura kaydı bulunamadı.'),
  );

  RentEntry _rent(PersonAccount person, String id) => person.rents.firstWhere(
    (item) => item.id == id,
    orElse: () => throw ArgumentError('Kira/taksit kaydı bulunamadı.'),
  );

  PaymentRecord _paymentFor(
    PersonAccount person,
    RecordType type,
    String sourceId,
    String paymentId,
  ) {
    Iterable<PaymentRecord> payments;
    switch (type) {
      case RecordType.debt:
        payments = person.banks
            .expand((bank) => bank.products)
            .firstWhere(
              (item) => item.id == sourceId,
              orElse: () => throw ArgumentError('Borç kaydı bulunamadı.'),
            )
            .payments;
      case RecordType.personalDebt:
        payments = _personalDebt(person, sourceId).payments;
      case RecordType.bill:
        payments = _bill(person, sourceId).payments;
      case RecordType.subscription:
        payments = _subscription(person, sourceId).payments;
      case RecordType.rent:
        payments = _rent(person, sourceId).payments;
    }
    return payments.firstWhere(
      (item) => item.id == paymentId,
      orElse: () => throw ArgumentError('Ödeme kaydı bulunamadı.'),
    );
  }

  DateTime _advanceDueDate(
    DateTime dueDate,
    PaymentFrequency frequency,
    int? customDays,
  ) {
    switch (frequency) {
      case PaymentFrequency.oneTime:
        return dueDate;
      case PaymentFrequency.weekly:
        return dueDate.add(const Duration(days: 7));
      case PaymentFrequency.biweekly:
        return dueDate.add(const Duration(days: 14));
      case PaymentFrequency.monthly:
        return _addMonths(dueDate, 1);
      case PaymentFrequency.quarterly:
        return _addMonths(dueDate, 3);
      case PaymentFrequency.yearly:
        return _addMonths(dueDate, 12);
      case PaymentFrequency.custom:
        return dueDate.add(Duration(days: customDays ?? 1));
    }
  }

  DateTime _addMonths(DateTime source, int count) {
    final targetMonth = source.month - 1 + count;
    final year = source.year + targetMonth ~/ 12;
    final month = targetMonth % 12 + 1;
    final lastDay = DateTime(year, month + 1, 0).day;
    return DateTime(year, month, source.day.clamp(1, lastDay));
  }

  double _normalizedPositive(double value, String label) {
    _positiveAmount(value, label);
    return double.parse(value.toStringAsFixed(2));
  }

  ExpenseCategory _category(String id) => _state.expenseCategories.firstWhere(
    (item) => item.id == id,
    orElse: () => throw ArgumentError('Gider kategorisi bulunamadı.'),
  );

  ExpenseItem _expense(String id) => _state.expenses.firstWhere(
    (item) => item.id == id,
    orElse: () => throw ArgumentError('Gider kaydı bulunamadı.'),
  );

  void _ensureUniqueBankName(
    PersonAccount person,
    String name, {
    String? excludingId,
  }) {
    final normalized = name.toLowerCase();
    if (person.banks.any(
      (bank) =>
          bank.id != excludingId &&
          bank.userWrittenName.toLowerCase() == normalized,
    )) {
      throw ArgumentError('Bu kişide aynı banka adı zaten var.');
    }
  }

  void _ensureUniqueCategoryName(String name, {String? excludingId}) {
    final normalized = name.toLowerCase();
    if (_state.expenseCategories.any(
      (category) =>
          category.id != excludingId &&
          category.name.toLowerCase() == normalized,
    )) {
      throw ArgumentError('Bu kategori adı zaten kullanılıyor.');
    }
  }

  String _requiredText(String value, String label, int maxLength) {
    final clean = value.trim();
    if (clean.isEmpty) {
      throw ArgumentError('$label boş bırakılamaz.');
    }
    if (clean.length > maxLength) {
      throw ArgumentError('$label en fazla $maxLength karakter olabilir.');
    }
    return clean;
  }

  String _optionalText(String value, String label, int maxLength) {
    final clean = value.trim();
    if (clean.length > maxLength) {
      throw ArgumentError('$label en fazla $maxLength karakter olabilir.');
    }
    return clean;
  }

  void _positiveAmount(double value, String label) {
    if (!value.isFinite || value <= 0) {
      throw ArgumentError('$label sıfırdan büyük olmalı.');
    }
  }

  void _nonNegativeAmount(double value, String label) {
    if (!value.isFinite || value < 0) {
      throw ArgumentError('$label negatif olamaz.');
    }
  }

  void _validateInstallments(int? total, int? current) {
    if (total != null && total <= 0) {
      throw ArgumentError('Toplam taksit pozitif olmalı.');
    }
    if (current != null && current <= 0) {
      throw ArgumentError('Mevcut taksit pozitif olmalı.');
    }
    if (total != null && current != null && current > total) {
      throw ArgumentError('Mevcut taksit toplam taksiti aşamaz.');
    }
  }

  String _friendlyError(Object error) {
    return error
        .toString()
        .replaceFirst('Invalid argument(s): ', '')
        .replaceFirst('Bad state: ', '')
        .replaceFirst('FormatException: ', '')
        .replaceFirst('FileSystemException: ', '');
  }
}
