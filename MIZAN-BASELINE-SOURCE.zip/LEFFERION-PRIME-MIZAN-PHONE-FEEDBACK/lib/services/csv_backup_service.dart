import 'dart:convert';

import 'package:csv/csv.dart';

import '../models/mizan_models.dart';

class CsvBackupService {
  const CsvBackupService();

  static const formatName = 'MIZAN_CSV_BACKUP';
  static final CsvCodec _codec = CsvCodec();

  String exportState(MizanState state) {
    final safeState = state.copyWith(schemaVersion: currentSchemaVersion);
    final rows = <List<dynamic>>[
      const [
        'format',
        'schema_version',
        'entity_type',
        'entity_id',
        'person_id',
        'bank_id',
        'record_type',
        'record_id',
        'name',
        'amount',
        'date',
        'data_json',
      ],
      [
        formatName,
        currentSchemaVersion,
        'snapshot',
        'state',
        '',
        '',
        '',
        '',
        'MİZAN tam yedek',
        '',
        DateTime.now().toUtc().toIso8601String(),
        jsonEncode(safeState.toJson()),
      ],
    ];

    for (final person in safeState.people) {
      rows.add(
        _row(
          'person',
          person.id,
          person.name,
          person.toJson(),
          personId: person.id,
        ),
      );
      for (final bank in person.banks) {
        rows.add(
          _row(
            'bank_group',
            bank.id,
            bank.userWrittenName,
            bank.toJson(),
            personId: person.id,
            bankId: bank.id,
            amount: bank.totalDebt,
          ),
        );
        for (final debt in bank.products) {
          rows.add(
            _row(
              'bank_debt',
              debt.id,
              debt.title,
              debt.toJson(),
              personId: person.id,
              bankId: bank.id,
              recordType: RecordType.debt.name,
              recordId: debt.id,
              amount: debt.remainingAmount,
              date: debt.dueDate,
            ),
          );
          _children(
            rows,
            person.id,
            bank.id,
            RecordType.debt.name,
            debt.id,
            debt.payments,
            debt.notes,
          );
        }
      }
      for (final debt in person.personalDebts) {
        rows.add(
          _row(
            'personal_corporate_debt',
            debt.id,
            debt.title,
            debt.toJson(),
            personId: person.id,
            recordType: RecordType.personalDebt.name,
            recordId: debt.id,
            amount: debt.remainingAmount,
            date: debt.effectiveDueDate,
          ),
        );
        _children(
          rows,
          person.id,
          '',
          RecordType.personalDebt.name,
          debt.id,
          debt.payments,
          debt.notes,
        );
      }
      for (final bill in person.bills) {
        rows.add(
          _row(
            'bill',
            bill.id,
            '${bill.kind.label} - ${bill.institutionName}',
            bill.toJson(),
            personId: person.id,
            recordType: RecordType.bill.name,
            recordId: bill.id,
            amount: bill.remainingAmount,
            date: bill.dueDate,
          ),
        );
        _children(
          rows,
          person.id,
          '',
          RecordType.bill.name,
          bill.id,
          bill.payments,
          bill.notes,
        );
      }
      for (final subscription in person.subscriptions) {
        rows.add(
          _row(
            'subscription',
            subscription.id,
            subscription.title,
            subscription.toJson(),
            personId: person.id,
            recordType: RecordType.subscription.name,
            recordId: subscription.id,
            amount: subscription.remainingAmount,
            date: subscription.nextDueDate,
          ),
        );
        _children(
          rows,
          person.id,
          '',
          RecordType.subscription.name,
          subscription.id,
          subscription.payments,
          subscription.notes,
        );
      }
      for (final rent in person.rents) {
        rows.add(
          _row(
            'rent_installment',
            rent.id,
            rent.title,
            rent.toJson(),
            personId: person.id,
            recordType: RecordType.rent.name,
            recordId: rent.id,
            amount: rent.remainingAmount,
            date: rent.dueDate,
          ),
        );
        _children(
          rows,
          person.id,
          '',
          RecordType.rent.name,
          rent.id,
          rent.payments,
          rent.notes,
        );
      }
    }
    for (final category in safeState.expenseCategories) {
      rows.add(
        _row('expense_category', category.id, category.name, category.toJson()),
      );
    }
    for (final expense in safeState.expenses) {
      rows.add(
        _row(
          'expense',
          expense.id,
          expense.name,
          expense.toJson(),
          recordId: expense.categoryId,
          amount: expense.totalAmount,
          date: expense.spentAt,
        ),
      );
    }
    return _codec.encode(rows);
  }

  MizanState importState(String content) {
    final rows = _codec.decode(content);
    if (rows.length < 2) {
      throw const FormatException('CSV yedeği boş veya eksik.');
    }
    final header = rows.first.map((value) => value.toString()).toList();
    final formatIndex = header.indexOf('format');
    final typeIndex = header.indexOf('entity_type');
    final dataIndex = header.indexOf('data_json');
    if (formatIndex < 0 || typeIndex < 0 || dataIndex < 0) {
      throw const FormatException('Bu dosya MİZAN CSV yedeği değil.');
    }
    for (final row in rows.skip(1)) {
      if (row.length <= dataIndex) {
        continue;
      }
      if (row[formatIndex].toString() != formatName ||
          row[typeIndex].toString() != 'snapshot') {
        continue;
      }
      final decoded = jsonDecode(row[dataIndex].toString());
      if (decoded is! Map) {
        throw const FormatException('CSV tam yedek verisi geçersiz.');
      }
      return MizanState.fromJson(Map<String, dynamic>.from(decoded));
    }
    throw const FormatException('CSV içinde tam MİZAN yedeği bulunamadı.');
  }

  void _children(
    List<List<dynamic>> rows,
    String personId,
    String bankId,
    String type,
    String sourceId,
    List<PaymentRecord> payments,
    List<RecordNote> notes,
  ) {
    for (final payment in payments) {
      rows.add(
        _row(
          'payment',
          payment.id,
          payment.method.isEmpty ? 'Ödeme' : payment.method,
          payment.toJson(),
          personId: personId,
          bankId: bankId,
          recordType: type,
          recordId: sourceId,
          amount: payment.amount,
          date: payment.paidAt,
        ),
      );
    }
    for (final note in notes) {
      rows.add(
        _row(
          'note',
          note.id,
          note.text,
          note.toJson(),
          personId: personId,
          bankId: bankId,
          recordType: type,
          recordId: sourceId,
          date: note.createdAt,
        ),
      );
    }
  }

  List<dynamic> _row(
    String type,
    String id,
    String name,
    Map<String, dynamic> data, {
    String personId = '',
    String bankId = '',
    String recordType = '',
    String recordId = '',
    double? amount,
    DateTime? date,
  }) => [
    formatName,
    currentSchemaVersion,
    type,
    id,
    personId,
    bankId,
    recordType,
    recordId,
    name,
    amount ?? '',
    date?.toIso8601String() ?? '',
    jsonEncode(data),
  ];
}
