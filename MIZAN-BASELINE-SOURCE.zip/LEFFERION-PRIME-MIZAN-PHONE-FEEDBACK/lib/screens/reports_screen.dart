import 'package:flutter/material.dart';

import '../controllers/mizan_controller.dart';
import '../core/formatters.dart';
import '../core/theme.dart';
import '../models/mizan_models.dart';
import '../widgets/mizan_cards.dart';
import 'people_screen.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({required this.controller, super.key});

  final MizanController controller;

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  String? personId;
  bool onlySelectedMonth = true;
  DateTime month = DateTime(DateTime.now().year, DateTime.now().month);
  PaymentStatus? status;

  @override
  Widget build(BuildContext context) {
    final state = widget.controller.state;
    if (personId != null && !state.people.any((item) => item.id == personId)) {
      personId = null;
    }
    final now = DateTime.now();
    final records =
        state
            .recordReferencesAt(now)
            .where((item) {
              if (personId != null && item.personId != personId) return false;
              if (onlySelectedMonth && !isSameMonth(item.dueDate, month)) {
                return false;
              }
              if (status != null && item.status != status) return false;
              return true;
            })
            .toList(growable: false)
          ..sort((a, b) => a.dueDate.compareTo(b.dueDate));

    final openRecords = records.where(
      (item) =>
          item.status != PaymentStatus.completed &&
          item.status != PaymentStatus.passive,
    );
    final remainingLoad = openRecords.fold<double>(
      0.0,
      (sum, item) => sum + item.amount,
    );
    final overdue = records
        .where((item) => item.status == PaymentStatus.overdue)
        .fold<double>(0.0, (sum, item) => sum + item.amount);
    final upcoming = records
        .where((item) => item.status == PaymentStatus.upcoming)
        .fold<double>(0.0, (sum, item) => sum + item.amount);

    final remainingByType = <RecordType, double>{
      for (final type in RecordType.values) type: 0,
    };
    for (final record in openRecords) {
      remainingByType[record.type] =
          (remainingByType[record.type] ?? 0) + record.amount;
    }

    final reportMonth = onlySelectedMonth ? month : null;
    final actualPayments = state.actualPaymentTotals(
      month: reportMonth,
      personId: personId,
    );
    final actualPaymentTotal = actualPayments.values.fold<double>(
      0.0,
      (sum, item) => sum + item,
    );

    final expenseSource = state.expenses
        .where((item) => !onlySelectedMonth || isSameMonth(item.spentAt, month))
        .toList(growable: false);
    final expenseTotal = expenseSource.fold<double>(
      0.0,
      (sum, item) => sum + item.totalAmount,
    );
    final expenseByCategory = <String, double>{};
    for (final expense in expenseSource) {
      expenseByCategory[expense.categoryId] =
          (expenseByCategory[expense.categoryId] ?? 0) + expense.totalAmount;
    }
    final realizedGrandTotal = actualPaymentTotal + expenseTotal;
    final periodLabel = onlySelectedMonth
        ? '${month.month.toString().padLeft(2, '0')}.${month.year}'
        : 'Tüm zamanlar';
    final padding = MediaQuery.sizeOf(context).width < 380 ? 12.0 : 18.0;

    return ListView(
      key: const PageStorageKey('reports'),
      padding: EdgeInsets.fromLTRB(padding, 18, padding, 110),
      children: [
        const PageHeader(
          title: 'Raporlar',
          subtitle:
              'Gerçekleşen ödemeleri, günlük giderleri ve kalan ödeme yükünü birbirine karıştırmadan gösterir.',
        ),
        const SizedBox(height: 18),
        _SimpleFilters(
          state: state,
          personId: personId,
          onlySelectedMonth: onlySelectedMonth,
          month: month,
          status: status,
          onPersonChanged: (value) => setState(() => personId = value),
          onPeriodChanged: (value) => setState(() => onlySelectedMonth = value),
          onMonthChanged: (value) => setState(() => month = value),
          onStatusChanged: (value) => setState(() => status = value),
        ),
        const SizedBox(height: 16),
        _RealizedTotalCard(
          periodLabel: periodLabel,
          paymentTotal: actualPaymentTotal,
          expenseTotal: expenseTotal,
          grandTotal: realizedGrandTotal,
        ),
        const SizedBox(height: 16),
        AdaptiveGrid(
          minTileWidth: 175,
          children: [
            MetricCard(
              label: 'Gerçekleşen ödemeler',
              value: money(actualPaymentTotal),
              color: MizanTheme.blue,
              icon: Icons.payments_outlined,
            ),
            MetricCard(
              label: 'Giderler',
              value: money(expenseTotal),
              color: MizanTheme.green,
              icon: Icons.shopping_bag_outlined,
            ),
            MetricCard(
              label: 'Kalan ödeme yükü',
              value: money(remainingLoad),
              icon: Icons.account_balance_wallet_outlined,
            ),
            MetricCard(
              label: 'Gecikmiş',
              value: money(overdue),
              color: MizanTheme.red,
              icon: Icons.warning_amber_rounded,
            ),
            MetricCard(
              label: 'Yaklaşan',
              value: money(upcoming),
              color: MizanTheme.orange,
              icon: Icons.upcoming_outlined,
            ),
          ],
        ),
        const SizedBox(height: 16),
        _ReportSection(
          title: onlySelectedMonth
              ? 'Bu ay yapılan ödemeler'
              : 'Gerçekleşen ödemeler',
          subtitle:
              'Ödeme geçmişine kaydedilen tutarlar kayıt türüne göre ayrı gösterilir.',
          showZeroEntries: true,
          entries: [
            for (final type in RecordType.values)
              _ReportEntry(
                label: _reportTypeLabel(type),
                amount: actualPayments[type] ?? 0,
                icon: _recordIcon(type),
              ),
          ],
        ),
        const SizedBox(height: 12),
        _ReportSection(
          title: 'Kalan ödeme yükünün dağılımı',
          subtitle:
              'Toplam borcun tamamı değil, seçili dönemdeki sıradaki ödeme tutarları gösterilir.',
          entries: [
            for (final type in RecordType.values)
              _ReportEntry(
                label: _reportTypeLabel(type),
                amount: remainingByType[type] ?? 0,
                icon: _recordIcon(type),
                onTap: () => _showRecords(
                  context,
                  _reportTypeLabel(type),
                  records.where((item) => item.type == type).toList(),
                ),
              ),
          ],
        ),
        const SizedBox(height: 12),
        _ReportSection(
          title: 'Gider dağılımı',
          subtitle:
              'Giderler bölümü ödeme kayıtlarından ayrıdır ve kategori bazında gösterilir.',
          entries: [
            for (final category in state.expenseCategories)
              _ReportEntry(
                label: category.name,
                amount: expenseByCategory[category.id] ?? 0,
                icon: Icons.category_outlined,
              ),
          ],
          emptyMessage: 'Seçili dönemde gider kaydı yok.',
        ),
        const SizedBox(height: 12),
        _ReportSection(
          title: 'Kişi bazında kalan borç',
          subtitle: 'Her kişinin birbirinden bağımsız toplam borcu',
          entries: [
            for (final person in state.people.where(
              (item) => personId == null || item.id == personId,
            ))
              _ReportEntry(
                label: person.name,
                amount: person.totalDebt,
                icon: Icons.person_outline,
              ),
          ],
          emptyMessage: 'Henüz kişi kaydı yok.',
        ),
      ],
    );
  }

  Future<void> _showRecords(
    BuildContext context,
    String title,
    List<RecordReference> records,
  ) => showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (sheetContext) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: .75,
      minChildSize: .45,
      maxChildSize: .95,
      builder: (_, scrollController) => ListView(
        controller: scrollController,
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
        children: [
          Text(
            title,
            style: Theme.of(
              sheetContext,
            ).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 12),
          if (records.isEmpty)
            const EmptyState(
              title: 'Kayıt yok',
              message: 'Bu rapor başlığında görüntülenecek kayıt bulunmuyor.',
            )
          else
            for (final record in records) ...[
              MizanListCard(
                title: record.title,
                subtitle:
                    '${record.subtitle}\n${shortDate(record.dueDate)} · Bu vade ${money(record.amount)}',
                leadingColor: statusColor(record.status),
                icon: _recordIcon(record.type),
                trailing: StatusChip(status: record.status),
                onTap: () async {
                  Navigator.pop(sheetContext);
                  await showRecordDetails(
                    context: context,
                    controller: widget.controller,
                    personId: record.personId,
                    type: record.type,
                    sourceId: record.sourceId,
                    bankId: record.bankId,
                  );
                },
              ),
              const SizedBox(height: 8),
            ],
        ],
      ),
    ),
  );
}

class _RealizedTotalCard extends StatelessWidget {
  const _RealizedTotalCard({
    required this.periodLabel,
    required this.paymentTotal,
    required this.expenseTotal,
    required this.grandTotal,
  });

  final String periodLabel;
  final double paymentTotal;
  final double expenseTotal;
  final double grandTotal;

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.summarize_outlined, color: MizanTheme.blue),
          const SizedBox(height: 10),
          const Text(
            'Bu ay gerçekleşen toplam ödeme-gider raporu',
            style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17),
          ),
          const SizedBox(height: 4),
          Text(periodLabel, style: const TextStyle(color: MizanTheme.muted)),
          const SizedBox(height: 12),
          Text(
            money(grandTotal),
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.w900,
              color: MizanTheme.ink,
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 12,
            runSpacing: 8,
            children: [
              _InlineTotal(label: 'Ödemeler', amount: paymentTotal),
              _InlineTotal(label: 'Giderler', amount: expenseTotal),
            ],
          ),
        ],
      ),
    ),
  );
}

class _InlineTotal extends StatelessWidget {
  const _InlineTotal({required this.label, required this.amount});
  final String label;
  final double amount;

  @override
  Widget build(BuildContext context) => DecoratedBox(
    decoration: BoxDecoration(
      color: MizanTheme.surface,
      borderRadius: BorderRadius.circular(12),
    ),
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      child: Text(
        '$label: ${money(amount)}',
        style: const TextStyle(fontWeight: FontWeight.w800),
      ),
    ),
  );
}

class _SimpleFilters extends StatelessWidget {
  const _SimpleFilters({
    required this.state,
    required this.personId,
    required this.onlySelectedMonth,
    required this.month,
    required this.status,
    required this.onPersonChanged,
    required this.onPeriodChanged,
    required this.onMonthChanged,
    required this.onStatusChanged,
  });

  final MizanState state;
  final String? personId;
  final bool onlySelectedMonth;
  final DateTime month;
  final PaymentStatus? status;
  final ValueChanged<String?> onPersonChanged;
  final ValueChanged<bool> onPeriodChanged;
  final ValueChanged<DateTime> onMonthChanged;
  final ValueChanged<PaymentStatus?> onStatusChanged;

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'Rapor kapsamı',
            style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            initialValue: personId ?? '',
            isExpanded: true,
            decoration: const InputDecoration(labelText: 'Kişi'),
            items: [
              const DropdownMenuItem<String>(
                value: '',
                child: Text('Tüm kişiler'),
              ),
              for (final person in state.people)
                DropdownMenuItem<String>(
                  value: person.id,
                  child: Text(person.name),
                ),
            ],
            onChanged: (value) =>
                onPersonChanged(value == null || value.isEmpty ? null : value),
          ),
          const SizedBox(height: 10),
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: true, label: Text('Seçili ay')),
              ButtonSegment(value: false, label: Text('Tüm zamanlar')),
            ],
            selected: {onlySelectedMonth},
            onSelectionChanged: (values) => onPeriodChanged(values.first),
          ),
          if (onlySelectedMonth) ...[
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: () async {
                final selected = await showDatePicker(
                  context: context,
                  initialDate: month,
                  firstDate: DateTime(2000),
                  lastDate: DateTime(2100),
                  helpText: 'Rapor ayından bir gün seçin',
                );
                if (selected != null) {
                  onMonthChanged(DateTime(selected.year, selected.month));
                }
              },
              icon: const Icon(Icons.calendar_month_outlined),
              label: Text(
                '${month.month.toString().padLeft(2, '0')}.${month.year}',
              ),
            ),
          ],
          const SizedBox(height: 12),
          const Divider(height: 1),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: status?.name ?? '',
            isExpanded: true,
            decoration: const InputDecoration(
              labelText: 'Kayıt durumu',
              helperText: 'İsteğe bağlı filtre',
            ),
            items: [
              const DropdownMenuItem<String>(
                value: '',
                child: Text('Tüm durumlar'),
              ),
              for (final item in PaymentStatus.values)
                DropdownMenuItem<String>(
                  value: item.name,
                  child: Text(item.label),
                ),
            ],
            onChanged: (value) => onStatusChanged(
              value == null || value.isEmpty
                  ? null
                  : PaymentStatus.values.firstWhere(
                      (item) => item.name == value,
                    ),
            ),
          ),
          if (personId != null) ...[
            const SizedBox(height: 8),
            const Text(
              'Kişi filtresi ödeme kayıtlarını etkiler. Giderler kişiden bağımsız tutulduğu için gider toplamı değişmez.',
              style: TextStyle(color: MizanTheme.muted, fontSize: 12),
            ),
          ],
        ],
      ),
    ),
  );
}

class _ReportEntry {
  const _ReportEntry({
    required this.label,
    required this.amount,
    required this.icon,
    this.onTap,
  });

  final String label;
  final double amount;
  final IconData icon;
  final VoidCallback? onTap;
}

class _ReportSection extends StatelessWidget {
  const _ReportSection({
    required this.title,
    required this.subtitle,
    required this.entries,
    this.emptyMessage = 'Kayıt bulunmuyor.',
    this.showZeroEntries = false,
  });

  final String title;
  final String subtitle;
  final List<_ReportEntry> entries;
  final String emptyMessage;
  final bool showZeroEntries;

  @override
  Widget build(BuildContext context) {
    final visible = showZeroEntries
        ? entries
        : entries.where((item) => item.amount > 0).toList();
    final maxAmount = visible.fold<double>(
      0,
      (max, item) => item.amount > max ? item.amount : max,
    );
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SectionTitle(title, subtitle: subtitle),
            const SizedBox(height: 12),
            if (visible.isEmpty)
              Text(
                emptyMessage,
                style: const TextStyle(color: MizanTheme.muted),
              )
            else
              for (final item in visible) ...[
                InkWell(
                  onTap: item.onTap,
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          children: [
                            Icon(item.icon, size: 19, color: MizanTheme.blue),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                item.label,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                            Text(
                              money(item.amount),
                              style: const TextStyle(
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            if (item.onTap != null)
                              const Icon(Icons.chevron_right, size: 20),
                          ],
                        ),
                        const SizedBox(height: 7),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(99),
                          child: LinearProgressIndicator(
                            minHeight: 7,
                            value: maxAmount <= 0 ? 0 : item.amount / maxAmount,
                            backgroundColor: MizanTheme.surface,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
          ],
        ),
      ),
    );
  }
}

String _reportTypeLabel(RecordType type) => switch (type) {
  RecordType.debt => 'Banka borçları',
  RecordType.personalDebt => 'Kişisel ve kurumsal borçlar',
  RecordType.bill => 'Faturalar',
  RecordType.subscription => 'Abonelikler',
  RecordType.rent => 'Kira ve taksitler',
};

IconData _recordIcon(RecordType type) => switch (type) {
  RecordType.debt => Icons.account_balance_outlined,
  RecordType.personalDebt => Icons.handshake_outlined,
  RecordType.bill => Icons.receipt_long_outlined,
  RecordType.subscription => Icons.autorenew_outlined,
  RecordType.rent => Icons.home_work_outlined,
};
