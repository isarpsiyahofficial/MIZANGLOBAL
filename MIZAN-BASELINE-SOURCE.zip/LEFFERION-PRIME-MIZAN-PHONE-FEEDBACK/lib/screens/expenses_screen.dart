import 'package:flutter/material.dart';

import '../controllers/mizan_controller.dart';
import '../core/formatters.dart';
import '../core/theme.dart';
import '../models/mizan_models.dart';
import '../widgets/mizan_cards.dart';

enum _ExpensePeriod { thisMonth, days30, days90, all }

extension on _ExpensePeriod {
  String get label => switch (this) {
    _ExpensePeriod.thisMonth => 'Bu ay',
    _ExpensePeriod.days30 => 'Son 30 gün',
    _ExpensePeriod.days90 => 'Son 90 gün',
    _ExpensePeriod.all => 'Tümü',
  };
}

class ExpensesScreen extends StatefulWidget {
  const ExpensesScreen({required this.controller, super.key});

  final MizanController controller;

  @override
  State<ExpensesScreen> createState() => _ExpensesScreenState();
}

class _ExpensesScreenState extends State<ExpensesScreen> {
  String? selectedCategoryId;
  _ExpensePeriod period = _ExpensePeriod.thisMonth;

  @override
  Widget build(BuildContext context) {
    final state = widget.controller.state;
    if (selectedCategoryId != null &&
        !state.expenseCategories.any((item) => item.id == selectedCategoryId)) {
      selectedCategoryId = null;
    }
    final now = DateTime.now();
    final visible =
        state.expenses
            .where((item) {
              if (selectedCategoryId != null &&
                  item.categoryId != selectedCategoryId) {
                return false;
              }
              return switch (period) {
                _ExpensePeriod.thisMonth => isSameMonth(item.spentAt, now),
                _ExpensePeriod.days30 => !item.spentAt.isBefore(
                  dateOnly(now).subtract(const Duration(days: 29)),
                ),
                _ExpensePeriod.days90 => !item.spentAt.isBefore(
                  dateOnly(now).subtract(const Duration(days: 89)),
                ),
                _ExpensePeriod.all => true,
              };
            })
            .toList(growable: false)
          ..sort((a, b) => b.spentAt.compareTo(a.spentAt));
    final visibleTotal = visible.fold<double>(
      0.0,
      (sum, item) => sum + item.totalAmount,
    );
    final padding = MediaQuery.sizeOf(context).width < 380 ? 12.0 : 18.0;

    return ListView(
      key: const PageStorageKey('expenses'),
      padding: EdgeInsets.fromLTRB(padding, 18, padding, 110),
      children: [
        PageHeader(
          title: 'Giderler',
          subtitle:
              'Günlük harcamalar borç ve ödeme kayıtlarından bağımsız tutulur.',
          action: FilledButton.icon(
            onPressed: () => _showExpenseForm(context),
            icon: const Icon(Icons.add_shopping_cart_outlined),
            label: const Text('Gider ekle'),
          ),
        ),
        const SizedBox(height: 18),
        AdaptiveGrid(
          minTileWidth: 175,
          children: [
            MetricCard(
              label: 'Bugün',
              value: money(state.expenseTotalForDay(now)),
              color: MizanTheme.green,
              icon: Icons.today_outlined,
            ),
            MetricCard(
              label: 'Bu ay',
              value: money(state.expenseTotalForMonth(now)),
              color: MizanTheme.blue,
              icon: Icons.calendar_month_outlined,
            ),
            MetricCard(
              label: '${period.label} görünümü',
              value: money(visibleTotal),
              icon: Icons.filter_alt_outlined,
            ),
          ],
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SectionTitle(
                  'Kategoriler',
                  subtitle:
                      'Bir kategori seçildiğinde yalnız o kategoriye ait harcamalar görünür.',
                  action: TextButton.icon(
                    onPressed: () => _showCategoryManager(context),
                    icon: const Icon(Icons.tune_outlined),
                    label: const Text('Yönet'),
                  ),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    ChoiceChip(
                      selected: selectedCategoryId == null,
                      label: const Text('Tüm kategoriler'),
                      onSelected: (_) =>
                          setState(() => selectedCategoryId = null),
                    ),
                    for (final category in state.expenseCategories)
                      ChoiceChip(
                        selected: selectedCategoryId == category.id,
                        label: Text(category.name),
                        onSelected: (_) =>
                            setState(() => selectedCategoryId = category.id),
                      ),
                    ActionChip(
                      avatar: const Icon(Icons.add, size: 18),
                      label: const Text('Kategori ekle'),
                      onPressed: () => _showCategoryForm(context),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                const Divider(height: 1),
                const SizedBox(height: 14),
                const Text(
                  'Tarih aralığı',
                  style: TextStyle(fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 4),
                Text(
                  'Gösterilen gider dönemi: ${period.label}',
                  style: const TextStyle(color: MizanTheme.muted),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final item in _ExpensePeriod.values)
                      ChoiceChip(
                        selected: period == item,
                        label: Text(item.label),
                        onSelected: (_) => setState(() => period = item),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        SectionTitle(
          'Harcamalar',
          subtitle: '${visible.length} kayıt · ${money(visibleTotal)}',
        ),
        const SizedBox(height: 10),
        if (state.expenseCategories.isEmpty)
          EmptyState(
            title: 'Önce kategori ekleyin',
            message:
                'Market, ulaşım veya kullanıcıya özel başka bir kategori ekledikten sonra gider kaydı oluşturabilirsiniz.',
            action: FilledButton.icon(
              onPressed: () => _showCategoryForm(context),
              icon: const Icon(Icons.add),
              label: const Text('Kategori ekle'),
            ),
          )
        else if (visible.isEmpty)
          EmptyState(
            title: 'Bu görünümde gider yok',
            message: 'Seçili kategori ve tarih aralığında kayıt bulunmuyor.',
            action: FilledButton.icon(
              onPressed: () => _showExpenseForm(context),
              icon: const Icon(Icons.add),
              label: const Text('Gider ekle'),
            ),
          )
        else
          for (final item in visible) ...[
            _ExpenseCard(
              item: item,
              category: state.expenseCategories.firstWhere(
                (category) => category.id == item.categoryId,
              ),
              onEdit: () => _showExpenseForm(context, item: item),
              onDelete: () => _confirmDeleteExpense(context, item),
            ),
            const SizedBox(height: 8),
          ],
      ],
    );
  }

  Future<void> _showCategoryManager(BuildContext context) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (sheetContext) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
        child: AnimatedBuilder(
          animation: widget.controller,
          builder: (context, child) {
            final categories = widget.controller.state.expenseCategories;
            return SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'Gider kategorileri',
                    style: Theme.of(sheetContext).textTheme.headlineSmall
                        ?.copyWith(fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Kategori silinirse yalnız o kategoriye bağlı giderler açık onayla silinir.',
                    style: TextStyle(color: MizanTheme.muted),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: () => _showCategoryForm(sheetContext),
                    icon: const Icon(Icons.add),
                    label: const Text('Kategori ekle'),
                  ),
                  const SizedBox(height: 10),
                  for (final category in categories)
                    ListTile(
                      title: Text(category.name),
                      subtitle: Text(
                        '${widget.controller.state.expensesForCategory(category.id).length} gider · ${money(widget.controller.state.expenseTotalForCategory(category.id))}',
                      ),
                      trailing: PopupMenuButton<String>(
                        onSelected: (value) async {
                          if (value == 'edit') {
                            await _showCategoryForm(
                              sheetContext,
                              category: category,
                            );
                          } else if (value == 'delete') {
                            await _showDeleteCategory(sheetContext, category);
                          }
                        },
                        itemBuilder: (_) => const [
                          PopupMenuItem(value: 'edit', child: Text('Düzenle')),
                          PopupMenuItem(value: 'delete', child: Text('Sil')),
                        ],
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Future<void> _showCategoryForm(
    BuildContext context, {
    ExpenseCategory? category,
  }) async {
    final key = GlobalKey<FormState>();
    final name = TextEditingController(text: category?.name ?? '');
    try {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: Text(
            category == null ? 'Kategori ekle' : 'Kategoriyi düzenle',
          ),
          content: Form(
            key: key,
            child: TextFormField(
              controller: name,
              autofocus: true,
              maxLength: 60,
              decoration: const InputDecoration(labelText: 'Kategori adı'),
              validator: (value) => value == null || value.trim().isEmpty
                  ? 'Kategori adı boş bırakılamaz.'
                  : null,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Vazgeç'),
            ),
            FilledButton(
              onPressed: () async {
                if (!(key.currentState?.validate() ?? false)) return;
                if (category == null) {
                  await widget.controller.addExpenseCategory(name.text);
                } else {
                  await widget.controller.renameExpenseCategory(
                    categoryId: category.id,
                    name: name.text,
                  );
                }
                if (dialogContext.mounted) Navigator.pop(dialogContext);
              },
              child: const Text('Kaydet'),
            ),
          ],
        ),
      );
    } finally {
      await Future<void>.delayed(kThemeAnimationDuration);
      name.dispose();
    }
  }

  Future<void> _showDeleteCategory(
    BuildContext context,
    ExpenseCategory category,
  ) async {
    final key = GlobalKey<FormState>();
    final confirmation = TextEditingController();
    try {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Kategoriyi sil'),
          content: Form(
            key: key,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  '${category.name} kategorisi ve yalnız bu kategoriye bağlı giderler silinecek.',
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: confirmation,
                  decoration: const InputDecoration(
                    labelText: 'ONAYLIYORUM yazın',
                  ),
                  validator: (value) => value?.trim() == 'ONAYLIYORUM'
                      ? null
                      : 'Tam olarak ONAYLIYORUM yazılmalı.',
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Vazgeç'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: MizanTheme.red),
              onPressed: () async {
                if (!(key.currentState?.validate() ?? false)) return;
                await widget.controller.deleteExpenseCategory(
                  categoryId: category.id,
                  confirmation: confirmation.text,
                );
                if (dialogContext.mounted) Navigator.pop(dialogContext);
              },
              child: const Text('Kategoriyi sil'),
            ),
          ],
        ),
      );
    } finally {
      await Future<void>.delayed(kThemeAnimationDuration);
      confirmation.dispose();
    }
  }

  Future<void> _showExpenseForm(
    BuildContext context, {
    ExpenseItem? item,
  }) async {
    final categories = widget.controller.state.expenseCategories;
    if (categories.isEmpty) {
      await _showCategoryForm(context);
      if (!context.mounted) {
        return;
      }
      if (widget.controller.state.expenseCategories.isEmpty) {
        return;
      }
    }
    final currentCategories = widget.controller.state.expenseCategories;
    final key = GlobalKey<FormState>();
    var categoryId =
        item?.categoryId ?? selectedCategoryId ?? currentCategories.first.id;
    var spentAt = item?.spentAt ?? dateOnly(DateTime.now());
    final name = TextEditingController(text: item?.name ?? '');
    final quantity = TextEditingController(
      text: item == null ? '1' : decimalText(item.quantity),
    );
    final unitPrice = TextEditingController(
      text: item == null ? '' : decimalText(item.unitPrice),
    );
    final note = TextEditingController(text: item?.note ?? '');
    try {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => StatefulBuilder(
          builder: (dialogContext, setDialogState) => AlertDialog(
            title: Text(item == null ? 'Gider ekle' : 'Gideri düzenle'),
            content: ConstrainedBox(
              constraints: BoxConstraints(
                maxWidth: 560,
                maxHeight: MediaQuery.sizeOf(dialogContext).height * .72,
              ),
              child: Form(
                key: key,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      DropdownButtonFormField<String>(
                        initialValue: categoryId,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'Kategori',
                        ),
                        items: [
                          for (final category in currentCategories)
                            DropdownMenuItem(
                              value: category.id,
                              child: Text(category.name),
                            ),
                        ],
                        onChanged: (value) => setDialogState(
                          () => categoryId = value ?? categoryId,
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: name,
                        maxLength: 100,
                        decoration: const InputDecoration(
                          labelText: 'Gider adı',
                        ),
                        validator: (value) =>
                            value == null || value.trim().isEmpty
                            ? 'Gider adı boş bırakılamaz.'
                            : null,
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: quantity,
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        decoration: const InputDecoration(
                          labelText: 'Adet / miktar',
                        ),
                        validator: (value) {
                          try {
                            parsePositiveDecimal(
                              value ?? '',
                              fieldName: 'Adet',
                            );
                            return null;
                          } on FormatException catch (error) {
                            return error.message;
                          }
                        },
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: unitPrice,
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        decoration: const InputDecoration(
                          labelText: 'Birim fiyat',
                        ),
                        validator: (value) {
                          try {
                            if (parseMoney(value ?? '') < 0) {
                              return 'Birim fiyat negatif olamaz.';
                            }
                            return null;
                          } on FormatException catch (error) {
                            return error.message;
                          }
                        },
                      ),
                      const SizedBox(height: 12),
                      OutlinedButton.icon(
                        onPressed: () async {
                          final selected = await showDatePicker(
                            context: dialogContext,
                            initialDate: spentAt,
                            firstDate: DateTime(2000),
                            lastDate: DateTime(2100),
                          );
                          if (selected != null) {
                            setDialogState(() => spentAt = selected);
                          }
                        },
                        icon: const Icon(Icons.calendar_today_outlined),
                        label: Text('Tarih: ${shortDate(spentAt)}'),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: note,
                        maxLength: 240,
                        minLines: 2,
                        maxLines: 5,
                        decoration: const InputDecoration(labelText: 'Not'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext),
                child: const Text('Vazgeç'),
              ),
              FilledButton(
                onPressed: () async {
                  if (!(key.currentState?.validate() ?? false)) return;
                  if (item == null) {
                    await widget.controller.addExpense(
                      categoryId: categoryId,
                      name: name.text,
                      quantity: parsePositiveDecimal(quantity.text),
                      unitPrice: parseMoney(unitPrice.text),
                      spentAt: spentAt,
                      note: note.text,
                    );
                  } else {
                    await widget.controller.updateExpense(
                      expenseId: item.id,
                      categoryId: categoryId,
                      name: name.text,
                      quantity: parsePositiveDecimal(quantity.text),
                      unitPrice: parseMoney(unitPrice.text),
                      spentAt: spentAt,
                      note: note.text,
                    );
                  }
                  if (dialogContext.mounted) Navigator.pop(dialogContext);
                },
                child: const Text('Kaydet'),
              ),
            ],
          ),
        ),
      );
    } finally {
      await Future<void>.delayed(kThemeAnimationDuration);
      name.dispose();
      quantity.dispose();
      unitPrice.dispose();
      note.dispose();
    }
  }

  Future<void> _confirmDeleteExpense(
    BuildContext context,
    ExpenseItem item,
  ) async {
    final accepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Gideri sil'),
        content: Text('${item.name} gider kaydı silinsin mi?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: MizanTheme.red),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Sil'),
          ),
        ],
      ),
    );
    if (accepted == true) await widget.controller.deleteExpense(item.id);
  }
}

class _ExpenseCard extends StatelessWidget {
  const _ExpenseCard({
    required this.item,
    required this.category,
    required this.onEdit,
    required this.onDelete,
  });

  final ExpenseItem item;
  final ExpenseCategory category;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) => MizanListCard(
    title: item.name,
    subtitle:
        '${category.name} · ${shortDate(item.spentAt)}\n${decimalText(item.quantity)} × ${money(item.unitPrice)}${item.note.isEmpty ? '' : ' · ${item.note}'}',
    leadingColor: Color(category.colorValue),
    icon: Icons.shopping_bag_outlined,
    trailing: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          money(item.totalAmount),
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
        PopupMenuButton<String>(
          onSelected: (value) => value == 'edit' ? onEdit() : onDelete(),
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'edit', child: Text('Düzenle')),
            PopupMenuItem(value: 'delete', child: Text('Sil')),
          ],
        ),
      ],
    ),
    onTap: onEdit,
  );
}
