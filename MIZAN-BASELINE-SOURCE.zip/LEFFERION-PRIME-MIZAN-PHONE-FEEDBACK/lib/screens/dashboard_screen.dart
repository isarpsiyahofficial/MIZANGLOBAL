import 'package:flutter/material.dart';

import '../controllers/mizan_controller.dart';
import '../core/formatters.dart';
import '../core/theme.dart';
import '../models/mizan_models.dart';
import '../widgets/mizan_cards.dart';
import 'people_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({required this.controller, super.key});

  final MizanController controller;

  @override
  Widget build(BuildContext context) {
    final state = controller.state;
    final now = DateTime.now();
    final records = state.recordReferencesAt(now)
      ..sort((a, b) => a.dueDate.compareTo(b.dueDate));
    final critical = records
        .where(
          (item) =>
              item.amount > 0 &&
              item.status != PaymentStatus.completed &&
              item.status != PaymentStatus.passive &&
              calendarDaysBetween(now, item.dueDate) <= 7,
        )
        .take(8)
        .toList(growable: false);
    final padding = MediaQuery.sizeOf(context).width < 380 ? 12.0 : 18.0;

    return ListView(
      key: const PageStorageKey('dashboard'),
      padding: EdgeInsets.fromLTRB(padding, 18, padding, 110),
      children: [
        const PageHeader(
          title: 'LEFFERION PRIME - MİZAN',
          subtitle:
              'Borç, ödeme ve giderlerin sade özeti. Detay görmek için kartlara dokunabilirsin.',
        ),
        const SizedBox(height: 18),
        AdaptiveGrid(
          minTileWidth: 185,
          children: [
            MetricCard(
              label: 'Kalan toplam borç',
              value: money(state.totalDebt),
              icon: Icons.account_balance_wallet_outlined,
              onTap: () => _showDebtBreakdown(context, state),
            ),
            MetricCard(
              label: 'Bu ay planlanan',
              value: money(state.monthlyDebtLoadFor(now)),
              color: MizanTheme.blue,
              icon: Icons.calendar_month_outlined,
              onTap: () => _showRecordList(
                context,
                title: 'Bu ay planlanan ödemeler',
                records: records
                    .where((item) => isSameMonth(item.dueDate, now))
                    .toList(growable: false),
              ),
            ),
            MetricCard(
              label: 'Gecikmiş toplam',
              value: money(state.overdueTotalAt(now)),
              color: MizanTheme.red,
              icon: Icons.warning_amber_rounded,
              onTap: () => _showRecordList(
                context,
                title: 'Gecikmiş ödemeler',
                records: records
                    .where((item) => item.status == PaymentStatus.overdue)
                    .toList(growable: false),
              ),
            ),
            MetricCard(
              label: 'Önümüzdeki 7 gün',
              value: money(state.dueWithinDaysTotal(now, 7)),
              color: MizanTheme.orange,
              icon: Icons.upcoming_outlined,
              onTap: () => _showRecordList(
                context,
                title: 'Önümüzdeki 7 gün',
                records: records
                    .where((item) {
                      final days = calendarDaysBetween(now, item.dueDate);
                      return days >= 0 && days <= 7 && item.amount > 0;
                    })
                    .toList(growable: false),
              ),
            ),
            MetricCard(
              label: 'Bugünkü gider',
              value: money(state.expenseTotalForDay(now)),
              color: MizanTheme.green,
              icon: Icons.shopping_bag_outlined,
            ),
            MetricCard(
              label: 'Bu ay gider',
              value: money(state.expenseTotalForMonth(now)),
              color: MizanTheme.green,
              icon: Icons.receipt_outlined,
            ),
          ],
        ),
        const SizedBox(height: 18),
        const SectionTitle(
          'Kritik ödemeler',
          subtitle:
              'Gecikmiş veya yedi gün içinde vadesi gelen kayıtlar. Ayrıntı için satıra dokun.',
        ),
        const SizedBox(height: 10),
        if (critical.isEmpty)
          const EmptyState(
            title: 'Kritik ödeme yok',
            message:
                'Gecikmiş veya önümüzdeki yedi gün içinde vadesi gelen kayıt bulunmuyor.',
          )
        else
          for (final record in critical) ...[
            MizanListCard(
              title: record.title,
              subtitle:
                  '${record.type.label} · ${record.subtitle}\n${_dueText(record, now)} · ${money(record.amount)}',
              leadingColor: statusColor(record.status),
              icon: _recordIcon(record.type),
              trailing: StatusChip(status: record.status),
              onTap: () => showRecordDetails(
                context: context,
                controller: controller,
                personId: record.personId,
                type: record.type,
                sourceId: record.sourceId,
                bankId: record.bankId,
              ),
            ),
            const SizedBox(height: 8),
          ],
        if (state.people.isEmpty) ...[
          const SizedBox(height: 18),
          const EmptyState(
            title: 'Uygulama boş ve kullanıma hazır',
            message:
                'Örnek ödeme veya borç oluşturulmadı. Kayıtlar bölümünden ilk kişiyi ekleyerek başlayabilirsin.',
          ),
        ],
      ],
    );
  }

  Future<void> _showDebtBreakdown(
    BuildContext context,
    MizanState state,
  ) async {
    final now = DateTime.now();
    final groups = <({String title, double amount, RecordType? type})>[
      (
        title: 'Banka borçları',
        amount: state.bankDebtTotal,
        type: RecordType.debt,
      ),
      (
        title: 'Kişisel ve kurumsal borçlar',
        amount: state.personalCorporateDebtTotal,
        type: RecordType.personalDebt,
      ),
      (title: 'Faturalar', amount: state.billTotal, type: RecordType.bill),
      (
        title: 'Abonelikler',
        amount: state.subscriptionTotal,
        type: RecordType.subscription,
      ),
      (
        title: 'Kira ve taksitler',
        amount: state.rentInstallmentTotal,
        type: RecordType.rent,
      ),
      (title: 'Gecikmiş toplam', amount: state.overdueTotalAt(now), type: null),
      (
        title: 'Önümüzdeki 7 gün',
        amount: state.dueWithinDaysTotal(now, 7),
        type: null,
      ),
    ];
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (sheetContext) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Kalan toplam borç detayı',
                style: Theme.of(sheetContext).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'Her bölümün toplamı ayrı hesaplanır. Satıra dokunarak yalnız ilgili kayıtları görebilirsin.',
                style: TextStyle(color: MizanTheme.muted),
              ),
              const SizedBox(height: 14),
              for (final group in groups) ...[
                MizanListCard(
                  title: group.title,
                  subtitle: money(group.amount),
                  leadingColor: group.amount > 0
                      ? MizanTheme.blue
                      : MizanTheme.muted,
                  icon: group.type == null
                      ? Icons.summarize_outlined
                      : _recordIcon(group.type!),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () async {
                    final records = state
                        .recordReferencesAt(now)
                        .where((item) {
                          if (group.type != null) {
                            return item.type == group.type;
                          }
                          if (group.title == 'Gecikmiş toplam') {
                            return item.status == PaymentStatus.overdue;
                          }
                          final days = calendarDaysBetween(now, item.dueDate);
                          return days >= 0 && days <= 7 && item.amount > 0;
                        })
                        .toList(growable: false);
                    Navigator.pop(sheetContext);
                    await _showRecordList(
                      context,
                      title: group.title,
                      records: records,
                    );
                  },
                ),
                const SizedBox(height: 8),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showRecordList(
    BuildContext context, {
    required String title,
    required List<RecordReference> records,
  }) {
    final sorted = [...records]..sort((a, b) => a.dueDate.compareTo(b.dueDate));
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (sheetContext) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: .78,
        minChildSize: .45,
        maxChildSize: .95,
        builder: (_, scrollController) => ListView(
          controller: scrollController,
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
          children: [
            Text(
              title,
              style: Theme.of(
                sheetContext,
              ).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 12),
            if (sorted.isEmpty)
              const EmptyState(
                title: 'Kayıt bulunmuyor',
                message: 'Bu başlığa ait açık ödeme kaydı yok.',
              )
            else
              for (final record in sorted) ...[
                MizanListCard(
                  title: record.title,
                  subtitle:
                      '${record.subtitle}\n${shortDate(record.dueDate)} · ${money(record.amount)}',
                  leadingColor: statusColor(record.status),
                  icon: _recordIcon(record.type),
                  trailing: StatusChip(status: record.status),
                  onTap: () async {
                    Navigator.pop(sheetContext);
                    await showRecordDetails(
                      context: context,
                      controller: controller,
                      personId: record.personId,
                      type: record.type,
                      sourceId: record.sourceId,
                      bankId: record.bankId,
                    );
                  },
                ),
                const SizedBox(height: 8),
              ],
          ],
        ),
      ),
    );
  }
}

String _dueText(RecordReference record, DateTime now) {
  final days = calendarDaysBetween(now, record.dueDate);
  if (days < 0) return '${days.abs()} gün gecikti';
  if (days == 0) return 'Son ödeme bugün';
  return '$days gün kaldı';
}

IconData _recordIcon(RecordType type) => switch (type) {
  RecordType.debt => Icons.account_balance_outlined,
  RecordType.personalDebt => Icons.handshake_outlined,
  RecordType.bill => Icons.receipt_long_outlined,
  RecordType.subscription => Icons.autorenew_outlined,
  RecordType.rent => Icons.home_work_outlined,
};
