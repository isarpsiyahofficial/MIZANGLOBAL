import 'package:flutter/material.dart';

import '../controllers/mizan_controller.dart';
import '../core/formatters.dart';
import '../core/theme.dart';
import '../models/mizan_models.dart';
import '../widgets/mizan_cards.dart';
import '../widgets/record_notes_panel.dart';
import 'record_form_dialogs.dart';

class PeopleScreen extends StatefulWidget {
  const PeopleScreen({required this.controller, super.key});

  final MizanController controller;

  @override
  State<PeopleScreen> createState() => _PeopleScreenState();
}

class _PeopleScreenState extends State<PeopleScreen> {
  String? selectedPersonId;
  bool includeArchived = false;

  @override
  Widget build(BuildContext context) {
    final state = widget.controller.state;
    if (state.people.isNotEmpty &&
        !state.people.any((item) => item.id == selectedPersonId)) {
      selectedPersonId = state.people.first.id;
    }
    final selected = selectedPersonId == null
        ? null
        : state.people.where((item) => item.id == selectedPersonId).firstOrNull;
    final padding = MediaQuery.sizeOf(context).width < 380 ? 12.0 : 18.0;

    return ListView(
      key: const PageStorageKey('records'),
      padding: EdgeInsets.fromLTRB(padding, 18, padding, 110),
      children: [
        PageHeader(
          title: 'Kayıtlar',
          subtitle:
              'Önce kişiyi seç, ardından kayıt türünü aç. Her bölüm birbirinden bağımsız tutulur.',
          action: FilledButton.icon(
            onPressed: () =>
                showPersonForm(context: context, controller: widget.controller),
            icon: const Icon(Icons.person_add_alt_1_outlined),
            label: const Text('Kişi ekle'),
          ),
        ),
        const SizedBox(height: 18),
        if (state.people.isEmpty)
          EmptyState(
            title: 'Henüz kişi yok',
            message:
                'Kayıtların birbirine karışmaması için önce ödeme ve gider kayıtlarının sahibi olacak kişiyi ekleyin.',
            action: FilledButton.icon(
              onPressed: () => showPersonForm(
                context: context,
                controller: widget.controller,
              ),
              icon: const Icon(Icons.person_add_alt_1_outlined),
              label: const Text('İlk kişiyi ekle'),
            ),
          )
        else ...[
          _PersonSelector(
            controller: widget.controller,
            people: state.people,
            selected: selected!,
            includeArchived: includeArchived,
            onPersonChanged: (value) =>
                setState(() => selectedPersonId = value),
            onArchivedChanged: (value) =>
                setState(() => includeArchived = value),
          ),
          const SizedBox(height: 16),
          _BankDebtGroup(
            controller: widget.controller,
            person: selected,
            includeArchived: includeArchived,
          ),
          const SizedBox(height: 12),
          _SimpleRecordGroup(
            title: 'Kişisel ve Kurumsal Borçlar',
            subtitle:
                'Kişi, şirket/kurum, çek, senet, esnaf/işletme, aile/yakın ve diğer alacaklılar',
            icon: Icons.handshake_outlined,
            total: selected.personalDebts
                .where((item) => !item.isArchived)
                .fold<double>(0.0, (sum, item) => sum + item.remainingAmount),
            count: selected.personalDebts.length,
            onAdd: () => showPersonalDebtForm(
              context: context,
              controller: widget.controller,
              person: selected,
            ),
            addLabel: 'Kişisel / kurumsal borç ekle',
            emptyMessage: 'Banka dışı borç kaydı bulunmuyor.',
            children: [
              for (final debt in selected.personalDebts.where(
                (item) => includeArchived || !item.isArchived,
              ))
                MizanListCard(
                  title: debt.title,
                  subtitle:
                      '${debt.creditorType.label} · ${debt.displayCreditor}\nKalan ${money(debt.remainingAmount)} · Vade ${shortDate(debt.effectiveDueDate)}',
                  leadingColor: statusColor(debt.status),
                  icon: _creditorIcon(debt.creditorType),
                  trailing: StatusChip(status: debt.status),
                  onTap: () => showRecordDetails(
                    context: context,
                    controller: widget.controller,
                    personId: selected.id,
                    type: RecordType.personalDebt,
                    sourceId: debt.id,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          _SimpleRecordGroup(
            title: 'Faturalar',
            subtitle:
                'Elektrik, su, telefon, internet, doğalgaz ve özel faturalar',
            icon: Icons.receipt_long_outlined,
            total: selected.bills
                .where((item) => !item.isArchived)
                .fold<double>(0.0, (sum, item) => sum + item.remainingAmount),
            count: selected.bills.length,
            onAdd: () => showBillForm(
              context: context,
              controller: widget.controller,
              person: selected,
            ),
            addLabel: 'Fatura ekle',
            emptyMessage: 'Fatura kaydı bulunmuyor.',
            children: [
              for (final bill in selected.bills.where(
                (item) => includeArchived || !item.isArchived,
              ))
                MizanListCard(
                  title: '${bill.kind.label} · ${bill.institutionName}',
                  subtitle:
                      'Kalan ${money(bill.remainingAmount)} · Son ödeme ${shortDate(bill.dueDate)}',
                  leadingColor: statusColor(bill.status),
                  icon: Icons.receipt_long_outlined,
                  trailing: StatusChip(status: bill.status),
                  onTap: () => showRecordDetails(
                    context: context,
                    controller: widget.controller,
                    personId: selected.id,
                    type: RecordType.bill,
                    sourceId: bill.id,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          _SimpleRecordGroup(
            title: 'Abonelikler',
            subtitle:
                'Belirli aralıklarla tekrarlayan dijital hizmet, üyelik, sigorta, eğitim ve bakım ödemeleri',
            icon: Icons.autorenew_outlined,
            total: selected.subscriptions
                .where((item) => !item.isArchived)
                .fold<double>(0.0, (sum, item) => sum + item.remainingAmount),
            count: selected.subscriptions.length,
            onAdd: () => showSubscriptionForm(
              context: context,
              controller: widget.controller,
              person: selected,
            ),
            addLabel: 'Abonelik ekle',
            emptyMessage: 'Abonelik kaydı bulunmuyor.',
            children: [
              for (final item in selected.subscriptions.where(
                (item) => includeArchived || !item.isArchived,
              ))
                MizanListCard(
                  title: item.title,
                  subtitle:
                      '${item.providerName} · ${item.frequency.label}\nBu dönem ${money(item.remainingAmount)} · Sıradaki tarih ${shortDate(item.nextDueDate)}',
                  leadingColor: statusColor(item.status),
                  icon: Icons.autorenew_outlined,
                  trailing: StatusChip(status: item.status),
                  onTap: () => showRecordDetails(
                    context: context,
                    controller: widget.controller,
                    personId: selected.id,
                    type: RecordType.subscription,
                    sourceId: item.id,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          _SimpleRecordGroup(
            title: 'Kira ve Taksitler',
            subtitle:
                'Ev/iş yeri kirası, ürün taksiti ve düzenli ödeme planları',
            icon: Icons.home_work_outlined,
            total: selected.rents
                .where((item) => !item.isArchived)
                .fold<double>(0.0, (sum, item) => sum + item.remainingAmount),
            count: selected.rents.length,
            onAdd: () => showRentForm(
              context: context,
              controller: widget.controller,
              person: selected,
            ),
            addLabel: 'Kira / taksit ekle',
            emptyMessage: 'Kira veya taksit kaydı bulunmuyor.',
            children: [
              for (final rent in selected.rents.where(
                (item) => includeArchived || !item.isArchived,
              ))
                MizanListCard(
                  title: rent.title,
                  subtitle:
                      '${rent.receiverName} · Kalan ${money(rent.remainingAmount)} · Son ödeme ${shortDate(rent.dueDate)}',
                  leadingColor: statusColor(rent.status),
                  icon: Icons.home_work_outlined,
                  trailing: StatusChip(status: rent.status),
                  onTap: () => showRecordDetails(
                    context: context,
                    controller: widget.controller,
                    personId: selected.id,
                    type: RecordType.rent,
                    sourceId: rent.id,
                  ),
                ),
            ],
          ),
        ],
      ],
    );
  }
}

class _PersonSelector extends StatelessWidget {
  const _PersonSelector({
    required this.controller,
    required this.people,
    required this.selected,
    required this.includeArchived,
    required this.onPersonChanged,
    required this.onArchivedChanged,
  });

  final MizanController controller;
  final List<PersonAccount> people;
  final PersonAccount selected;
  final bool includeArchived;
  final ValueChanged<String> onPersonChanged;
  final ValueChanged<bool> onArchivedChanged;

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Kayıt sahibi',
              style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
            ),
            const SizedBox(height: 4),
            const Text(
              'Aşağıdaki bütün kayıtlar yalnızca seçili kişiye aittir.',
              style: TextStyle(color: MizanTheme.muted),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: selected.id,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Kişi seçin',
                prefixIcon: Icon(Icons.person_outline),
              ),
              items: [
                for (final person in people)
                  DropdownMenuItem(value: person.id, child: Text(person.name)),
              ],
              onChanged: (value) {
                if (value != null) onPersonChanged(value);
              },
            ),
            const SizedBox(height: 12),
            AdaptiveGrid(
              minTileWidth: 170,
              children: [
                MetricCard(
                  label: 'Kalan toplam',
                  value: money(selected.totalDebt),
                  icon: Icons.account_balance_wallet_outlined,
                ),
                MetricCard(
                  label: 'Bu ay planlanan',
                  value: money(selected.monthlyLoadFor(now)),
                  color: MizanTheme.blue,
                  icon: Icons.calendar_month_outlined,
                ),
                MetricCard(
                  label: 'Gecikmiş kayıt',
                  value: selected.overdueCountAt(now).toString(),
                  color: MizanTheme.red,
                  icon: Icons.warning_amber_rounded,
                ),
              ],
            ),
            const SizedBox(height: 10),
            FilledButton.tonalIcon(
              onPressed: () => _showPersonDetails(
                context: context,
                controller: controller,
                personId: selected.id,
                includeArchived: includeArchived,
              ),
              icon: const Icon(Icons.manage_accounts_outlined),
              label: const Text('Kişi detaylarını aç'),
            ),
            const SizedBox(height: 6),
            Align(
              alignment: Alignment.centerLeft,
              child: FilterChip(
                selected: includeArchived,
                label: const Text('Arşivdekileri göster'),
                onSelected: onArchivedChanged,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Future<void> _showPersonDetails({
  required BuildContext context,
  required MizanController controller,
  required String personId,
  required bool includeArchived,
}) async {
  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (sheetContext) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: .88,
      minChildSize: .58,
      maxChildSize: .96,
      builder: (_, scrollController) => AnimatedBuilder(
        animation: controller,
        builder: (context, child) {
          final person = controller.state.people
              .where((item) => item.id == personId)
              .firstOrNull;
          if (person == null) {
            return const Center(child: Text('Kişi kaydı bulunamadı.'));
          }
          final now = DateTime.now();
          final records =
              controller.state
                  .recordReferencesAt(now)
                  .where(
                    (item) =>
                        item.personId == person.id &&
                        (includeArchived ||
                            item.status != PaymentStatus.passive),
                  )
                  .toList(growable: false)
                ..sort((a, b) => a.dueDate.compareTo(b.dueDate));
          final summaries =
              <({String label, double amount, int count, IconData icon})>[
                (
                  label: 'Banka borçları',
                  amount: person.banks.fold<double>(
                    0,
                    (sum, bank) => sum + bank.totalDebt,
                  ),
                  count: person.banks
                      .expand((bank) => bank.products)
                      .where((item) => includeArchived || !item.isArchived)
                      .length,
                  icon: Icons.account_balance_outlined,
                ),
                (
                  label: 'Kişisel ve kurumsal borçlar',
                  amount: person.personalDebts
                      .where((item) => !item.isArchived)
                      .fold<double>(
                        0,
                        (sum, item) => sum + item.remainingAmount,
                      ),
                  count: person.personalDebts
                      .where((item) => includeArchived || !item.isArchived)
                      .length,
                  icon: Icons.handshake_outlined,
                ),
                (
                  label: 'Faturalar',
                  amount: person.bills
                      .where((item) => !item.isArchived)
                      .fold<double>(
                        0,
                        (sum, item) => sum + item.remainingAmount,
                      ),
                  count: person.bills
                      .where((item) => includeArchived || !item.isArchived)
                      .length,
                  icon: Icons.receipt_long_outlined,
                ),
                (
                  label: 'Abonelikler',
                  amount: person.subscriptions
                      .where((item) => !item.isArchived)
                      .fold<double>(
                        0,
                        (sum, item) => sum + item.remainingAmount,
                      ),
                  count: person.subscriptions
                      .where((item) => includeArchived || !item.isArchived)
                      .length,
                  icon: Icons.autorenew_outlined,
                ),
                (
                  label: 'Kira ve taksitler',
                  amount: person.rents
                      .where((item) => !item.isArchived)
                      .fold<double>(
                        0,
                        (sum, item) => sum + item.remainingAmount,
                      ),
                  count: person.rents
                      .where((item) => includeArchived || !item.isArchived)
                      .length,
                  icon: Icons.home_work_outlined,
                ),
              ];
          return ListView(
            controller: scrollController,
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const CircleAvatar(child: Icon(Icons.person_outline)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Kişi detayları',
                          style: Theme.of(sheetContext).textTheme.headlineSmall
                              ?.copyWith(fontWeight: FontWeight.w900),
                        ),
                        Text(
                          person.name,
                          style: const TextStyle(
                            color: MizanTheme.muted,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(sheetContext),
                    icon: const Icon(Icons.close),
                    tooltip: 'Kapat',
                  ),
                ],
              ),
              const SizedBox(height: 14),
              for (final summary in summaries) ...[
                MizanListCard(
                  title: summary.label,
                  subtitle:
                      '${summary.count} kayıt · Kalan ${money(summary.amount)}',
                  leadingColor: MizanTheme.blue,
                  icon: summary.icon,
                ),
                const SizedBox(height: 8),
              ],
              const SizedBox(height: 8),
              SectionTitle(
                'Bu kişiye ait kayıtlar',
                subtitle:
                    '${records.length} kayıt · Toplam kalan ${money(person.totalDebt)}',
              ),
              const SizedBox(height: 10),
              if (records.isEmpty)
                const EmptyState(
                  title: 'Kayıt bulunmuyor',
                  message: 'Bu kişiye bağlı açık ödeme kaydı yok.',
                )
              else
                for (final record in records) ...[
                  MizanListCard(
                    title: record.title,
                    subtitle:
                        '${record.type.label} · ${record.subtitle}\n${shortDate(record.dueDate)} · Bu vade ${money(record.amount)}',
                    leadingColor: statusColor(record.status),
                    icon: _recordTypeIcon(record.type),
                    trailing: StatusChip(status: record.status),
                    onTap: () async {
                      Navigator.pop(sheetContext);
                      await showRecordDetails(
                        context: context,
                        controller: controller,
                        personId: record.personId,
                        type: record.type,
                        sourceId: record.sourceId,
                        bankId: record.bankId,
                      );
                    },
                  ),
                  const SizedBox(height: 8),
                ],
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () async {
                  Navigator.pop(sheetContext);
                  await showPersonForm(
                    context: context,
                    controller: controller,
                    person: person,
                  );
                },
                icon: const Icon(Icons.edit_outlined),
                label: const Text('Kişiyi düzenle'),
              ),
              const SizedBox(height: 8),
              TextButton.icon(
                style: TextButton.styleFrom(foregroundColor: MizanTheme.red),
                onPressed: () async {
                  Navigator.pop(sheetContext);
                  await _confirmDeletePerson(context, controller, person);
                },
                icon: const Icon(Icons.delete_outline),
                label: const Text('Kişiyi sil'),
              ),
            ],
          );
        },
      ),
    ),
  );
}

IconData _recordTypeIcon(RecordType type) => switch (type) {
  RecordType.debt => Icons.account_balance_outlined,
  RecordType.personalDebt => Icons.handshake_outlined,
  RecordType.bill => Icons.receipt_long_outlined,
  RecordType.subscription => Icons.autorenew_outlined,
  RecordType.rent => Icons.home_work_outlined,
};

class _BankDebtGroup extends StatelessWidget {
  const _BankDebtGroup({
    required this.controller,
    required this.person,
    required this.includeArchived,
  });

  final MizanController controller;
  final PersonAccount person;
  final bool includeArchived;

  @override
  Widget build(BuildContext context) {
    final total = person.banks.fold<double>(
      0.0,
      (sum, bank) => sum + bank.totalDebt,
    );
    return Card(
      child: ExpansionTile(
        key: PageStorageKey('bank-debts-${person.id}'),
        initiallyExpanded: true,
        leading: const Icon(Icons.account_balance_outlined),
        title: const Text(
          'Banka Borçları',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        subtitle: Text(
          '${person.banks.length} banka grubu · Kalan ${money(total)}',
        ),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: FilledButton.tonalIcon(
              onPressed: () => showBankForm(
                context: context,
                controller: controller,
                person: person,
              ),
              icon: const Icon(Icons.add),
              label: const Text('Banka grubu ekle'),
            ),
          ),
          const SizedBox(height: 10),
          if (person.banks.isEmpty)
            const EmptyState(
              title: 'Banka borcu yok',
              message:
                  'Banka adı kullanıcı tarafından yazılır. Hazır banka markası veya logosu kullanılmaz.',
            )
          else
            for (final bank in person.banks) ...[
              _BankCard(
                controller: controller,
                person: person,
                bank: bank,
                includeArchived: includeArchived,
              ),
              const SizedBox(height: 8),
            ],
        ],
      ),
    );
  }
}

class _BankCard extends StatelessWidget {
  const _BankCard({
    required this.controller,
    required this.person,
    required this.bank,
    required this.includeArchived,
  });

  final MizanController controller;
  final PersonAccount person;
  final BankGroup bank;
  final bool includeArchived;

  @override
  Widget build(BuildContext context) {
    final products = bank.products
        .where((item) => includeArchived || !item.isArchived)
        .toList(growable: false);
    return Material(
      color: MizanTheme.surface,
      borderRadius: BorderRadius.circular(16),
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        key: PageStorageKey('bank-${bank.id}'),
        title: Text(
          bank.userWrittenName,
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
        subtitle: Text(
          '${bank.products.length} kayıt · Kalan ${money(bank.totalDebt)}',
        ),
        trailing: PopupMenuButton<String>(
          tooltip: 'Banka grubu işlemleri',
          onSelected: (value) async {
            if (value == 'add') {
              await showDebtForm(
                context: context,
                controller: controller,
                person: person,
                bank: bank,
              );
            } else if (value == 'edit') {
              await showBankForm(
                context: context,
                controller: controller,
                person: person,
                bank: bank,
              );
            } else if (value == 'delete') {
              await _confirmAction(
                context,
                title: 'Banka grubunu sil',
                message:
                    '${bank.userWrittenName} ve altındaki tüm borç kayıtları silinecek.',
                confirmLabel: 'Grubu sil',
                action: () => controller.deleteBankGroup(
                  personId: person.id,
                  bankId: bank.id,
                ),
              );
            }
          },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'add', child: Text('Borç ekle')),
            PopupMenuItem(value: 'edit', child: Text('Grubu düzenle')),
            PopupMenuItem(value: 'delete', child: Text('Grubu sil')),
          ],
        ),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        children: [
          if (products.isEmpty)
            const Padding(
              padding: EdgeInsets.all(12),
              child: Text(
                'Bu banka grubunda görüntülenecek borç bulunmuyor.',
                style: TextStyle(color: MizanTheme.muted),
              ),
            )
          else
            for (final debt in products) ...[
              MizanListCard(
                title: debt.title,
                subtitle:
                    '${debt.displayKind} · Kalan ${money(debt.remainingAmount)} · Sıradaki ${shortDate(debt.effectiveDueDateAt(DateTime.now()))}',
                leadingColor: statusColor(debt.status),
                icon: Icons.credit_card_outlined,
                trailing: StatusChip(status: debt.status),
                onTap: () => showRecordDetails(
                  context: context,
                  controller: controller,
                  personId: person.id,
                  type: RecordType.debt,
                  sourceId: debt.id,
                  bankId: bank.id,
                ),
              ),
              const SizedBox(height: 6),
            ],
        ],
      ),
    );
  }
}

class _SimpleRecordGroup extends StatelessWidget {
  const _SimpleRecordGroup({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.total,
    required this.count,
    required this.onAdd,
    required this.addLabel,
    required this.emptyMessage,
    required this.children,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final double total;
  final int count;
  final VoidCallback onAdd;
  final String addLabel;
  final String emptyMessage;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ExpansionTile(
        key: PageStorageKey(title),
        leading: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text('$count kayıt · Kalan ${money(total)}'),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              subtitle,
              style: const TextStyle(color: MizanTheme.muted),
            ),
          ),
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerLeft,
            child: FilledButton.tonalIcon(
              onPressed: onAdd,
              icon: const Icon(Icons.add),
              label: Text(addLabel),
            ),
          ),
          const SizedBox(height: 10),
          if (children.isEmpty)
            Padding(
              padding: const EdgeInsets.all(14),
              child: Text(
                emptyMessage,
                style: const TextStyle(color: MizanTheme.muted),
              ),
            )
          else
            for (var index = 0; index < children.length; index++) ...[
              children[index],
              if (index != children.length - 1) const SizedBox(height: 8),
            ],
        ],
      ),
    );
  }
}

Future<void> showRecordDetails({
  required BuildContext context,
  required MizanController controller,
  required String personId,
  required RecordType type,
  required String sourceId,
  String? bankId,
}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (_) => _RecordDetailSheet(
      controller: controller,
      personId: personId,
      type: type,
      sourceId: sourceId,
      bankId: bankId,
    ),
  );
}

class _RecordDetailSheet extends StatelessWidget {
  const _RecordDetailSheet({
    required this.controller,
    required this.personId,
    required this.type,
    required this.sourceId,
    this.bankId,
  });

  final MizanController controller;
  final String personId;
  final RecordType type;
  final String sourceId;
  final String? bankId;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final current = _detailData(
          controller,
          personId,
          type,
          sourceId,
          bankId,
        );
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: .82,
          minChildSize: .55,
          maxChildSize: .96,
          builder: (context, scrollController) => ListView(
            controller: scrollController,
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 32),
            children: [
              Center(
                child: Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.black26,
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          current.title,
                          style: Theme.of(context).textTheme.headlineSmall
                              ?.copyWith(fontWeight: FontWeight.w900),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          current.subtitle,
                          style: const TextStyle(color: MizanTheme.muted),
                        ),
                      ],
                    ),
                  ),
                  StatusChip(status: current.status),
                ],
              ),
              const SizedBox(height: 14),
              AdaptiveGrid(
                minTileWidth: 150,
                children: [
                  MetricCard(
                    label: current.amountLabel,
                    value: money(current.remainingAmount),
                    color: statusColor(current.status),
                  ),
                  MetricCard(
                    label: 'Son ödeme tarihi',
                    value: shortDate(current.dueDate),
                    color: MizanTheme.blue,
                  ),
                  MetricCard(
                    label: 'Toplam ödeme',
                    value: money(current.paidAmount),
                    color: MizanTheme.green,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  FilledButton.icon(
                    onPressed: current.remainingAmount <= 0
                        ? null
                        : () => showPaymentForm(
                            context: context,
                            controller: controller,
                            personId: personId,
                            type: type,
                            sourceId: sourceId,
                            remainingAmount: current.remainingAmount,
                          ),
                    icon: const Icon(Icons.payments_outlined),
                    label: const Text('Ödeme ekle'),
                  ),
                  OutlinedButton.icon(
                    onPressed: () => current.edit(context),
                    icon: const Icon(Icons.edit_outlined),
                    label: const Text('Düzenle'),
                  ),
                  OutlinedButton.icon(
                    onPressed: () => current.setArchived(!current.isArchived),
                    icon: Icon(
                      current.isArchived
                          ? Icons.unarchive_outlined
                          : Icons.archive_outlined,
                    ),
                    label: Text(
                      current.isArchived ? 'Arşivden çıkar' : 'Arşivle',
                    ),
                  ),
                  TextButton.icon(
                    onPressed: () => _confirmDeleteRecord(context, current),
                    icon: const Icon(Icons.delete_outline),
                    label: const Text('Sil'),
                  ),
                ],
              ),
              if (current.description.trim().isNotEmpty) ...[
                const SizedBox(height: 14),
                _InformationCard(
                  title: 'Açıklama',
                  lines: [current.description],
                ),
              ],
              if (current.detailLines.isNotEmpty) ...[
                const SizedBox(height: 12),
                _InformationCard(
                  title: 'Kayıt bilgileri',
                  lines: current.detailLines,
                ),
              ],
              if (current.schedule.isNotEmpty) ...[
                const SizedBox(height: 12),
                _ScheduleCard(items: current.schedule),
              ],
              const SizedBox(height: 14),
              const SectionTitle(
                'Ödeme geçmişi',
                subtitle: 'Yalnızca bu kayda bağlı ödemeler',
              ),
              const SizedBox(height: 8),
              if (current.payments.isEmpty)
                const EmptyState(
                  title: 'Ödeme yok',
                  message: 'Bu kayda henüz ödeme eklenmedi.',
                )
              else
                for (final payment in current.payments) ...[
                  MizanListCard(
                    title: money(payment.amount),
                    subtitle:
                        '${shortDate(payment.paidAt)}${payment.method.isEmpty ? '' : ' · ${payment.method}'}${payment.note.isEmpty ? '' : '\n${payment.note}'}',
                    leadingColor: MizanTheme.green,
                    icon: Icons.check_circle_outline,
                    trailing: PopupMenuButton<String>(
                      onSelected: (value) async {
                        if (value == 'edit') {
                          await showPaymentForm(
                            context: context,
                            controller: controller,
                            personId: personId,
                            type: type,
                            sourceId: sourceId,
                            remainingAmount:
                                current.remainingAmount + payment.amount,
                            payment: payment,
                          );
                        } else if (value == 'delete') {
                          await _confirmAction(
                            context,
                            title: 'Ödemeyi sil',
                            message:
                                '${money(payment.amount)} tutarındaki ödeme yalnızca bu kayıttan silinecek.',
                            confirmLabel: 'Ödemeyi sil',
                            action: () => controller.deletePayment(
                              personId: personId,
                              type: type,
                              sourceId: sourceId,
                              paymentId: payment.id,
                            ),
                          );
                        }
                      },
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'edit', child: Text('Düzenle')),
                        PopupMenuItem(value: 'delete', child: Text('Sil')),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
              const SizedBox(height: 10),
              RecordNotesPanel(
                notes: current.notes,
                onAddNote: (text) => controller.addNote(
                  personId: personId,
                  type: type,
                  sourceId: sourceId,
                  text: text,
                ),
                onDeleteNote: (noteId) => controller.deleteNote(
                  personId: personId,
                  type: type,
                  sourceId: sourceId,
                  noteId: noteId,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _InformationCard extends StatelessWidget {
  const _InformationCard({required this.title, required this.lines});

  final String title;
  final List<String> lines;

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          for (final line in lines)
            Padding(
              padding: const EdgeInsets.only(bottom: 5),
              child: Text(line),
            ),
        ],
      ),
    ),
  );
}

class _ScheduleCard extends StatelessWidget {
  const _ScheduleCard({required this.items});

  final List<DueScheduleItem> items;

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Ödeme planı',
            style: TextStyle(fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),
          for (final item in items)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(
                item.isCompleted
                    ? Icons.check_circle
                    : Icons.calendar_today_outlined,
                color: item.isCompleted ? MizanTheme.green : MizanTheme.blue,
              ),
              title: Text(item.label),
              subtitle: Text(shortDate(item.dueDate)),
              trailing: Text(
                money(item.amount),
                style: const TextStyle(fontWeight: FontWeight.w900),
              ),
            ),
        ],
      ),
    ),
  );
}

class _RecordDetailData {
  const _RecordDetailData({
    required this.title,
    required this.subtitle,
    required this.amountLabel,
    required this.remainingAmount,
    required this.paidAmount,
    required this.dueDate,
    required this.status,
    required this.description,
    required this.detailLines,
    required this.schedule,
    required this.payments,
    required this.notes,
    required this.isArchived,
    required this.edit,
    required this.setArchived,
    required this.delete,
  });

  final String title;
  final String subtitle;
  final String amountLabel;
  final double remainingAmount;
  final double paidAmount;
  final DateTime dueDate;
  final PaymentStatus status;
  final String description;
  final List<String> detailLines;
  final List<DueScheduleItem> schedule;
  final List<PaymentRecord> payments;
  final List<RecordNote> notes;
  final bool isArchived;
  final Future<void> Function(BuildContext context) edit;
  final Future<void> Function(bool archived) setArchived;
  final Future<void> Function() delete;
}

_RecordDetailData _detailData(
  MizanController controller,
  String personId,
  RecordType type,
  String sourceId,
  String? bankId,
) {
  final state = controller.state;
  final person = state.people.firstWhere((item) => item.id == personId);
  switch (type) {
    case RecordType.debt:
      final bank = bankId == null
          ? person.banks.firstWhere(
              (item) => item.products.any((product) => product.id == sourceId),
            )
          : person.banks.firstWhere((item) => item.id == bankId);
      final debt = bank.products.firstWhere((item) => item.id == sourceId);
      return _RecordDetailData(
        title: debt.title,
        subtitle:
            '${person.name} · ${bank.userWrittenName} · ${debt.displayKind}',
        amountLabel: 'Kalan borç',
        remainingAmount: debt.remainingAmount,
        paidAmount: debt.paidAmount,
        dueDate: debt.effectiveDueDateAt(DateTime.now()),
        status: debt.status,
        description: debt.description,
        detailLines: [
          if (debt.monthlyAmount > 0)
            'Aylık tutar: ${money(debt.monthlyAmount)}',
          'Ödeme tarihi: ${debt.dueRuleLabel}',
          if (debt.installmentCount != null)
            'Taksit: ${debt.currentInstallment ?? 1}/${debt.installmentCount}',
          if (debt.limit != null) 'Limit: ${money(debt.limit!)}',
          if (debt.usedLimit != null)
            'Kullanılan limit: ${money(debt.usedLimit!)}',
        ],
        schedule: const [],
        payments: debt.payments,
        notes: debt.notes,
        isArchived: debt.isArchived,
        edit: (context) => showDebtForm(
          context: context,
          controller: controller,
          person: person,
          bank: bank,
          debt: debt,
        ),
        setArchived: (archived) => controller.setDebtArchived(
          personId: person.id,
          bankId: bank.id,
          debtId: debt.id,
          archived: archived,
        ),
        delete: () => controller.deleteDebtProduct(
          personId: person.id,
          bankId: bank.id,
          debtId: debt.id,
        ),
      );
    case RecordType.personalDebt:
      final debt = person.personalDebts.firstWhere(
        (item) => item.id == sourceId,
      );
      return _RecordDetailData(
        title: debt.title,
        subtitle:
            '${person.name} · ${debt.creditorType.label} · ${debt.displayCreditor}',
        amountLabel: 'Kalan borç',
        remainingAmount: debt.remainingAmount,
        paidAmount: debt.paidAmount,
        dueDate: debt.effectiveDueDate,
        status: debt.status,
        description: debt.description,
        detailLines: [
          'Borç tarihi: ${shortDate(debt.debtDate)}',
          'Ödeme sıklığı: ${debt.frequency.label}',
          if (debt.installmentCount != null)
            'Taksit: ${debt.currentInstallment ?? 1}/${debt.installmentCount}',
          if (debt.monthlyAmount > 0)
            'Düzenli ödeme: ${money(debt.monthlyAmount)}',
          if (debt.chequeNumber.isNotEmpty) 'Çek no: ${debt.chequeNumber}',
          if (debt.issuerName.isNotEmpty) 'Düzenleyen: ${debt.issuerName}',
          if (debt.bankInfo.isNotEmpty) 'Banka bilgisi: ${debt.bankInfo}',
          if (debt.promissoryNoteNumber.isNotEmpty)
            'Senet no: ${debt.promissoryNoteNumber}',
          if (debt.documentCount != null)
            'Senet: ${debt.currentDocument ?? 1}/${debt.documentCount}',
        ],
        schedule: debt.resolvedSchedule,
        payments: debt.payments,
        notes: debt.notes,
        isArchived: debt.isArchived,
        edit: (context) => showPersonalDebtForm(
          context: context,
          controller: controller,
          person: person,
          debt: debt,
        ),
        setArchived: (archived) => controller.setPersonalDebtArchived(
          personId: person.id,
          debtId: debt.id,
          archived: archived,
        ),
        delete: () =>
            controller.deletePersonalDebt(personId: person.id, debtId: debt.id),
      );
    case RecordType.bill:
      final bill = person.bills.firstWhere((item) => item.id == sourceId);
      return _RecordDetailData(
        title: bill.kind.label,
        subtitle: '${person.name} · ${bill.institutionName}',
        amountLabel: 'Kalan fatura',
        remainingAmount: bill.remainingAmount,
        paidAmount: bill.paidAmount,
        dueDate: bill.dueDate,
        status: bill.status,
        description: bill.description,
        detailLines: [
          if (bill.subscriberNumber.isNotEmpty)
            'Abone no: ${bill.subscriberNumber}',
          if (bill.contractNumber.isNotEmpty)
            'Sözleşme / tesisat no: ${bill.contractNumber}',
        ],
        schedule: const [],
        payments: bill.payments,
        notes: bill.notes,
        isArchived: bill.isArchived,
        edit: (context) => showBillForm(
          context: context,
          controller: controller,
          person: person,
          bill: bill,
        ),
        setArchived: (archived) => controller.setBillArchived(
          personId: person.id,
          billId: bill.id,
          archived: archived,
        ),
        delete: () =>
            controller.deleteBill(personId: person.id, billId: bill.id),
      );
    case RecordType.subscription:
      final item = person.subscriptions.firstWhere(
        (item) => item.id == sourceId,
      );
      return _RecordDetailData(
        title: item.title,
        subtitle: '${person.name} · ${item.providerName} · ${item.displayKind}',
        amountLabel: 'Bu dönem kalan',
        remainingAmount: item.remainingAmount,
        paidAmount: item.paidAmount,
        dueDate: item.nextDueDate,
        status: item.status,
        description: item.description,
        detailLines: [
          'Tekrar sıklığı: ${item.frequency.label}',
          if (item.subscriberNumber.isNotEmpty)
            'Abone no: ${item.subscriberNumber}',
          if (item.contractNumber.isNotEmpty)
            'Sözleşme no: ${item.contractNumber}',
        ],
        schedule: const [],
        payments: item.payments,
        notes: item.notes,
        isArchived: item.isArchived,
        edit: (context) => showSubscriptionForm(
          context: context,
          controller: controller,
          person: person,
          subscription: item,
        ),
        setArchived: (archived) => controller.setSubscriptionArchived(
          personId: person.id,
          subscriptionId: item.id,
          archived: archived,
        ),
        delete: () => controller.deleteSubscription(
          personId: person.id,
          subscriptionId: item.id,
        ),
      );
    case RecordType.rent:
      final rent = person.rents.firstWhere((item) => item.id == sourceId);
      return _RecordDetailData(
        title: rent.title,
        subtitle: '${person.name} · ${rent.receiverName}',
        amountLabel: 'Kalan tutar',
        remainingAmount: rent.remainingAmount,
        paidAmount: rent.paidAmount,
        dueDate: rent.dueDate,
        status: rent.status,
        description: rent.description,
        detailLines: [
          'Ödeme günü: ${rent.paymentDay}',
          if (rent.iban.isNotEmpty) 'IBAN: ${rent.iban}',
          if (rent.installmentCount != null)
            'Taksit: ${rent.currentInstallment ?? 1}/${rent.installmentCount}',
          if (rent.contractStart != null)
            'Sözleşme başlangıcı: ${shortDate(rent.contractStart!)}',
          if (rent.contractEnd != null)
            'Sözleşme bitişi: ${shortDate(rent.contractEnd!)}',
        ],
        schedule: const [],
        payments: rent.payments,
        notes: rent.notes,
        isArchived: rent.isArchived,
        edit: (context) => showRentForm(
          context: context,
          controller: controller,
          person: person,
          rent: rent,
        ),
        setArchived: (archived) => controller.setRentArchived(
          personId: person.id,
          rentId: rent.id,
          archived: archived,
        ),
        delete: () =>
            controller.deleteRent(personId: person.id, rentId: rent.id),
      );
  }
}

Future<void> _confirmDeletePerson(
  BuildContext context,
  MizanController controller,
  PersonAccount person,
) => _confirmAction(
  context,
  title: 'Kişiyi sil',
  message:
      '${person.name} ve bu kişiye bağlı bütün kayıtlar silinecek. Bu işlem yalnız açık onayla yapılır.',
  confirmLabel: 'Kişiyi sil',
  action: () => controller.deletePerson(person.id),
);

Future<void> _confirmDeleteRecord(
  BuildContext context,
  _RecordDetailData data,
) async {
  final accepted = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: const Text('Kaydı sil'),
      content: Text(
        '${data.title} kaydı, kendi ödeme ve not geçmişiyle birlikte silinecek.',
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(dialogContext, false),
          child: const Text('Vazgeç'),
        ),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: MizanTheme.red),
          onPressed: () => Navigator.pop(dialogContext, true),
          child: const Text('Kaydı sil'),
        ),
      ],
    ),
  );
  if (accepted != true) {
    return;
  }
  if (context.mounted) {
    Navigator.pop(context);
  }
  await Future<void>.delayed(kThemeAnimationDuration);
  await data.delete();
}

Future<void> _confirmAction(
  BuildContext context, {
  required String title,
  required String message,
  required String confirmLabel,
  required Future<void> Function() action,
}) async {
  final accepted = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(dialogContext, false),
          child: const Text('Vazgeç'),
        ),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: MizanTheme.red),
          onPressed: () => Navigator.pop(dialogContext, true),
          child: Text(confirmLabel),
        ),
      ],
    ),
  );
  if (accepted == true) await action();
}

IconData _creditorIcon(CreditorType type) => switch (type) {
  CreditorType.person => Icons.person_outline,
  CreditorType.companyInstitution => Icons.business_outlined,
  CreditorType.cheque => Icons.payments_outlined,
  CreditorType.promissoryNote => Icons.description_outlined,
  CreditorType.merchantBusiness => Icons.storefront_outlined,
  CreditorType.familyRelative => Icons.family_restroom_outlined,
  CreditorType.other => Icons.category_outlined,
};

extension _IterableFirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
