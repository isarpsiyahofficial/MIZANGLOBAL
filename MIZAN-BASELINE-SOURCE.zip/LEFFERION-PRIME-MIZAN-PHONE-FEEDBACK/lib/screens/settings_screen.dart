import 'dart:convert';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../controllers/mizan_controller.dart';
import '../core/formatters.dart';
import '../core/theme.dart';
import '../models/mizan_models.dart';
import '../services/csv_backup_service.dart';
import '../widgets/mizan_cards.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({required this.controller, super.key});

  final MizanController controller;

  @override
  Widget build(BuildContext context) {
    final state = controller.state;
    final health = controller.notificationHealth;
    final padding = MediaQuery.sizeOf(context).width < 380 ? 12.0 : 18.0;

    return ListView(
      key: const PageStorageKey('settings'),
      padding: EdgeInsets.fromLTRB(padding, 18, padding, 100),
      children: [
        const PageHeader(
          title: 'Ayarlar',
          subtitle: 'Bildirimler, yerel kayıt ve CSV yedekleme seçenekleri',
        ),
        const SizedBox(height: 18),
        _SettingsSection(
          title: 'Bildirimler',
          subtitle:
              'Bildirim izni ilk açılışta istenir. İzin reddedildiyse buradan yeniden isteyebilirsin.',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                title: const Text(
                  'Ödeme ve gider hatırlatmaları',
                  style: TextStyle(fontWeight: FontWeight.w900),
                ),
                subtitle: const Text(
                  'Kapatıldığında planlanmış MİZAN bildirimleri temizlenir.',
                ),
                value: state.notificationsEnabled,
                onChanged: controller.isBusy
                    ? null
                    : controller.setNotificationsEnabled,
              ),
              const Divider(),
              AdaptiveGrid(
                minTileWidth: 180,
                children: [
                  MetricCard(
                    label: 'Bildirim izni',
                    value: health.permissionGranted ? 'Açık' : 'Kapalı',
                    color: health.permissionGranted
                        ? MizanTheme.green
                        : MizanTheme.orange,
                  ),
                  MetricCard(
                    label: 'Zamanlama',
                    value: health.exactAlarmGranted ? 'Dakik' : 'Yaklaşık',
                    color: health.exactAlarmGranted
                        ? MizanTheme.green
                        : MizanTheme.orange,
                  ),
                  MetricCard(
                    label: 'Planlanan',
                    value: health.pendingCount.toString(),
                    color: MizanTheme.blue,
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  if (!health.permissionGranted)
                    FilledButton.icon(
                      onPressed: controller.isBusy
                          ? null
                          : controller.requestNotificationPermissions,
                      icon: const Icon(Icons.notifications_active_outlined),
                      label: const Text('Bildirim iznini yeniden iste'),
                    ),
                  OutlinedButton.icon(
                    onPressed: controller.isBusy
                        ? null
                        : controller.rescheduleNotifications,
                    icon: const Icon(Icons.refresh),
                    label: const Text('Hatırlatmaları yenile'),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        const SectionTitle(
          'Günlük gider hatırlatmaları',
          subtitle: 'Saat, mesaj ve açık/kapalı durumu ayrı düzenlenir',
        ),
        const SizedBox(height: 10),
        for (final slot in state.notificationSlots) ...[
          MizanListCard(
            title: '${slot.label} · ${timeLabel(slot.hour, slot.minute)}',
            subtitle: slot.message,
            leadingColor: slot.enabled ? MizanTheme.green : MizanTheme.muted,
            icon: Icons.alarm_outlined,
            trailing: Switch.adaptive(
              value: slot.enabled,
              onChanged: controller.isBusy
                  ? null
                  : (value) => controller.updateNotificationSlot(
                      slotId: slot.id,
                      enabled: value,
                    ),
            ),
            onTap: () => _editSlot(context, slot),
          ),
          const SizedBox(height: 10),
        ],
        const MizanListCard(
          title: 'Ödeme hatırlatma düzeni',
          subtitle:
              'Her aktif kayıt için vade tarihinden 5 gün önce başlayarak vade günü ve gecikmeden sonraki 5 gün boyunca 09.00 ve 18.00 saatlerinde planlanır. Bildirim planlaması ödeme kaydı oluşturmaz.',
          leadingColor: MizanTheme.blue,
          icon: Icons.event_available_outlined,
        ),
        const SizedBox(height: 16),
        _SettingsSection(
          title: 'Yerel veri güvenliği',
          subtitle:
              'Her değişiklik cihazda anında kaydedilir. Ana dosya doğrulanmadan mevcut sağlam kayıt değiştirilmez.',
          child: const Column(
            children: [
              MizanListCard(
                title: 'Anlık yerel kayıt',
                subtitle:
                    'Kişiler, borçlar, faturalar, abonelikler, ödemeler, notlar ve giderler her işlemden sonra cihazdaki dosyaya yazılır.',
                leadingColor: MizanTheme.green,
                icon: Icons.save_outlined,
              ),
              SizedBox(height: 10),
              MizanListCard(
                title: 'Doğrulanmış yedek kopya',
                subtitle:
                    'Yeni kayıt doğrulandıktan sonra ana dosya değiştirilir; son sağlam kopya ayrıca korunur.',
                leadingColor: MizanTheme.blue,
                icon: Icons.verified_user_outlined,
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _SettingsSection(
          title: 'CSV yedekleme',
          subtitle:
              'Tüm kayıt ilişkileri ve benzersiz kimlikler tek CSV dosyasında korunur.',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              FilledButton.icon(
                onPressed: controller.isBusy ? null : () => _exportCsv(context),
                icon: const Icon(Icons.file_download_outlined),
                label: const Text('CSV yedeğini dışa aktar'),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: controller.isBusy ? null : () => _importCsv(context),
                icon: const Icon(Icons.file_upload_outlined),
                label: const Text('CSV yedeğini geri yükle'),
              ),
              const SizedBox(height: 10),
              Text(
                'Geri yükleme işlemi önce dosyayı doğrular, ardından içerik özetini gösterir. Onay verilmeden mevcut kayıtlar değiştirilmez.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _editSlot(BuildContext context, NotificationSlot slot) async {
    var time = TimeOfDay(hour: slot.hour, minute: slot.minute);
    final message = TextEditingController(text: slot.message);
    final key = GlobalKey<FormState>();
    try {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => StatefulBuilder(
          builder: (dialogContext, setDialogState) => AlertDialog(
            title: Text('${slot.label} bildirimi'),
            content: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 540),
              child: Form(
                key: key,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      OutlinedButton.icon(
                        onPressed: () async {
                          final selected = await showTimePicker(
                            context: dialogContext,
                            initialTime: time,
                          );
                          if (selected != null) {
                            setDialogState(() => time = selected);
                          }
                        },
                        icon: const Icon(Icons.schedule),
                        label: Text(time.format(dialogContext)),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: message,
                        maxLength: 160,
                        minLines: 2,
                        maxLines: 5,
                        decoration: const InputDecoration(
                          labelText: 'Bildirim mesajı',
                        ),
                        validator: (value) =>
                            value == null || value.trim().isEmpty
                            ? 'Bildirim mesajı boş bırakılamaz.'
                            : null,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext),
                child: const Text('Vazgeç'),
              ),
              FilledButton(
                onPressed: () async {
                  if (!(key.currentState?.validate() ?? false)) {
                    return;
                  }
                  await controller.updateNotificationSlot(
                    slotId: slot.id,
                    hour: time.hour,
                    minute: time.minute,
                    message: message.text,
                  );
                  if (dialogContext.mounted) {
                    Navigator.pop(dialogContext);
                  }
                },
                child: const Text('Kaydet'),
              ),
            ],
          ),
        ),
      );
    } finally {
      await Future<void>.delayed(kThemeAnimationDuration);
      message.dispose();
    }
  }

  Future<void> _exportCsv(BuildContext context) async {
    try {
      const service = CsvBackupService();
      final content = service.exportState(controller.state);
      final now = DateTime.now();
      final date =
          '${now.year.toString().padLeft(4, '0')}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}';
      final result = await FilePicker.platform.saveFile(
        dialogTitle: 'MİZAN CSV yedeğini kaydet',
        fileName: 'MIZAN-YEDEK-$date.csv',
        type: FileType.custom,
        allowedExtensions: const ['csv'],
        bytes: Uint8List.fromList(utf8.encode(content)),
      );
      if (context.mounted && result != null) {
        _showMessage(context, 'CSV yedeği oluşturuldu.');
      }
    } on Object catch (error) {
      if (context.mounted) {
        _showMessage(context, 'CSV yedeği oluşturulamadı: $error', error: true);
      }
    }
  }

  Future<void> _importCsv(BuildContext context) async {
    try {
      final result = await FilePicker.platform.pickFiles(
        dialogTitle: 'MİZAN CSV yedeğini seç',
        type: FileType.custom,
        allowedExtensions: const ['csv'],
        withData: true,
      );
      if (result == null || result.files.isEmpty) {
        return;
      }
      final bytes = result.files.single.bytes;
      if (bytes == null) {
        throw const FormatException('Seçilen CSV dosyası okunamadı.');
      }
      const service = CsvBackupService();
      final restored = service.importState(utf8.decode(bytes));
      if (!context.mounted) {
        return;
      }
      final accepted = await _confirmRestore(context, restored);
      if (accepted != true) {
        return;
      }
      await controller.restoreFromBackup(restored);
      if (context.mounted) {
        _showMessage(context, 'CSV yedeği başarıyla geri yüklendi.');
      }
    } on Object catch (error) {
      if (context.mounted) {
        _showMessage(
          context,
          'CSV yedeği geri yüklenemedi: $error',
          error: true,
        );
      }
    }
  }

  Future<bool?> _confirmRestore(BuildContext context, MizanState restored) {
    final recordCount = restored.recordReferencesAt(DateTime.now()).length;
    final paymentCount = restored.people.fold<int>(0, (personTotal, person) {
      final bankPayments = person.banks.fold<int>(
        0,
        (bankTotal, bank) =>
            bankTotal +
            bank.products.fold<int>(
              0,
              (total, debt) => total + debt.payments.length,
            ),
      );
      final directPayments = [
        ...person.personalDebts.map((item) => item.payments.length),
        ...person.bills.map((item) => item.payments.length),
        ...person.subscriptions.map((item) => item.payments.length),
        ...person.rents.map((item) => item.payments.length),
      ].fold<int>(0, (sum, count) => sum + count);
      return personTotal + bankPayments + directPayments;
    });

    return showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('CSV yedeğini geri yükle'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Dosya doğrulandı. Geri yükleme mevcut verilerin yerine bu yedeği kullanır.',
              ),
              const SizedBox(height: 14),
              Text('Kişi: ${restored.people.length}'),
              Text('Toplam kayıt: $recordCount'),
              Text('Gerçekleşen ödeme: $paymentCount'),
              Text('Gider: ${restored.expenses.length}'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Yedeği geri yükle'),
          ),
        ],
      ),
    );
  }

  void _showMessage(
    BuildContext context,
    String message, {
    bool error = false,
  }) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: error ? MizanTheme.red : null,
      ),
    );
  }
}

class _SettingsSection extends StatelessWidget {
  const _SettingsSection({
    required this.title,
    required this.subtitle,
    required this.child,
  });

  final String title;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title,
              style: Theme.of(
                context,
              ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 4),
            Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }
}
