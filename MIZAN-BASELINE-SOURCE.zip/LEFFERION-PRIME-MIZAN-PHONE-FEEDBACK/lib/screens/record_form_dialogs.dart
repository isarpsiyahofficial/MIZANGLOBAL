import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../controllers/mizan_controller.dart';
import '../core/formatters.dart';
import '../models/mizan_models.dart';

Future<void> showPersonForm({
  required BuildContext context,
  required MizanController controller,
  PersonAccount? person,
}) {
  return showDialog<void>(
    context: context,
    builder: (_) => _PersonForm(controller: controller, person: person),
  );
}

Future<void> showBankForm({
  required BuildContext context,
  required MizanController controller,
  required PersonAccount person,
  BankGroup? bank,
}) {
  return showDialog<void>(
    context: context,
    builder: (_) =>
        _BankForm(controller: controller, person: person, bank: bank),
  );
}

Future<void> showDebtForm({
  required BuildContext context,
  required MizanController controller,
  required PersonAccount person,
  required BankGroup bank,
  DebtProduct? debt,
}) {
  return showDialog<void>(
    context: context,
    builder: (_) => _DebtForm(
      controller: controller,
      person: person,
      bank: bank,
      debt: debt,
    ),
  );
}

Future<void> showBillForm({
  required BuildContext context,
  required MizanController controller,
  required PersonAccount person,
  BillEntry? bill,
}) {
  return showDialog<void>(
    context: context,
    builder: (_) =>
        _BillForm(controller: controller, person: person, bill: bill),
  );
}

Future<void> showPersonalDebtForm({
  required BuildContext context,
  required MizanController controller,
  required PersonAccount person,
  PersonalDebtEntry? debt,
}) {
  return showDialog<void>(
    context: context,
    builder: (_) =>
        _PersonalDebtForm(controller: controller, person: person, debt: debt),
  );
}

Future<void> showSubscriptionForm({
  required BuildContext context,
  required MizanController controller,
  required PersonAccount person,
  SubscriptionEntry? subscription,
}) {
  return showDialog<void>(
    context: context,
    builder: (_) => _SubscriptionForm(
      controller: controller,
      person: person,
      subscription: subscription,
    ),
  );
}

Future<void> showRentForm({
  required BuildContext context,
  required MizanController controller,
  required PersonAccount person,
  RentEntry? rent,
}) {
  return showDialog<void>(
    context: context,
    builder: (_) =>
        _RentForm(controller: controller, person: person, rent: rent),
  );
}

Future<void> showPaymentForm({
  required BuildContext context,
  required MizanController controller,
  required String personId,
  required RecordType type,
  required String sourceId,
  required double remainingAmount,
  PaymentRecord? payment,
}) {
  return showDialog<void>(
    context: context,
    builder: (_) => _PaymentForm(
      controller: controller,
      personId: personId,
      type: type,
      sourceId: sourceId,
      remainingAmount: remainingAmount,
      payment: payment,
    ),
  );
}

class _DialogShell extends StatelessWidget {
  const _DialogShell({
    required this.title,
    required this.formKey,
    required this.children,
    required this.onSave,
  });

  final String title;
  final GlobalKey<FormState> formKey;
  final List<Widget> children;
  final Future<void> Function() onSave;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(title),
      insetPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 24),
      content: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: 620,
          maxHeight: MediaQuery.sizeOf(context).height * .72,
        ),
        child: Form(
          key: formKey,
          child: SingleChildScrollView(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: _withSpacing(children),
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Vazgeç'),
        ),
        FilledButton(
          onPressed: () async {
            if (!(formKey.currentState?.validate() ?? false)) {
              return;
            }
            try {
              await onSave();
              if (context.mounted) {
                Navigator.pop(context);
              }
            } on Object catch (error) {
              if (!context.mounted) {
                return;
              }
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(SnackBar(content: Text(_message(error))));
            }
          },
          child: const Text('Kaydet'),
        ),
      ],
    );
  }
}

List<Widget> _withSpacing(List<Widget> children) {
  return [
    for (var i = 0; i < children.length; i++) ...[
      children[i],
      if (i != children.length - 1) const SizedBox(height: 12),
    ],
  ];
}

String _message(Object error) => error
    .toString()
    .replaceFirst('Invalid argument(s): ', '')
    .replaceFirst('FormatException: ', '')
    .replaceFirst('Bad state: ', '');

String? _required(String? value, String label) =>
    value == null || value.trim().isEmpty ? '$label boş bırakılamaz.' : null;

String? _moneyValidator(String? value, String label, {bool allowZero = false}) {
  try {
    final parsed = parseMoney(value ?? '');
    if (allowZero ? parsed < 0 : parsed <= 0) {
      return '$label geçersiz.';
    }
    return null;
  } on FormatException catch (error) {
    return error.message;
  }
}

class _PersonForm extends StatefulWidget {
  const _PersonForm({required this.controller, this.person});
  final MizanController controller;
  final PersonAccount? person;
  @override
  State<_PersonForm> createState() => _PersonFormState();
}

class _PersonFormState extends State<_PersonForm> {
  final key = GlobalKey<FormState>();
  late final TextEditingController name;
  @override
  void initState() {
    super.initState();
    name = TextEditingController(text: widget.person?.name ?? '');
  }

  @override
  void dispose() {
    name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _DialogShell(
      title: widget.person == null ? 'Kişi ekle' : 'Kişiyi düzenle',
      formKey: key,
      children: [
        TextFormField(
          controller: name,
          maxLength: 80,
          autofocus: true,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(labelText: 'Kişi adı'),
          validator: (value) => _required(value, 'Kişi adı'),
        ),
      ],
      onSave: () => widget.person == null
          ? widget.controller.addPerson(name.text)
          : widget.controller.updatePerson(
              personId: widget.person!.id,
              name: name.text,
            ),
    );
  }
}

class _BankForm extends StatefulWidget {
  const _BankForm({required this.controller, required this.person, this.bank});
  final MizanController controller;
  final PersonAccount person;
  final BankGroup? bank;
  @override
  State<_BankForm> createState() => _BankFormState();
}

class _BankFormState extends State<_BankForm> {
  final key = GlobalKey<FormState>();
  late final TextEditingController name;
  @override
  void initState() {
    super.initState();
    name = TextEditingController(text: widget.bank?.userWrittenName ?? '');
  }

  @override
  void dispose() {
    name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _DialogShell(
      title: widget.bank == null ? 'Banka grubu ekle' : 'Banka grubunu düzenle',
      formKey: key,
      children: [
        TextFormField(
          controller: name,
          maxLength: 100,
          autofocus: true,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(
            labelText: 'Banka adı',
            helperText: 'Hazır marka listesi yoktur; adı kullanıcı belirler.',
          ),
          validator: (value) => _required(value, 'Banka adı'),
        ),
      ],
      onSave: () => widget.bank == null
          ? widget.controller.addBankGroup(
              personId: widget.person.id,
              userWrittenName: name.text,
            )
          : widget.controller.updateBankGroup(
              personId: widget.person.id,
              bankId: widget.bank!.id,
              userWrittenName: name.text,
            ),
    );
  }
}

class _DebtForm extends StatefulWidget {
  const _DebtForm({
    required this.controller,
    required this.person,
    required this.bank,
    this.debt,
  });
  final MizanController controller;
  final PersonAccount person;
  final BankGroup bank;
  final DebtProduct? debt;
  @override
  State<_DebtForm> createState() => _DebtFormState();
}

class _DebtFormState extends State<_DebtForm> {
  final key = GlobalKey<FormState>();
  late final TextEditingController title,
      total,
      monthly,
      custom,
      installmentCount,
      currentInstallment,
      limit,
      usedLimit,
      dueDay,
      description;
  late DebtKind kind;
  late DebtDueMode dueMode;
  late DateTime dueDate;

  @override
  void initState() {
    super.initState();
    final item = widget.debt;
    kind = item?.kind ?? DebtKind.creditCard;
    dueMode = item?.dueMode ?? DebtDueMode.fixedDate;
    dueDate =
        item?.dueDate ?? dateOnly(DateTime.now().add(const Duration(days: 7)));
    title = TextEditingController(text: item?.title ?? '');
    total = TextEditingController(
      text: item == null ? '' : decimalText(item.totalAmount),
    );
    monthly = TextEditingController(
      text: item == null ? '' : decimalText(item.monthlyAmount),
    );
    custom = TextEditingController(text: item?.customKindName ?? '');
    installmentCount = TextEditingController(
      text: item?.installmentCount?.toString() ?? '',
    );
    currentInstallment = TextEditingController(
      text: item?.currentInstallment?.toString() ?? '',
    );
    limit = TextEditingController(
      text: item?.limit == null ? '' : decimalText(item!.limit!),
    );
    usedLimit = TextEditingController(
      text: item?.usedLimit == null ? '' : decimalText(item!.usedLimit!),
    );
    dueDay = TextEditingController(
      text: (item?.dueDayOfMonth ?? dueDate.day).toString(),
    );
    description = TextEditingController(text: item?.description ?? '');
  }

  @override
  void dispose() {
    for (final controller in [
      title,
      total,
      monthly,
      custom,
      installmentCount,
      currentInstallment,
      limit,
      usedLimit,
      dueDay,
      description,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _DialogShell(
      title: widget.debt == null ? 'Borç ürünü ekle' : 'Borç ürününü düzenle',
      formKey: key,
      children: [
        DropdownButtonFormField<DebtKind>(
          initialValue: kind,
          decoration: const InputDecoration(labelText: 'Borç türü'),
          items: [
            for (final item in DebtKind.values)
              DropdownMenuItem(value: item, child: Text(item.label)),
          ],
          onChanged: (value) => setState(() => kind = value ?? kind),
        ),
        if (kind == DebtKind.custom)
          TextFormField(
            controller: custom,
            maxLength: 60,
            decoration: const InputDecoration(labelText: 'Özel borç türü'),
            validator: (v) => _required(v, 'Özel borç türü'),
          ),
        TextFormField(
          controller: title,
          maxLength: 100,
          decoration: const InputDecoration(labelText: 'Başlık'),
          validator: (v) => _required(v, 'Başlık'),
        ),
        _MoneyField(
          controller: total,
          label: 'Toplam borç',
          validator: (v) => _moneyValidator(v, 'Toplam borç'),
        ),
        _MoneyField(
          controller: monthly,
          label: 'Aylık tutar',
          validator: (v) => _moneyValidator(v, 'Aylık tutar', allowZero: true),
        ),
        DropdownButtonFormField<DebtDueMode>(
          initialValue: dueMode,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Ödeme tarihi yöntemi'),
          items: [
            for (final item in DebtDueMode.values)
              DropdownMenuItem(value: item, child: Text(item.label)),
          ],
          onChanged: (value) => setState(() => dueMode = value ?? dueMode),
        ),
        if (dueMode == DebtDueMode.fixedDate)
          _DateField(
            label: 'Son ödeme tarihi',
            value: dueDate,
            onChanged: (value) => setState(() => dueDate = value),
          )
        else
          TextFormField(
            controller: dueDay,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(
              labelText: 'Her ayın kaçıncı günü?',
              helperText: '1 ile 31 arasında bir gün girin.',
            ),
            validator: (value) {
              final day = int.tryParse(value?.trim() ?? '');
              if (day == null || day < 1 || day > 31) {
                return 'Aylık ödeme günü 1 ile 31 arasında olmalıdır.';
              }
              return null;
            },
          ),
        _TwoColumn(
          left: TextFormField(
            controller: installmentCount,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(labelText: 'Toplam taksit'),
          ),
          right: TextFormField(
            controller: currentInstallment,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(labelText: 'Mevcut taksit'),
          ),
        ),
        _TwoColumn(
          left: _MoneyField(
            controller: limit,
            label: 'Limit (opsiyonel)',
            requiredValue: false,
          ),
          right: _MoneyField(
            controller: usedLimit,
            label: 'Kullanılan limit',
            requiredValue: false,
          ),
        ),
        TextFormField(
          controller: description,
          maxLength: 240,
          minLines: 2,
          maxLines: 5,
          decoration: const InputDecoration(labelText: 'Açıklama'),
        ),
      ],
      onSave: () {
        final args = (
          personId: widget.person.id,
          bankId: widget.bank.id,
          kind: kind,
          title: title.text,
          totalAmount: parseMoney(total.text),
          monthlyAmount: monthly.text.trim().isEmpty
              ? 0.0
              : parseMoney(monthly.text),
          dueDate: dueDate,
          dueMode: dueMode,
          dueDayOfMonth: dueMode == DebtDueMode.monthlyDay
              ? int.parse(dueDay.text.trim())
              : null,
          customKindName: custom.text,
          installmentCount: parseOptionalPositiveInt(
            installmentCount.text,
            fieldName: 'Toplam taksit',
          ),
          currentInstallment: parseOptionalPositiveInt(
            currentInstallment.text,
            fieldName: 'Mevcut taksit',
          ),
          limit: limit.text.trim().isEmpty ? null : parseMoney(limit.text),
          usedLimit: usedLimit.text.trim().isEmpty
              ? null
              : parseMoney(usedLimit.text),
          description: description.text,
        );
        if (widget.debt == null) {
          return widget.controller.addDebtProduct(
            personId: args.personId,
            bankId: args.bankId,
            kind: args.kind,
            title: args.title,
            totalAmount: args.totalAmount,
            monthlyAmount: args.monthlyAmount,
            dueDate: args.dueDate,
            dueMode: args.dueMode,
            dueDayOfMonth: args.dueDayOfMonth,
            customKindName: args.customKindName,
            installmentCount: args.installmentCount,
            currentInstallment: args.currentInstallment,
            limit: args.limit,
            usedLimit: args.usedLimit,
            description: args.description,
          );
        }
        return widget.controller.updateDebtProduct(
          personId: args.personId,
          bankId: args.bankId,
          debtId: widget.debt!.id,
          kind: args.kind,
          title: args.title,
          totalAmount: args.totalAmount,
          monthlyAmount: args.monthlyAmount,
          dueDate: args.dueDate,
          dueMode: args.dueMode,
          dueDayOfMonth: args.dueDayOfMonth,
          customKindName: args.customKindName,
          installmentCount: args.installmentCount,
          currentInstallment: args.currentInstallment,
          limit: args.limit,
          usedLimit: args.usedLimit,
          description: args.description,
        );
      },
    );
  }
}

class _BillForm extends StatefulWidget {
  const _BillForm({required this.controller, required this.person, this.bill});
  final MizanController controller;
  final PersonAccount person;
  final BillEntry? bill;
  @override
  State<_BillForm> createState() => _BillFormState();
}

class _BillFormState extends State<_BillForm> {
  final key = GlobalKey<FormState>();
  late BillKind kind;
  late DateTime dueDate;
  late final TextEditingController institution,
      amount,
      subscriber,
      contract,
      description;
  @override
  void initState() {
    super.initState();
    final item = widget.bill;
    kind = item?.kind ?? BillKind.electricity;
    dueDate =
        item?.dueDate ?? dateOnly(DateTime.now().add(const Duration(days: 7)));
    institution = TextEditingController(text: item?.institutionName ?? '');
    amount = TextEditingController(
      text: item == null ? '' : decimalText(item.amount),
    );
    subscriber = TextEditingController(text: item?.subscriberNumber ?? '');
    contract = TextEditingController(text: item?.contractNumber ?? '');
    description = TextEditingController(text: item?.description ?? '');
  }

  @override
  void dispose() {
    for (final c in [institution, amount, subscriber, contract, description]) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _DialogShell(
      title: widget.bill == null ? 'Fatura ekle' : 'Faturayı düzenle',
      formKey: key,
      children: [
        DropdownButtonFormField<BillKind>(
          initialValue: kind,
          decoration: const InputDecoration(labelText: 'Fatura türü'),
          items: [
            for (final item in BillKind.values)
              DropdownMenuItem(value: item, child: Text(item.label)),
          ],
          onChanged: (v) => setState(() => kind = v ?? kind),
        ),
        TextFormField(
          controller: institution,
          maxLength: 100,
          decoration: const InputDecoration(labelText: 'Kurum adı'),
          validator: (v) => _required(v, 'Kurum adı'),
        ),
        _MoneyField(
          controller: amount,
          label: 'Tutar',
          validator: (v) => _moneyValidator(v, 'Tutar'),
        ),
        _DateField(
          label: 'Son ödeme tarihi',
          value: dueDate,
          onChanged: (v) => setState(() => dueDate = v),
        ),
        TextFormField(
          controller: subscriber,
          maxLength: 60,
          decoration: const InputDecoration(labelText: 'Abone numarası'),
        ),
        TextFormField(
          controller: contract,
          maxLength: 60,
          decoration: const InputDecoration(
            labelText: 'Tesisat / sözleşme numarası',
          ),
        ),
        TextFormField(
          controller: description,
          maxLength: 240,
          minLines: 2,
          maxLines: 5,
          decoration: const InputDecoration(labelText: 'Açıklama'),
        ),
      ],
      onSave: () => widget.bill == null
          ? widget.controller.addBill(
              personId: widget.person.id,
              kind: kind,
              institutionName: institution.text,
              amount: parseMoney(amount.text),
              dueDate: dueDate,
              subscriberNumber: subscriber.text,
              contractNumber: contract.text,
              description: description.text,
            )
          : widget.controller.updateBill(
              personId: widget.person.id,
              billId: widget.bill!.id,
              kind: kind,
              institutionName: institution.text,
              amount: parseMoney(amount.text),
              dueDate: dueDate,
              subscriberNumber: subscriber.text,
              contractNumber: contract.text,
              description: description.text,
            ),
    );
  }
}

class _RentForm extends StatefulWidget {
  const _RentForm({required this.controller, required this.person, this.rent});
  final MizanController controller;
  final PersonAccount person;
  final RentEntry? rent;
  @override
  State<_RentForm> createState() => _RentFormState();
}

class _RentFormState extends State<_RentForm> {
  final key = GlobalKey<FormState>();
  late DateTime dueDate;
  DateTime? contractStart, contractEnd, increaseDate;
  late final TextEditingController title,
      amount,
      paymentDay,
      receiver,
      iban,
      installmentCount,
      currentInstallment,
      description;
  @override
  void initState() {
    super.initState();
    final i = widget.rent;
    dueDate =
        i?.dueDate ?? dateOnly(DateTime.now().add(const Duration(days: 7)));
    contractStart = i?.contractStart;
    contractEnd = i?.contractEnd;
    increaseDate = i?.increaseDate;
    title = TextEditingController(text: i?.title ?? '');
    amount = TextEditingController(
      text: i == null ? '' : decimalText(i.amount),
    );
    paymentDay = TextEditingController(
      text: i?.paymentDay.toString() ?? dueDate.day.toString(),
    );
    receiver = TextEditingController(text: i?.receiverName ?? '');
    iban = TextEditingController(text: i?.iban ?? '');
    installmentCount = TextEditingController(
      text: i?.installmentCount?.toString() ?? '',
    );
    currentInstallment = TextEditingController(
      text: i?.currentInstallment?.toString() ?? '',
    );
    description = TextEditingController(text: i?.description ?? '');
  }

  @override
  void dispose() {
    for (final c in [
      title,
      amount,
      paymentDay,
      receiver,
      iban,
      installmentCount,
      currentInstallment,
      description,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => _DialogShell(
    title: widget.rent == null
        ? 'Kira / taksit ekle'
        : 'Kira / taksiti düzenle',
    formKey: key,
    children: [
      TextFormField(
        controller: title,
        maxLength: 100,
        decoration: const InputDecoration(labelText: 'Başlık'),
        validator: (v) => _required(v, 'Başlık'),
      ),
      _MoneyField(
        controller: amount,
        label: 'Toplam tutar',
        validator: (v) => _moneyValidator(v, 'Toplam tutar'),
      ),
      TextFormField(
        controller: paymentDay,
        keyboardType: TextInputType.number,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        decoration: const InputDecoration(labelText: 'Ödeme günü (1-31)'),
        validator: (v) {
          final n = int.tryParse(v ?? '');
          return n == null || n < 1 || n > 31
              ? '1 ile 31 arasında bir gün girin.'
              : null;
        },
      ),
      TextFormField(
        controller: receiver,
        maxLength: 100,
        decoration: const InputDecoration(labelText: 'Alıcı adı'),
        validator: (v) => _required(v, 'Alıcı adı'),
      ),
      TextFormField(
        controller: iban,
        maxLength: 40,
        textCapitalization: TextCapitalization.characters,
        decoration: const InputDecoration(labelText: 'IBAN (opsiyonel)'),
      ),
      _DateField(
        label: 'Son ödeme tarihi',
        value: dueDate,
        onChanged: (v) => setState(() => dueDate = v),
      ),
      _OptionalDateField(
        label: 'Sözleşme başlangıcı',
        value: contractStart,
        onChanged: (v) => setState(() => contractStart = v),
      ),
      _OptionalDateField(
        label: 'Sözleşme bitişi',
        value: contractEnd,
        onChanged: (v) => setState(() => contractEnd = v),
      ),
      _OptionalDateField(
        label: 'Artış tarihi',
        value: increaseDate,
        onChanged: (v) => setState(() => increaseDate = v),
      ),
      _TwoColumn(
        left: TextFormField(
          controller: installmentCount,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: const InputDecoration(labelText: 'Toplam taksit'),
        ),
        right: TextFormField(
          controller: currentInstallment,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: const InputDecoration(labelText: 'Mevcut taksit'),
        ),
      ),
      TextFormField(
        controller: description,
        maxLength: 240,
        minLines: 2,
        maxLines: 5,
        decoration: const InputDecoration(labelText: 'Açıklama'),
      ),
    ],
    onSave: () {
      final args = (
        personId: widget.person.id,
        title: title.text,
        amount: parseMoney(amount.text),
        paymentDay: int.parse(paymentDay.text),
        receiverName: receiver.text,
        dueDate: dueDate,
        iban: iban.text,
        contractStart: contractStart,
        contractEnd: contractEnd,
        increaseDate: increaseDate,
        installmentCount: parseOptionalPositiveInt(
          installmentCount.text,
          fieldName: 'Toplam taksit',
        ),
        currentInstallment: parseOptionalPositiveInt(
          currentInstallment.text,
          fieldName: 'Mevcut taksit',
        ),
        description: description.text,
      );
      return widget.rent == null
          ? widget.controller.addRent(
              personId: args.personId,
              title: args.title,
              amount: args.amount,
              paymentDay: args.paymentDay,
              receiverName: args.receiverName,
              dueDate: args.dueDate,
              iban: args.iban,
              contractStart: args.contractStart,
              contractEnd: args.contractEnd,
              increaseDate: args.increaseDate,
              installmentCount: args.installmentCount,
              currentInstallment: args.currentInstallment,
              description: args.description,
            )
          : widget.controller.updateRent(
              personId: args.personId,
              rentId: widget.rent!.id,
              title: args.title,
              amount: args.amount,
              paymentDay: args.paymentDay,
              receiverName: args.receiverName,
              dueDate: args.dueDate,
              iban: args.iban,
              contractStart: args.contractStart,
              contractEnd: args.contractEnd,
              increaseDate: args.increaseDate,
              installmentCount: args.installmentCount,
              currentInstallment: args.currentInstallment,
              description: args.description,
            );
    },
  );
}

class _PersonalDebtForm extends StatefulWidget {
  const _PersonalDebtForm({
    required this.controller,
    required this.person,
    this.debt,
  });

  final MizanController controller;
  final PersonAccount person;
  final PersonalDebtEntry? debt;

  @override
  State<_PersonalDebtForm> createState() => _PersonalDebtFormState();
}

class _PersonalDebtFormState extends State<_PersonalDebtForm> {
  final key = GlobalKey<FormState>();
  late CreditorType creditorType;
  late PaymentFrequency frequency;
  late bool isInstallment;
  late DateTime debtDate;
  late DateTime dueDate;
  late final TextEditingController title;
  late final TextEditingController creditorName;
  late final TextEditingController totalAmount;
  late final TextEditingController installmentCount;
  late final TextEditingController currentInstallment;
  late final TextEditingController monthlyAmount;
  late final TextEditingController customFrequencyDays;
  late final TextEditingController description;
  late final TextEditingController chequeNumber;
  late final TextEditingController issuerName;
  late final TextEditingController bankInfo;
  late final TextEditingController promissoryNoteNumber;
  late final TextEditingController documentCount;
  late final TextEditingController currentDocument;

  @override
  void initState() {
    super.initState();
    final item = widget.debt;
    creditorType = item?.creditorType ?? CreditorType.person;
    frequency = item?.frequency ?? PaymentFrequency.oneTime;
    isInstallment = item?.isInstallment ?? false;
    debtDate = item?.debtDate ?? dateOnly(DateTime.now());
    dueDate =
        item?.dueDate ?? dateOnly(DateTime.now().add(const Duration(days: 7)));
    title = TextEditingController(text: item?.title ?? '');
    creditorName = TextEditingController(text: item?.creditorName ?? '');
    totalAmount = TextEditingController(
      text: item == null ? '' : decimalText(item.totalAmount),
    );
    installmentCount = TextEditingController(
      text: item?.installmentCount?.toString() ?? '',
    );
    currentInstallment = TextEditingController(
      text: item?.currentInstallment?.toString() ?? '',
    );
    monthlyAmount = TextEditingController(
      text: item == null || item.monthlyAmount <= 0
          ? ''
          : decimalText(item.monthlyAmount),
    );
    customFrequencyDays = TextEditingController(
      text: item?.customFrequencyDays?.toString() ?? '',
    );
    description = TextEditingController(text: item?.description ?? '');
    chequeNumber = TextEditingController(text: item?.chequeNumber ?? '');
    issuerName = TextEditingController(text: item?.issuerName ?? '');
    bankInfo = TextEditingController(text: item?.bankInfo ?? '');
    promissoryNoteNumber = TextEditingController(
      text: item?.promissoryNoteNumber ?? '',
    );
    documentCount = TextEditingController(
      text: item?.documentCount?.toString() ?? '',
    );
    currentDocument = TextEditingController(
      text: item?.currentDocument?.toString() ?? '',
    );
  }

  @override
  void dispose() {
    for (final controller in [
      title,
      creditorName,
      totalAmount,
      installmentCount,
      currentInstallment,
      monthlyAmount,
      customFrequencyDays,
      description,
      chequeNumber,
      issuerName,
      bankInfo,
      promissoryNoteNumber,
      documentCount,
      currentDocument,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isCheque = creditorType == CreditorType.cheque;
    final isPromissory = creditorType == CreditorType.promissoryNote;
    return _DialogShell(
      title: widget.debt == null
          ? 'Kişisel / kurumsal borç ekle'
          : 'Kişisel / kurumsal borcu düzenle',
      formKey: key,
      children: [
        DropdownButtonFormField<CreditorType>(
          initialValue: creditorType,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Alacaklı türü'),
          items: [
            for (final item in CreditorType.values)
              DropdownMenuItem(value: item, child: Text(item.label)),
          ],
          onChanged: (value) =>
              setState(() => creditorType = value ?? creditorType),
        ),
        TextFormField(
          controller: title,
          maxLength: 100,
          decoration: const InputDecoration(labelText: 'Borç başlığı'),
          validator: (value) => _required(value, 'Borç başlığı'),
        ),
        TextFormField(
          controller: creditorName,
          maxLength: 100,
          decoration: const InputDecoration(labelText: 'Alacaklı adı'),
          validator: (value) => _required(value, 'Alacaklı adı'),
        ),
        _MoneyField(
          controller: totalAmount,
          label: 'Toplam borç',
          validator: (value) => _moneyValidator(value, 'Toplam borç'),
        ),
        _TwoColumn(
          left: _DateField(
            label: 'Borcun oluştuğu tarih',
            value: debtDate,
            onChanged: (value) => setState(() => debtDate = value),
          ),
          right: _DateField(
            label: 'Son ödeme tarihi',
            value: dueDate,
            onChanged: (value) => setState(() => dueDate = value),
          ),
        ),
        SwitchListTile.adaptive(
          contentPadding: EdgeInsets.zero,
          title: const Text('Taksitli ödeme planı'),
          subtitle: const Text(
            'Açıksa taksit sayısı ve düzenli ödeme tutarı saklanır.',
          ),
          value: isInstallment,
          onChanged: (value) => setState(() {
            isInstallment = value;
            if (!value) {
              frequency = PaymentFrequency.oneTime;
            } else if (frequency == PaymentFrequency.oneTime) {
              frequency = PaymentFrequency.monthly;
            }
          }),
        ),
        DropdownButtonFormField<PaymentFrequency>(
          initialValue: frequency,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Ödeme sıklığı'),
          items: [
            for (final item in PaymentFrequency.values)
              if (isInstallment || item == PaymentFrequency.oneTime)
                DropdownMenuItem(value: item, child: Text(item.label)),
          ],
          onChanged: (value) => setState(() => frequency = value ?? frequency),
        ),
        if (frequency == PaymentFrequency.custom)
          TextFormField(
            controller: customFrequencyDays,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(
              labelText: 'Özel ödeme aralığı (gün)',
            ),
            validator: (value) => int.tryParse(value ?? '') == null
                ? 'Gün sayısını girin.'
                : null,
          ),
        if (isInstallment)
          _TwoColumn(
            left: TextFormField(
              controller: installmentCount,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(labelText: 'Toplam taksit'),
              validator: (value) => int.tryParse(value ?? '') == null
                  ? 'Toplam taksiti girin.'
                  : null,
            ),
            right: TextFormField(
              controller: currentInstallment,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(labelText: 'Mevcut taksit'),
            ),
          ),
        if (isInstallment)
          _MoneyField(
            controller: monthlyAmount,
            label: 'Düzenli ödeme tutarı',
            validator: (value) =>
                _moneyValidator(value, 'Düzenli ödeme tutarı'),
          ),
        if (isCheque) ...[
          TextFormField(
            controller: chequeNumber,
            maxLength: 80,
            decoration: const InputDecoration(labelText: 'Çek numarası'),
            validator: (value) => _required(value, 'Çek numarası'),
          ),
          TextFormField(
            controller: issuerName,
            maxLength: 100,
            decoration: const InputDecoration(
              labelText: 'Çeki düzenleyen kişi / kurum',
            ),
          ),
          TextFormField(
            controller: bankInfo,
            maxLength: 100,
            decoration: const InputDecoration(
              labelText: 'Banka bilgisi (kullanıcı girişi)',
            ),
          ),
        ],
        if (isPromissory) ...[
          TextFormField(
            controller: promissoryNoteNumber,
            maxLength: 80,
            decoration: const InputDecoration(labelText: 'Senet numarası'),
            validator: (value) => _required(value, 'Senet numarası'),
          ),
          _TwoColumn(
            left: TextFormField(
              controller: documentCount,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(labelText: 'Senet adedi'),
            ),
            right: TextFormField(
              controller: currentDocument,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(labelText: 'Mevcut senet'),
            ),
          ),
          const Text(
            'Birden fazla senet varsa her biri ayrı vade satırı olarak oluşturulur.',
          ),
        ],
        TextFormField(
          controller: description,
          maxLength: 240,
          minLines: 2,
          maxLines: 5,
          decoration: const InputDecoration(labelText: 'Açıklama'),
        ),
      ],
      onSave: () {
        final total = parseMoney(totalAmount.text);
        final installmentTotal = parseOptionalPositiveInt(
          installmentCount.text,
          fieldName: 'Toplam taksit',
        );
        final documentTotal = parseOptionalPositiveInt(
          documentCount.text,
          fieldName: 'Senet adedi',
        );
        final paymentAmount = monthlyAmount.text.trim().isEmpty
            ? 0.0
            : parseMoney(monthlyAmount.text);
        final scheduleCount = isPromissory
            ? documentTotal
            : isInstallment
            ? installmentTotal
            : null;
        final schedule = _createSchedule(
          existing: widget.debt?.schedule ?? const [],
          count: scheduleCount,
          firstDueDate: dueDate,
          totalAmount: total,
          regularAmount: paymentAmount,
          frequency: frequency,
          customDays: int.tryParse(customFrequencyDays.text),
          prefix: isPromissory ? 'Senet' : 'Taksit',
        );
        final args = (
          creditorType: creditorType,
          title: title.text,
          creditorName: creditorName.text,
          totalAmount: total,
          debtDate: debtDate,
          dueDate: dueDate,
          frequency: frequency,
          isInstallment: isInstallment,
          installmentCount: installmentTotal,
          currentInstallment: parseOptionalPositiveInt(
            currentInstallment.text,
            fieldName: 'Mevcut taksit',
          ),
          monthlyAmount: paymentAmount,
          customFrequencyDays: int.tryParse(customFrequencyDays.text),
          description: description.text,
          chequeNumber: chequeNumber.text,
          issuerName: issuerName.text,
          bankInfo: bankInfo.text,
          promissoryNoteNumber: promissoryNoteNumber.text,
          documentCount: documentTotal,
          currentDocument: parseOptionalPositiveInt(
            currentDocument.text,
            fieldName: 'Mevcut senet',
          ),
          schedule: schedule,
        );
        return widget.debt == null
            ? widget.controller.addPersonalDebt(
                personId: widget.person.id,
                creditorType: args.creditorType,
                title: args.title,
                creditorName: args.creditorName,
                totalAmount: args.totalAmount,
                debtDate: args.debtDate,
                dueDate: args.dueDate,
                frequency: args.frequency,
                isInstallment: args.isInstallment,
                installmentCount: args.installmentCount,
                currentInstallment: args.currentInstallment,
                monthlyAmount: args.monthlyAmount,
                customFrequencyDays: args.customFrequencyDays,
                description: args.description,
                chequeNumber: args.chequeNumber,
                issuerName: args.issuerName,
                bankInfo: args.bankInfo,
                promissoryNoteNumber: args.promissoryNoteNumber,
                documentCount: args.documentCount,
                currentDocument: args.currentDocument,
                schedule: args.schedule,
              )
            : widget.controller.updatePersonalDebt(
                personId: widget.person.id,
                debtId: widget.debt!.id,
                creditorType: args.creditorType,
                title: args.title,
                creditorName: args.creditorName,
                totalAmount: args.totalAmount,
                debtDate: args.debtDate,
                dueDate: args.dueDate,
                frequency: args.frequency,
                isInstallment: args.isInstallment,
                installmentCount: args.installmentCount,
                currentInstallment: args.currentInstallment,
                monthlyAmount: args.monthlyAmount,
                customFrequencyDays: args.customFrequencyDays,
                description: args.description,
                chequeNumber: args.chequeNumber,
                issuerName: args.issuerName,
                bankInfo: args.bankInfo,
                promissoryNoteNumber: args.promissoryNoteNumber,
                documentCount: args.documentCount,
                currentDocument: args.currentDocument,
                schedule: args.schedule,
              );
      },
    );
  }

  List<DueScheduleItem> _createSchedule({
    required List<DueScheduleItem> existing,
    required int? count,
    required DateTime firstDueDate,
    required double totalAmount,
    required double regularAmount,
    required PaymentFrequency frequency,
    required int? customDays,
    required String prefix,
  }) {
    if (count == null || count <= 1) {
      return existing.length <= 1 ? existing : const [];
    }
    final result = <DueScheduleItem>[];
    var date = firstDueDate;
    var remaining = totalAmount;
    for (var index = 0; index < count; index++) {
      final amount = index == count - 1
          ? remaining
          : regularAmount > 0
          ? regularAmount.clamp(0.01, remaining).toDouble()
          : double.parse((totalAmount / count).toStringAsFixed(2));
      final existingItem = index < existing.length ? existing[index] : null;
      result.add(
        DueScheduleItem(
          id: existingItem?.id ?? newId('schedule'),
          label: '$prefix ${index + 1}/$count',
          amount: amount,
          dueDate: date,
          isCompleted: existingItem?.isCompleted ?? false,
        ),
      );
      remaining = double.parse(
        (remaining - amount).clamp(0, totalAmount).toStringAsFixed(2),
      );
      date = _nextScheduleDate(date, frequency, customDays);
    }
    return result;
  }

  DateTime _nextScheduleDate(
    DateTime source,
    PaymentFrequency frequency,
    int? customDays,
  ) {
    switch (frequency) {
      case PaymentFrequency.oneTime:
        return DateTime(source.year, source.month + 1, source.day);
      case PaymentFrequency.weekly:
        return source.add(const Duration(days: 7));
      case PaymentFrequency.biweekly:
        return source.add(const Duration(days: 14));
      case PaymentFrequency.monthly:
        return DateTime(source.year, source.month + 1, source.day);
      case PaymentFrequency.quarterly:
        return DateTime(source.year, source.month + 3, source.day);
      case PaymentFrequency.yearly:
        return DateTime(source.year + 1, source.month, source.day);
      case PaymentFrequency.custom:
        return source.add(Duration(days: customDays ?? 1));
    }
  }
}

class _SubscriptionForm extends StatefulWidget {
  const _SubscriptionForm({
    required this.controller,
    required this.person,
    this.subscription,
  });

  final MizanController controller;
  final PersonAccount person;
  final SubscriptionEntry? subscription;

  @override
  State<_SubscriptionForm> createState() => _SubscriptionFormState();
}

class _SubscriptionFormState extends State<_SubscriptionForm> {
  final key = GlobalKey<FormState>();
  late SubscriptionKind kind;
  late PaymentFrequency frequency;
  late DateTime nextDueDate;
  late final TextEditingController title;
  late final TextEditingController provider;
  late final TextEditingController amount;
  late final TextEditingController customKind;
  late final TextEditingController customDays;
  late final TextEditingController subscriberNumber;
  late final TextEditingController contractNumber;
  late final TextEditingController description;

  @override
  void initState() {
    super.initState();
    final item = widget.subscription;
    kind = item?.kind ?? SubscriptionKind.digitalService;
    frequency = item?.frequency ?? PaymentFrequency.monthly;
    nextDueDate =
        item?.nextDueDate ??
        dateOnly(DateTime.now().add(const Duration(days: 7)));
    title = TextEditingController(text: item?.title ?? '');
    provider = TextEditingController(text: item?.providerName ?? '');
    amount = TextEditingController(
      text: item == null ? '' : decimalText(item.amount),
    );
    customKind = TextEditingController(text: item?.customKindName ?? '');
    customDays = TextEditingController(
      text: item?.customFrequencyDays?.toString() ?? '',
    );
    subscriberNumber = TextEditingController(
      text: item?.subscriberNumber ?? '',
    );
    contractNumber = TextEditingController(text: item?.contractNumber ?? '');
    description = TextEditingController(text: item?.description ?? '');
  }

  @override
  void dispose() {
    for (final controller in [
      title,
      provider,
      amount,
      customKind,
      customDays,
      subscriberNumber,
      contractNumber,
      description,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => _DialogShell(
    title: widget.subscription == null ? 'Abonelik ekle' : 'Aboneliği düzenle',
    formKey: key,
    children: [
      DropdownButtonFormField<SubscriptionKind>(
        initialValue: kind,
        isExpanded: true,
        decoration: const InputDecoration(labelText: 'Abonelik türü'),
        items: [
          for (final item in SubscriptionKind.values)
            DropdownMenuItem(value: item, child: Text(item.label)),
        ],
        onChanged: (value) => setState(() => kind = value ?? kind),
      ),
      if (kind == SubscriptionKind.custom)
        TextFormField(
          controller: customKind,
          maxLength: 60,
          decoration: const InputDecoration(labelText: 'Özel tür adı'),
          validator: (value) => _required(value, 'Özel tür adı'),
        ),
      TextFormField(
        controller: title,
        maxLength: 100,
        decoration: const InputDecoration(labelText: 'Abonelik başlığı'),
        validator: (value) => _required(value, 'Abonelik başlığı'),
      ),
      TextFormField(
        controller: provider,
        maxLength: 100,
        decoration: const InputDecoration(labelText: 'Sağlayıcı adı'),
        validator: (value) => _required(value, 'Sağlayıcı adı'),
      ),
      _MoneyField(
        controller: amount,
        label: 'Dönem tutarı',
        validator: (value) => _moneyValidator(value, 'Dönem tutarı'),
      ),
      DropdownButtonFormField<PaymentFrequency>(
        initialValue: frequency,
        isExpanded: true,
        decoration: const InputDecoration(labelText: 'Tekrar sıklığı'),
        items: [
          for (final item in PaymentFrequency.values)
            if (item != PaymentFrequency.oneTime)
              DropdownMenuItem(value: item, child: Text(item.label)),
        ],
        onChanged: (value) => setState(() => frequency = value ?? frequency),
      ),
      if (frequency == PaymentFrequency.custom)
        TextFormField(
          controller: customDays,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: const InputDecoration(
            labelText: 'Özel tekrar aralığı (gün)',
          ),
          validator: (value) =>
              int.tryParse(value ?? '') == null ? 'Gün sayısını girin.' : null,
        ),
      _DateField(
        label: 'Sıradaki ödeme tarihi',
        value: nextDueDate,
        onChanged: (value) => setState(() => nextDueDate = value),
      ),
      TextFormField(
        controller: subscriberNumber,
        maxLength: 60,
        decoration: const InputDecoration(labelText: 'Abone numarası'),
      ),
      TextFormField(
        controller: contractNumber,
        maxLength: 60,
        decoration: const InputDecoration(labelText: 'Sözleşme numarası'),
      ),
      TextFormField(
        controller: description,
        maxLength: 240,
        minLines: 2,
        maxLines: 5,
        decoration: const InputDecoration(labelText: 'Açıklama'),
      ),
    ],
    onSave: () => widget.subscription == null
        ? widget.controller.addSubscription(
            personId: widget.person.id,
            kind: kind,
            title: title.text,
            providerName: provider.text,
            amount: parseMoney(amount.text),
            frequency: frequency,
            nextDueDate: nextDueDate,
            customKindName: customKind.text,
            customFrequencyDays: int.tryParse(customDays.text),
            subscriberNumber: subscriberNumber.text,
            contractNumber: contractNumber.text,
            description: description.text,
          )
        : widget.controller.updateSubscription(
            personId: widget.person.id,
            subscriptionId: widget.subscription!.id,
            kind: kind,
            title: title.text,
            providerName: provider.text,
            amount: parseMoney(amount.text),
            frequency: frequency,
            nextDueDate: nextDueDate,
            customKindName: customKind.text,
            customFrequencyDays: int.tryParse(customDays.text),
            subscriberNumber: subscriberNumber.text,
            contractNumber: contractNumber.text,
            description: description.text,
          ),
  );
}

class _PaymentForm extends StatefulWidget {
  const _PaymentForm({
    required this.controller,
    required this.personId,
    required this.type,
    required this.sourceId,
    required this.remainingAmount,
    this.payment,
  });
  final MizanController controller;
  final String personId;
  final RecordType type;
  final String sourceId;
  final double remainingAmount;
  final PaymentRecord? payment;
  @override
  State<_PaymentForm> createState() => _PaymentFormState();
}

class _PaymentFormState extends State<_PaymentForm> {
  final key = GlobalKey<FormState>();
  late DateTime paidAt;
  late final TextEditingController amount, note, method;
  @override
  void initState() {
    super.initState();
    paidAt = widget.payment?.paidAt ?? dateOnly(DateTime.now());
    amount = TextEditingController(
      text: widget.payment == null
          ? decimalText(widget.remainingAmount)
          : decimalText(widget.payment!.amount),
    );
    note = TextEditingController(text: widget.payment?.note ?? '');
    method = TextEditingController(text: widget.payment?.method ?? '');
  }

  @override
  void dispose() {
    amount.dispose();
    note.dispose();
    method.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => _DialogShell(
    title: widget.payment == null ? 'Ödeme ekle' : 'Ödemeyi düzenle',
    formKey: key,
    children: [
      Text(
        'Kalan tutar: ${money(widget.remainingAmount)}',
        style: const TextStyle(fontWeight: FontWeight.w800),
      ),
      _MoneyField(
        controller: amount,
        label: 'Ödeme tutarı',
        validator: (v) => _moneyValidator(v, 'Ödeme tutarı'),
      ),
      _DateField(
        label: 'Ödeme tarihi',
        value: paidAt,
        onChanged: (v) => setState(() => paidAt = v),
      ),
      TextFormField(
        controller: method,
        maxLength: 80,
        decoration: const InputDecoration(
          labelText: 'Ödeme yöntemi (opsiyonel)',
        ),
      ),
      TextFormField(
        controller: note,
        maxLength: 240,
        minLines: 2,
        maxLines: 5,
        decoration: const InputDecoration(labelText: 'Ödeme notu (opsiyonel)'),
      ),
    ],
    onSave: () => widget.payment == null
        ? widget.controller.addPayment(
            personId: widget.personId,
            type: widget.type,
            sourceId: widget.sourceId,
            amount: parseMoney(amount.text),
            paidAt: paidAt,
            note: note.text,
            method: method.text,
          )
        : widget.controller.updatePayment(
            personId: widget.personId,
            type: widget.type,
            sourceId: widget.sourceId,
            paymentId: widget.payment!.id,
            amount: parseMoney(amount.text),
            paidAt: paidAt,
            note: note.text,
            method: method.text,
          ),
  );
}

class _MoneyField extends StatelessWidget {
  const _MoneyField({
    required this.controller,
    required this.label,
    this.validator,
    this.requiredValue = true,
  });
  final TextEditingController controller;
  final String label;
  final String? Function(String?)? validator;
  final bool requiredValue;
  @override
  Widget build(BuildContext context) => TextFormField(
    controller: controller,
    keyboardType: const TextInputType.numberWithOptions(decimal: true),
    inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.,\s]'))],
    decoration: InputDecoration(labelText: label, suffixText: 'TL'),
    validator:
        validator ??
        (requiredValue
            ? (v) => _moneyValidator(v, label)
            : (v) {
                if (v == null || v.trim().isEmpty) return null;
                return _moneyValidator(v, label, allowZero: true);
              }),
  );
}

class _DateField extends StatelessWidget {
  const _DateField({
    required this.label,
    required this.value,
    required this.onChanged,
  });
  final String label;
  final DateTime value;
  final ValueChanged<DateTime> onChanged;
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: () async {
      final selected = await showDatePicker(
        context: context,
        initialDate: value,
        firstDate: DateTime(2000),
        lastDate: DateTime(2100),
      );
      if (selected != null) onChanged(selected);
    },
    borderRadius: BorderRadius.circular(14),
    child: InputDecorator(
      decoration: InputDecoration(
        labelText: label,
        suffixIcon: const Icon(Icons.calendar_month_outlined),
      ),
      child: Text(
        shortDate(value),
        style: const TextStyle(fontWeight: FontWeight.w800),
      ),
    ),
  );
}

class _OptionalDateField extends StatelessWidget {
  const _OptionalDateField({
    required this.label,
    required this.value,
    required this.onChanged,
  });
  final String label;
  final DateTime? value;
  final ValueChanged<DateTime?> onChanged;
  @override
  Widget build(BuildContext context) => Row(
    children: [
      Expanded(
        child: InkWell(
          onTap: () async {
            final selected = await showDatePicker(
              context: context,
              initialDate: value ?? DateTime.now(),
              firstDate: DateTime(2000),
              lastDate: DateTime(2100),
            );
            if (selected != null) onChanged(selected);
          },
          borderRadius: BorderRadius.circular(14),
          child: InputDecorator(
            decoration: InputDecoration(
              labelText: label,
              suffixIcon: const Icon(Icons.calendar_month_outlined),
            ),
            child: Text(
              value == null ? 'Seçilmedi' : shortDate(value!),
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
          ),
        ),
      ),
      if (value != null)
        IconButton(
          tooltip: 'Tarihi temizle',
          onPressed: () => onChanged(null),
          icon: const Icon(Icons.clear),
        ),
    ],
  );
}

class _TwoColumn extends StatelessWidget {
  const _TwoColumn({required this.left, required this.right});
  final Widget left;
  final Widget right;
  @override
  Widget build(BuildContext context) => Builder(
    builder: (context) {
      final narrow =
          MediaQuery.sizeOf(context).width < 600 ||
          MediaQuery.textScalerOf(context).scale(1) > 1.3;
      if (narrow) {
        return Column(children: [left, const SizedBox(height: 12), right]);
      }
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(child: left),
          const SizedBox(width: 12),
          Expanded(child: right),
        ],
      );
    },
  );
}
