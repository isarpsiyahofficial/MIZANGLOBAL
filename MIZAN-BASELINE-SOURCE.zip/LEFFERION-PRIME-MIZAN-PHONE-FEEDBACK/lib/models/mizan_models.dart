const int currentSchemaVersion = 5;

DateTime _dateOnly(DateTime value) =>
    DateTime(value.year, value.month, value.day);

DateTime _dayOfMonth(DateTime month, int requestedDay) {
  final lastDay = DateTime(month.year, month.month + 1, 0).day;
  final day = requestedDay.clamp(1, lastDay).toInt();
  return DateTime(month.year, month.month, day);
}

int _daysUntil(DateTime dueDate, DateTime reference) =>
    _dateOnly(dueDate).difference(_dateOnly(reference)).inDays;

double _safeAmount(num? value) {
  final parsed = value?.toDouble() ?? 0;
  if (!parsed.isFinite || parsed < 0) {
    return 0;
  }
  return double.parse(parsed.toStringAsFixed(2));
}

String _string(dynamic value, {String fallback = ''}) =>
    value is String ? value : fallback;

int? _intOrNull(dynamic value) {
  if (value is int) {
    return value;
  }
  if (value is num) {
    return value.toInt();
  }
  return int.tryParse(value?.toString() ?? '');
}

DateTime _date(dynamic value, {DateTime? fallback}) {
  if (value is DateTime) {
    return value;
  }
  if (value is String) {
    final parsed = DateTime.tryParse(value);
    if (parsed != null) {
      return parsed;
    }
  }
  return fallback ?? DateTime.now();
}

DateTime? _dateOrNull(dynamic value) {
  if (value == null) {
    return null;
  }
  if (value is DateTime) {
    return value;
  }
  if (value is String) {
    return DateTime.tryParse(value);
  }
  return null;
}

enum PaymentStatus {
  active('Aktif'),
  upcoming('Yaklaşıyor'),
  overdue('Gecikmede'),
  completed('Tamamlandı'),
  passive('Pasif');

  const PaymentStatus(this.label);
  final String label;
}

enum DebtKind {
  overdraft('KMH hesabı'),
  creditCard('Kredi kartı'),
  loan('Kredi'),
  vehicleLoan('Araç kredisi'),
  mortgage('Ev kredisi'),
  cashAdvance('Nakit avans'),
  installmentCashAdvance('Taksitli nakit avans'),
  custom('Özel borç türü');

  const DebtKind(this.label);
  final String label;
}

enum DebtDueMode {
  fixedDate('Son ödeme tarihi'),
  monthlyDay('Her ayın belirli günü');

  const DebtDueMode(this.label);
  final String label;
}

enum BillKind {
  electricity('Elektrik'),
  water('Su'),
  phone('Telefon'),
  internet('İnternet'),
  naturalGas('Doğalgaz'),
  custom('Özel fatura');

  const BillKind(this.label);
  final String label;
}

enum CreditorType {
  person('Kişi'),
  companyInstitution('Şirket / Kurum'),
  cheque('Çek'),
  promissoryNote('Senet'),
  merchantBusiness('Esnaf / İşletme'),
  familyRelative('Aile / Yakın'),
  other('Diğer');

  const CreditorType(this.label);
  final String label;
}

enum PaymentFrequency {
  oneTime('Tek ödeme'),
  weekly('Haftalık'),
  biweekly('İki haftada bir'),
  monthly('Aylık'),
  quarterly('Üç aylık'),
  yearly('Yıllık'),
  custom('Özel aralık');

  const PaymentFrequency(this.label);
  final String label;
}

enum SubscriptionKind {
  digitalService('Dijital hizmet'),
  membership('Üyelik'),
  insurance('Sigorta'),
  education('Eğitim'),
  maintenance('Bakım / servis'),
  custom('Diğer abonelik');

  const SubscriptionKind(this.label);
  final String label;
}

enum RecordType {
  debt('Banka borcu'),
  personalDebt('Kişisel / kurumsal borç'),
  bill('Fatura'),
  subscription('Abonelik'),
  rent('Kira / taksit');

  const RecordType(this.label);
  final String label;
}

class PaymentRecord {
  const PaymentRecord({
    required this.id,
    required this.amount,
    required this.paidAt,
    this.note = '',
    this.method = '',
    this.appliesToDueDate,
  });

  final String id;
  final double amount;
  final DateTime paidAt;
  final String note;
  final String method;
  final DateTime? appliesToDueDate;

  PaymentRecord copyWith({
    double? amount,
    DateTime? paidAt,
    String? note,
    String? method,
    DateTime? appliesToDueDate,
    bool clearAppliesToDueDate = false,
  }) {
    return PaymentRecord(
      id: id,
      amount: amount ?? this.amount,
      paidAt: paidAt ?? this.paidAt,
      note: note ?? this.note,
      method: method ?? this.method,
      appliesToDueDate: clearAppliesToDueDate
          ? null
          : appliesToDueDate ?? this.appliesToDueDate,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'amount': amount,
    'paidAt': paidAt.toIso8601String(),
    'note': note,
    'method': method,
    'appliesToDueDate': appliesToDueDate?.toIso8601String(),
  };

  factory PaymentRecord.fromJson(Map<String, dynamic> json) {
    return PaymentRecord(
      id: _string(json['id']),
      amount: _safeAmount(json['amount'] as num?),
      paidAt: _date(json['paidAt']),
      note: _string(json['note']),
      method: _string(json['method']),
      appliesToDueDate: _dateOrNull(json['appliesToDueDate']),
    );
  }
}

class RecordNote {
  const RecordNote({
    required this.id,
    required this.text,
    required this.createdAt,
  });

  final String id;
  final String text;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {
    'id': id,
    'text': text,
    'createdAt': createdAt.toIso8601String(),
  };

  factory RecordNote.fromJson(Map<String, dynamic> json) {
    return RecordNote(
      id: _string(json['id']),
      text: _string(json['text']),
      createdAt: _date(json['createdAt']),
    );
  }
}

class DebtProduct {
  const DebtProduct({
    required this.id,
    required this.kind,
    required this.title,
    required this.totalAmount,
    required this.monthlyAmount,
    required this.dueDate,
    this.dueMode = DebtDueMode.fixedDate,
    this.dueDayOfMonth,
    this.customKindName = '',
    this.installmentCount,
    this.currentInstallment,
    this.limit,
    this.usedLimit,
    this.description = '',
    this.isArchived = false,
    this.payments = const [],
    this.notes = const [],
  });

  final String id;
  final DebtKind kind;
  final String title;
  final String customKindName;
  final double totalAmount;
  final double monthlyAmount;
  final DateTime dueDate;
  final DebtDueMode dueMode;
  final int? dueDayOfMonth;
  final int? installmentCount;
  final int? currentInstallment;
  final double? limit;
  final double? usedLimit;
  final String description;
  final bool isArchived;
  final List<PaymentRecord> payments;
  final List<RecordNote> notes;

  double get paidAmount =>
      payments.fold<double>(0.0, (sum, item) => sum + item.amount);

  double get remainingAmount {
    final value = totalAmount - paidAmount;
    return value <= 0 ? 0 : double.parse(value.toStringAsFixed(2));
  }

  double get scheduledPaymentAmount {
    if (remainingAmount <= 0) return 0;
    final planned = monthlyAmount > 0 ? monthlyAmount : remainingAmount;
    return planned > remainingAmount ? remainingAmount : planned;
  }

  double paidInMonth(DateTime month) => payments
      .where(
        (item) =>
            item.paidAt.year == month.year && item.paidAt.month == month.month,
      )
      .fold<double>(0.0, (sum, item) => sum + item.amount);

  double dueAmountAt(DateTime reference) {
    if (remainingAmount <= 0) return 0;
    if (dueMode == DebtDueMode.fixedDate) return scheduledPaymentAmount;
    final cycleRemaining = scheduledPaymentAmount - paidInMonth(reference);
    if (cycleRemaining <= 0) return scheduledPaymentAmount;
    return cycleRemaining > remainingAmount ? remainingAmount : cycleRemaining;
  }

  DateTime dueDateForMonth(DateTime month) =>
      _dayOfMonth(month, dueDayOfMonth ?? dueDate.day);

  DateTime effectiveDueDateAt(DateTime reference) {
    if (dueMode == DebtDueMode.fixedDate) return dueDate;
    final currentDue = dueDateForMonth(reference);
    final paidThisMonth = paidInMonth(reference);
    if (paidThisMonth + 0.001 < scheduledPaymentAmount) return currentDue;
    return dueDateForMonth(DateTime(reference.year, reference.month + 1));
  }

  int overdueDaysAt(DateTime reference) {
    final effectiveDueDate = effectiveDueDateAt(reference);
    if (remainingAmount <= 0 ||
        !_dateOnly(effectiveDueDate).isBefore(_dateOnly(reference))) {
      return 0;
    }
    return _dateOnly(reference).difference(_dateOnly(effectiveDueDate)).inDays;
  }

  PaymentStatus statusAt(DateTime reference) {
    if (isArchived) return PaymentStatus.passive;
    if (remainingAmount <= 0) return PaymentStatus.completed;
    final days = _daysUntil(effectiveDueDateAt(reference), reference);
    if (days < 0) return PaymentStatus.overdue;
    if (days <= 5) return PaymentStatus.upcoming;
    return PaymentStatus.active;
  }

  PaymentStatus get status => statusAt(DateTime.now());

  String get displayKind =>
      kind == DebtKind.custom && customKindName.trim().isNotEmpty
      ? customKindName.trim()
      : kind.label;

  String get dueRuleLabel => dueMode == DebtDueMode.monthlyDay
      ? 'Her ayın ${dueDayOfMonth ?? dueDate.day}. günü'
      : 'Son ödeme ${_dateOnly(dueDate).day.toString().padLeft(2, '0')}.${_dateOnly(dueDate).month.toString().padLeft(2, '0')}.${dueDate.year}';

  bool isDueInMonth(DateTime month) =>
      remainingAmount > 0 &&
      (dueMode == DebtDueMode.monthlyDay ||
          (dueDate.year == month.year && dueDate.month == month.month));

  DebtProduct copyWith({
    DebtKind? kind,
    String? title,
    String? customKindName,
    double? totalAmount,
    double? monthlyAmount,
    DateTime? dueDate,
    DebtDueMode? dueMode,
    int? dueDayOfMonth,
    bool clearDueDayOfMonth = false,
    int? installmentCount,
    int? currentInstallment,
    double? limit,
    double? usedLimit,
    String? description,
    bool? isArchived,
    List<PaymentRecord>? payments,
    List<RecordNote>? notes,
  }) {
    return DebtProduct(
      id: id,
      kind: kind ?? this.kind,
      title: title ?? this.title,
      customKindName: customKindName ?? this.customKindName,
      totalAmount: totalAmount ?? this.totalAmount,
      monthlyAmount: monthlyAmount ?? this.monthlyAmount,
      dueDate: dueDate ?? this.dueDate,
      dueMode: dueMode ?? this.dueMode,
      dueDayOfMonth: clearDueDayOfMonth
          ? null
          : dueDayOfMonth ?? this.dueDayOfMonth,
      installmentCount: installmentCount ?? this.installmentCount,
      currentInstallment: currentInstallment ?? this.currentInstallment,
      limit: limit ?? this.limit,
      usedLimit: usedLimit ?? this.usedLimit,
      description: description ?? this.description,
      isArchived: isArchived ?? this.isArchived,
      payments: payments ?? this.payments,
      notes: notes ?? this.notes,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'kind': kind.name,
    'title': title,
    'customKindName': customKindName,
    'totalAmount': totalAmount,
    'monthlyAmount': monthlyAmount,
    'dueDate': dueDate.toIso8601String(),
    'dueMode': dueMode.name,
    'dueDayOfMonth': dueDayOfMonth,
    'installmentCount': installmentCount,
    'currentInstallment': currentInstallment,
    'limit': limit,
    'usedLimit': usedLimit,
    'description': description,
    'isArchived': isArchived,
    'payments': payments.map((item) => item.toJson()).toList(),
    'notes': notes.map((item) => item.toJson()).toList(),
  };

  factory DebtProduct.fromJson(Map<String, dynamic> json) {
    final kindName = _string(json['kind'], fallback: DebtKind.custom.name);
    final dueModeName = _string(
      json['dueMode'],
      fallback: DebtDueMode.fixedDate.name,
    );
    return DebtProduct(
      id: _string(json['id']),
      kind: DebtKind.values.firstWhere(
        (item) => item.name == kindName,
        orElse: () => DebtKind.custom,
      ),
      title: _string(json['title']),
      customKindName: _string(json['customKindName']),
      totalAmount: _safeAmount(json['totalAmount'] as num?),
      monthlyAmount: _safeAmount(json['monthlyAmount'] as num?),
      dueDate: _date(json['dueDate']),
      dueMode: DebtDueMode.values.firstWhere(
        (item) => item.name == dueModeName,
        orElse: () => DebtDueMode.fixedDate,
      ),
      dueDayOfMonth: _intOrNull(json['dueDayOfMonth']),
      installmentCount: _intOrNull(json['installmentCount']),
      currentInstallment: _intOrNull(json['currentInstallment']),
      limit: json['limit'] is num ? _safeAmount(json['limit'] as num) : null,
      usedLimit: json['usedLimit'] is num
          ? _safeAmount(json['usedLimit'] as num)
          : null,
      description: _string(
        json['description'],
        fallback: _string(json['note']),
      ),
      isArchived: json['isArchived'] as bool? ?? false,
      payments: _paymentList(json['payments']),
      notes: _noteList(json['notes']),
    );
  }
}

class BankGroup {
  const BankGroup({
    required this.id,
    required this.userWrittenName,
    this.products = const [],
  });

  final String id;
  final String userWrittenName;
  final List<DebtProduct> products;

  double get totalDebt => products
      .where((product) => !product.isArchived)
      .fold<double>(0.0, (sum, product) => sum + product.remainingAmount);

  double monthlyLoadFor(DateTime month) => products
      .where(
        (product) =>
            !product.isArchived &&
            product.remainingAmount > 0 &&
            product.isDueInMonth(month),
      )
      .fold<double>(
        0.0,
        (sum, product) => sum + product.scheduledPaymentAmount,
      );

  BankGroup copyWith({String? userWrittenName, List<DebtProduct>? products}) {
    return BankGroup(
      id: id,
      userWrittenName: userWrittenName ?? this.userWrittenName,
      products: products ?? this.products,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'userWrittenName': userWrittenName,
    'products': products.map((item) => item.toJson()).toList(),
  };

  factory BankGroup.fromJson(Map<String, dynamic> json) {
    return BankGroup(
      id: _string(json['id']),
      userWrittenName: _string(json['userWrittenName']),
      products: ((json['products'] as List?) ?? const [])
          .whereType<Map>()
          .map((item) => DebtProduct.fromJson(Map<String, dynamic>.from(item)))
          .toList(growable: false),
    );
  }
}

class BillEntry {
  const BillEntry({
    required this.id,
    required this.kind,
    required this.institutionName,
    required this.amount,
    required this.dueDate,
    this.subscriberNumber = '',
    this.contractNumber = '',
    this.description = '',
    this.isArchived = false,
    this.payments = const [],
    this.notes = const [],
  });

  final String id;
  final BillKind kind;
  final String institutionName;
  final String subscriberNumber;
  final String contractNumber;
  final double amount;
  final DateTime dueDate;
  final String description;
  final bool isArchived;
  final List<PaymentRecord> payments;
  final List<RecordNote> notes;

  double get paidAmount =>
      payments.fold<double>(0.0, (sum, item) => sum + item.amount);

  double get remainingAmount {
    final value = amount - paidAmount;
    return value <= 0 ? 0 : double.parse(value.toStringAsFixed(2));
  }

  PaymentStatus statusAt(DateTime reference) {
    if (isArchived) {
      return PaymentStatus.passive;
    }
    if (remainingAmount <= 0) {
      return PaymentStatus.completed;
    }
    final days = _daysUntil(dueDate, reference);
    if (days < 0) {
      return PaymentStatus.overdue;
    }
    if (days <= 5) {
      return PaymentStatus.upcoming;
    }
    return PaymentStatus.active;
  }

  PaymentStatus get status => statusAt(DateTime.now());

  bool isDueInMonth(DateTime month) =>
      dueDate.year == month.year && dueDate.month == month.month;

  BillEntry copyWith({
    BillKind? kind,
    String? institutionName,
    String? subscriberNumber,
    String? contractNumber,
    double? amount,
    DateTime? dueDate,
    String? description,
    bool? isArchived,
    List<PaymentRecord>? payments,
    List<RecordNote>? notes,
  }) {
    return BillEntry(
      id: id,
      kind: kind ?? this.kind,
      institutionName: institutionName ?? this.institutionName,
      subscriberNumber: subscriberNumber ?? this.subscriberNumber,
      contractNumber: contractNumber ?? this.contractNumber,
      amount: amount ?? this.amount,
      dueDate: dueDate ?? this.dueDate,
      description: description ?? this.description,
      isArchived: isArchived ?? this.isArchived,
      payments: payments ?? this.payments,
      notes: notes ?? this.notes,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'kind': kind.name,
    'institutionName': institutionName,
    'subscriberNumber': subscriberNumber,
    'contractNumber': contractNumber,
    'amount': amount,
    'dueDate': dueDate.toIso8601String(),
    'description': description,
    'isArchived': isArchived,
    'payments': payments.map((item) => item.toJson()).toList(),
    'notes': notes.map((item) => item.toJson()).toList(),
  };

  factory BillEntry.fromJson(Map<String, dynamic> json) {
    final kindName = _string(json['kind'], fallback: BillKind.custom.name);
    final legacyPaidAt = _dateOrNull(json['paidAt']);
    final payments = _paymentList(json['payments']).toList();
    if (legacyPaidAt != null && payments.isEmpty) {
      payments.add(
        PaymentRecord(
          id: 'legacy-${_string(json['id'])}',
          amount: _safeAmount(json['amount'] as num?),
          paidAt: legacyPaidAt,
          note: 'Eski kayıttan aktarıldı',
        ),
      );
    }
    return BillEntry(
      id: _string(json['id']),
      kind: BillKind.values.firstWhere(
        (item) => item.name == kindName,
        orElse: () => BillKind.custom,
      ),
      institutionName: _string(json['institutionName']),
      subscriberNumber: _string(json['subscriberNumber']),
      contractNumber: _string(json['contractNumber']),
      amount: _safeAmount(json['amount'] as num?),
      dueDate: _date(json['dueDate']),
      description: _string(json['description']),
      isArchived: json['isArchived'] as bool? ?? false,
      payments: payments,
      notes: _noteList(json['notes']),
    );
  }
}

class RentEntry {
  const RentEntry({
    required this.id,
    required this.title,
    required this.amount,
    required this.paymentDay,
    required this.receiverName,
    required this.dueDate,
    this.iban = '',
    this.contractStart,
    this.contractEnd,
    this.increaseDate,
    this.installmentCount,
    this.currentInstallment,
    this.description = '',
    this.isArchived = false,
    this.payments = const [],
    this.notes = const [],
  });

  final String id;
  final String title;
  final double amount;
  final int paymentDay;
  final String receiverName;
  final String iban;
  final DateTime dueDate;
  final DateTime? contractStart;
  final DateTime? contractEnd;
  final DateTime? increaseDate;
  final int? installmentCount;
  final int? currentInstallment;
  final String description;
  final bool isArchived;
  final List<PaymentRecord> payments;
  final List<RecordNote> notes;

  double get paidAmount =>
      payments.fold<double>(0.0, (sum, item) => sum + item.amount);

  double get remainingAmount {
    final value = amount - paidAmount;
    return value <= 0 ? 0 : double.parse(value.toStringAsFixed(2));
  }

  PaymentStatus statusAt(DateTime reference) {
    if (isArchived) {
      return PaymentStatus.passive;
    }
    if (remainingAmount <= 0) return PaymentStatus.completed;
    final days = _daysUntil(dueDate, reference);
    if (days < 0) {
      return PaymentStatus.overdue;
    }
    if (days <= 5) {
      return PaymentStatus.upcoming;
    }
    return PaymentStatus.active;
  }

  PaymentStatus get status => statusAt(DateTime.now());

  bool isDueInMonth(DateTime month) =>
      dueDate.year == month.year && dueDate.month == month.month;

  RentEntry copyWith({
    String? title,
    double? amount,
    int? paymentDay,
    String? receiverName,
    String? iban,
    DateTime? dueDate,
    DateTime? contractStart,
    DateTime? contractEnd,
    DateTime? increaseDate,
    int? installmentCount,
    int? currentInstallment,
    String? description,
    bool? isArchived,
    List<PaymentRecord>? payments,
    List<RecordNote>? notes,
  }) {
    return RentEntry(
      id: id,
      title: title ?? this.title,
      amount: amount ?? this.amount,
      paymentDay: paymentDay ?? this.paymentDay,
      receiverName: receiverName ?? this.receiverName,
      iban: iban ?? this.iban,
      dueDate: dueDate ?? this.dueDate,
      contractStart: contractStart ?? this.contractStart,
      contractEnd: contractEnd ?? this.contractEnd,
      increaseDate: increaseDate ?? this.increaseDate,
      installmentCount: installmentCount ?? this.installmentCount,
      currentInstallment: currentInstallment ?? this.currentInstallment,
      description: description ?? this.description,
      isArchived: isArchived ?? this.isArchived,
      payments: payments ?? this.payments,
      notes: notes ?? this.notes,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'amount': amount,
    'paymentDay': paymentDay,
    'receiverName': receiverName,
    'iban': iban,
    'dueDate': dueDate.toIso8601String(),
    'contractStart': contractStart?.toIso8601String(),
    'contractEnd': contractEnd?.toIso8601String(),
    'increaseDate': increaseDate?.toIso8601String(),
    'installmentCount': installmentCount,
    'currentInstallment': currentInstallment,
    'description': description,
    'isArchived': isArchived,
    'payments': payments.map((item) => item.toJson()).toList(),
    'notes': notes.map((item) => item.toJson()).toList(),
  };

  factory RentEntry.fromJson(Map<String, dynamic> json) {
    return RentEntry(
      id: _string(json['id']),
      title: _string(json['title']),
      amount: _safeAmount(json['amount'] as num?),
      paymentDay: (_intOrNull(json['paymentDay']) ?? 1).clamp(1, 31).toInt(),
      receiverName: _string(json['receiverName']),
      iban: _string(json['iban']),
      dueDate: _date(json['dueDate']),
      contractStart: _dateOrNull(json['contractStart']),
      contractEnd: _dateOrNull(json['contractEnd']),
      increaseDate: _dateOrNull(json['increaseDate']),
      installmentCount: _intOrNull(json['installmentCount']),
      currentInstallment: _intOrNull(json['currentInstallment']),
      description: _string(json['description']),
      isArchived: json['isArchived'] as bool? ?? false,
      payments: _paymentList(json['payments']),
      notes: _noteList(json['notes']),
    );
  }
}

class DueScheduleItem {
  const DueScheduleItem({
    required this.id,
    required this.label,
    required this.amount,
    required this.dueDate,
    this.isCompleted = false,
  });

  final String id;
  final String label;
  final double amount;
  final DateTime dueDate;
  final bool isCompleted;

  DueScheduleItem copyWith({
    String? label,
    double? amount,
    DateTime? dueDate,
    bool? isCompleted,
  }) => DueScheduleItem(
    id: id,
    label: label ?? this.label,
    amount: amount ?? this.amount,
    dueDate: dueDate ?? this.dueDate,
    isCompleted: isCompleted ?? this.isCompleted,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'label': label,
    'amount': amount,
    'dueDate': dueDate.toIso8601String(),
    'isCompleted': isCompleted,
  };

  factory DueScheduleItem.fromJson(Map<String, dynamic> json) =>
      DueScheduleItem(
        id: _string(json['id']),
        label: _string(json['label']),
        amount: _safeAmount(json['amount'] as num?),
        dueDate: _date(json['dueDate']),
        isCompleted: json['isCompleted'] as bool? ?? false,
      );
}

class PersonalDebtEntry {
  const PersonalDebtEntry({
    required this.id,
    required this.creditorType,
    required this.title,
    required this.creditorName,
    required this.totalAmount,
    required this.debtDate,
    required this.dueDate,
    required this.frequency,
    this.isInstallment = false,
    this.installmentCount,
    this.currentInstallment,
    this.monthlyAmount = 0,
    this.customFrequencyDays,
    this.description = '',
    this.chequeNumber = '',
    this.issuerName = '',
    this.bankInfo = '',
    this.promissoryNoteNumber = '',
    this.documentCount,
    this.currentDocument,
    this.schedule = const [],
    this.isArchived = false,
    this.payments = const [],
    this.notes = const [],
  });

  final String id;
  final CreditorType creditorType;
  final String title;
  final String creditorName;
  final double totalAmount;
  final DateTime debtDate;
  final DateTime dueDate;
  final PaymentFrequency frequency;
  final bool isInstallment;
  final int? installmentCount;
  final int? currentInstallment;
  final double monthlyAmount;
  final int? customFrequencyDays;
  final String description;
  final String chequeNumber;
  final String issuerName;
  final String bankInfo;
  final String promissoryNoteNumber;
  final int? documentCount;
  final int? currentDocument;
  final List<DueScheduleItem> schedule;
  final bool isArchived;
  final List<PaymentRecord> payments;
  final List<RecordNote> notes;

  double get paidAmount =>
      payments.fold<double>(0, (sum, item) => sum + item.amount);
  double get remainingAmount {
    final value = totalAmount - paidAmount;
    return value <= 0 ? 0 : double.parse(value.toStringAsFixed(2));
  }

  PaymentStatus statusAt(DateTime reference) {
    if (isArchived) return PaymentStatus.passive;
    if (remainingAmount <= 0) return PaymentStatus.completed;
    final days = _daysUntil(effectiveDueDate, reference);
    if (days < 0) return PaymentStatus.overdue;
    if (days <= 5) return PaymentStatus.upcoming;
    return PaymentStatus.active;
  }

  PaymentStatus get status => statusAt(DateTime.now());

  List<DueScheduleItem> get resolvedSchedule {
    var unallocatedPayment = paidAmount;
    return schedule
        .map((item) {
          final completed = unallocatedPayment + 0.001 >= item.amount;
          unallocatedPayment = (unallocatedPayment - item.amount)
              .clamp(0.0, double.infinity)
              .toDouble();
          return item.copyWith(isCompleted: completed);
        })
        .toList(growable: false);
  }

  DateTime get effectiveDueDate {
    final openItems =
        resolvedSchedule.where((item) => !item.isCompleted).toList()
          ..sort((a, b) => a.dueDate.compareTo(b.dueDate));
    return openItems.isEmpty ? dueDate : openItems.first.dueDate;
  }

  double get effectiveDueAmount {
    if (remainingAmount <= 0) return 0;
    if (schedule.isEmpty) {
      final planned = monthlyAmount > 0 ? monthlyAmount : remainingAmount;
      return planned > remainingAmount ? remainingAmount : planned;
    }
    var unallocatedPayment = paidAmount;
    final sorted = [...schedule]
      ..sort((a, b) => a.dueDate.compareTo(b.dueDate));
    for (final item in sorted) {
      final openAmount = item.amount - unallocatedPayment;
      if (openAmount > 0.001) {
        return openAmount > remainingAmount ? remainingAmount : openAmount;
      }
      unallocatedPayment = (unallocatedPayment - item.amount)
          .clamp(0.0, double.infinity)
          .toDouble();
    }
    return remainingAmount;
  }

  String get displayCreditor =>
      creditorName.trim().isEmpty ? creditorType.label : creditorName.trim();

  bool isDueInMonth(DateTime month) =>
      effectiveDueDate.year == month.year &&
      effectiveDueDate.month == month.month;

  PersonalDebtEntry copyWith({
    CreditorType? creditorType,
    String? title,
    String? creditorName,
    double? totalAmount,
    DateTime? debtDate,
    DateTime? dueDate,
    PaymentFrequency? frequency,
    bool? isInstallment,
    int? installmentCount,
    int? currentInstallment,
    double? monthlyAmount,
    int? customFrequencyDays,
    String? description,
    String? chequeNumber,
    String? issuerName,
    String? bankInfo,
    String? promissoryNoteNumber,
    int? documentCount,
    int? currentDocument,
    List<DueScheduleItem>? schedule,
    bool? isArchived,
    List<PaymentRecord>? payments,
    List<RecordNote>? notes,
  }) => PersonalDebtEntry(
    id: id,
    creditorType: creditorType ?? this.creditorType,
    title: title ?? this.title,
    creditorName: creditorName ?? this.creditorName,
    totalAmount: totalAmount ?? this.totalAmount,
    debtDate: debtDate ?? this.debtDate,
    dueDate: dueDate ?? this.dueDate,
    frequency: frequency ?? this.frequency,
    isInstallment: isInstallment ?? this.isInstallment,
    installmentCount: installmentCount ?? this.installmentCount,
    currentInstallment: currentInstallment ?? this.currentInstallment,
    monthlyAmount: monthlyAmount ?? this.monthlyAmount,
    customFrequencyDays: customFrequencyDays ?? this.customFrequencyDays,
    description: description ?? this.description,
    chequeNumber: chequeNumber ?? this.chequeNumber,
    issuerName: issuerName ?? this.issuerName,
    bankInfo: bankInfo ?? this.bankInfo,
    promissoryNoteNumber: promissoryNoteNumber ?? this.promissoryNoteNumber,
    documentCount: documentCount ?? this.documentCount,
    currentDocument: currentDocument ?? this.currentDocument,
    schedule: schedule ?? this.schedule,
    isArchived: isArchived ?? this.isArchived,
    payments: payments ?? this.payments,
    notes: notes ?? this.notes,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'creditorType': creditorType.name,
    'title': title,
    'creditorName': creditorName,
    'totalAmount': totalAmount,
    'debtDate': debtDate.toIso8601String(),
    'dueDate': dueDate.toIso8601String(),
    'frequency': frequency.name,
    'isInstallment': isInstallment,
    'installmentCount': installmentCount,
    'currentInstallment': currentInstallment,
    'monthlyAmount': monthlyAmount,
    'customFrequencyDays': customFrequencyDays,
    'description': description,
    'chequeNumber': chequeNumber,
    'issuerName': issuerName,
    'bankInfo': bankInfo,
    'promissoryNoteNumber': promissoryNoteNumber,
    'documentCount': documentCount,
    'currentDocument': currentDocument,
    'schedule': schedule.map((item) => item.toJson()).toList(),
    'isArchived': isArchived,
    'payments': payments.map((item) => item.toJson()).toList(),
    'notes': notes.map((item) => item.toJson()).toList(),
  };

  factory PersonalDebtEntry.fromJson(Map<String, dynamic> json) {
    final creditorName = _string(
      json['creditorType'],
      fallback: CreditorType.other.name,
    );
    final frequencyName = _string(
      json['frequency'],
      fallback: PaymentFrequency.oneTime.name,
    );
    return PersonalDebtEntry(
      id: _string(json['id']),
      creditorType: CreditorType.values.firstWhere(
        (item) => item.name == creditorName,
        orElse: () => CreditorType.other,
      ),
      title: _string(json['title']),
      creditorName: _string(json['creditorName']),
      totalAmount: _safeAmount(json['totalAmount'] as num?),
      debtDate: _date(json['debtDate']),
      dueDate: _date(json['dueDate']),
      frequency: PaymentFrequency.values.firstWhere(
        (item) => item.name == frequencyName,
        orElse: () => PaymentFrequency.oneTime,
      ),
      isInstallment: json['isInstallment'] as bool? ?? false,
      installmentCount: _intOrNull(json['installmentCount']),
      currentInstallment: _intOrNull(json['currentInstallment']),
      monthlyAmount: _safeAmount(json['monthlyAmount'] as num?),
      customFrequencyDays: _intOrNull(json['customFrequencyDays']),
      description: _string(json['description']),
      chequeNumber: _string(json['chequeNumber']),
      issuerName: _string(json['issuerName']),
      bankInfo: _string(json['bankInfo']),
      promissoryNoteNumber: _string(json['promissoryNoteNumber']),
      documentCount: _intOrNull(json['documentCount']),
      currentDocument: _intOrNull(json['currentDocument']),
      schedule: ((json['schedule'] as List?) ?? const [])
          .whereType<Map>()
          .map(
            (item) => DueScheduleItem.fromJson(Map<String, dynamic>.from(item)),
          )
          .toList(growable: false),
      isArchived: json['isArchived'] as bool? ?? false,
      payments: _paymentList(json['payments']),
      notes: _noteList(json['notes']),
    );
  }
}

class SubscriptionEntry {
  const SubscriptionEntry({
    required this.id,
    required this.kind,
    required this.title,
    required this.providerName,
    required this.amount,
    required this.frequency,
    required this.nextDueDate,
    this.customKindName = '',
    this.customFrequencyDays,
    this.subscriberNumber = '',
    this.contractNumber = '',
    this.description = '',
    this.isArchived = false,
    this.payments = const [],
    this.notes = const [],
  });

  final String id;
  final SubscriptionKind kind;
  final String title;
  final String providerName;
  final double amount;
  final PaymentFrequency frequency;
  final DateTime nextDueDate;
  final String customKindName;
  final int? customFrequencyDays;
  final String subscriberNumber;
  final String contractNumber;
  final String description;
  final bool isArchived;
  final List<PaymentRecord> payments;
  final List<RecordNote> notes;

  double get paidAmount =>
      payments.fold<double>(0.0, (sum, item) => sum + item.amount);

  double get currentCyclePaid => payments
      .where(
        (item) =>
            item.appliesToDueDate != null &&
            _dateOnly(item.appliesToDueDate!) == _dateOnly(nextDueDate),
      )
      .fold<double>(0.0, (sum, item) => sum + item.amount);

  double get remainingAmount {
    if (isArchived) return 0;
    final value = amount - currentCyclePaid;
    return value <= 0 ? 0 : double.parse(value.toStringAsFixed(2));
  }

  PaymentStatus statusAt(DateTime reference) {
    if (isArchived) return PaymentStatus.passive;
    if (remainingAmount <= 0) return PaymentStatus.completed;
    final days = _daysUntil(nextDueDate, reference);
    if (days < 0) return PaymentStatus.overdue;
    if (days <= 5) return PaymentStatus.upcoming;
    return PaymentStatus.active;
  }

  PaymentStatus get status => statusAt(DateTime.now());
  bool isDueInMonth(DateTime month) =>
      nextDueDate.year == month.year && nextDueDate.month == month.month;
  String get displayKind =>
      kind == SubscriptionKind.custom && customKindName.trim().isNotEmpty
      ? customKindName.trim()
      : kind.label;

  SubscriptionEntry copyWith({
    SubscriptionKind? kind,
    String? title,
    String? providerName,
    double? amount,
    PaymentFrequency? frequency,
    DateTime? nextDueDate,
    String? customKindName,
    int? customFrequencyDays,
    String? subscriberNumber,
    String? contractNumber,
    String? description,
    bool? isArchived,
    List<PaymentRecord>? payments,
    List<RecordNote>? notes,
  }) => SubscriptionEntry(
    id: id,
    kind: kind ?? this.kind,
    title: title ?? this.title,
    providerName: providerName ?? this.providerName,
    amount: amount ?? this.amount,
    frequency: frequency ?? this.frequency,
    nextDueDate: nextDueDate ?? this.nextDueDate,
    customKindName: customKindName ?? this.customKindName,
    customFrequencyDays: customFrequencyDays ?? this.customFrequencyDays,
    subscriberNumber: subscriberNumber ?? this.subscriberNumber,
    contractNumber: contractNumber ?? this.contractNumber,
    description: description ?? this.description,
    isArchived: isArchived ?? this.isArchived,
    payments: payments ?? this.payments,
    notes: notes ?? this.notes,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'kind': kind.name,
    'title': title,
    'providerName': providerName,
    'amount': amount,
    'frequency': frequency.name,
    'nextDueDate': nextDueDate.toIso8601String(),
    'customKindName': customKindName,
    'customFrequencyDays': customFrequencyDays,
    'subscriberNumber': subscriberNumber,
    'contractNumber': contractNumber,
    'description': description,
    'isArchived': isArchived,
    'payments': payments.map((item) => item.toJson()).toList(),
    'notes': notes.map((item) => item.toJson()).toList(),
  };

  factory SubscriptionEntry.fromJson(Map<String, dynamic> json) {
    final kindName = _string(
      json['kind'],
      fallback: SubscriptionKind.custom.name,
    );
    final frequencyName = _string(
      json['frequency'],
      fallback: PaymentFrequency.monthly.name,
    );
    return SubscriptionEntry(
      id: _string(json['id']),
      kind: SubscriptionKind.values.firstWhere(
        (item) => item.name == kindName,
        orElse: () => SubscriptionKind.custom,
      ),
      title: _string(json['title']),
      providerName: _string(json['providerName']),
      amount: _safeAmount(json['amount'] as num?),
      frequency: PaymentFrequency.values.firstWhere(
        (item) => item.name == frequencyName,
        orElse: () => PaymentFrequency.monthly,
      ),
      nextDueDate: _date(json['nextDueDate']),
      customKindName: _string(json['customKindName']),
      customFrequencyDays: _intOrNull(json['customFrequencyDays']),
      subscriberNumber: _string(json['subscriberNumber']),
      contractNumber: _string(json['contractNumber']),
      description: _string(json['description']),
      isArchived: json['isArchived'] as bool? ?? false,
      payments: _paymentList(json['payments']),
      notes: _noteList(json['notes']),
    );
  }
}

class PersonAccount {
  const PersonAccount({
    required this.id,
    required this.name,
    this.banks = const [],
    this.personalDebts = const [],
    this.bills = const [],
    this.subscriptions = const [],
    this.rents = const [],
  });

  final String id;
  final String name;
  final List<BankGroup> banks;
  final List<PersonalDebtEntry> personalDebts;
  final List<BillEntry> bills;
  final List<SubscriptionEntry> subscriptions;
  final List<RentEntry> rents;

  double get totalDebt {
    final bankTotal = banks.fold<double>(
      0.0,
      (sum, bank) => sum + bank.totalDebt,
    );
    final personalTotal = personalDebts
        .where((debt) => !debt.isArchived)
        .fold<double>(0.0, (sum, debt) => sum + debt.remainingAmount);
    final billTotal = bills
        .where((bill) => !bill.isArchived)
        .fold<double>(0.0, (sum, bill) => sum + bill.remainingAmount);
    final subscriptionTotal = subscriptions
        .where((subscription) => !subscription.isArchived)
        .fold<double>(
          0.0,
          (sum, subscription) => sum + subscription.remainingAmount,
        );
    final rentTotal = rents
        .where((rent) => !rent.isArchived)
        .fold<double>(0.0, (sum, rent) => sum + rent.remainingAmount);
    return bankTotal +
        personalTotal +
        billTotal +
        subscriptionTotal +
        rentTotal;
  }

  double monthlyLoadFor(DateTime month) {
    final bankTotal = banks.fold<double>(
      0.0,
      (sum, bank) => sum + bank.monthlyLoadFor(month),
    );
    final personalTotal = personalDebts
        .where(
          (item) =>
              !item.isArchived &&
              item.remainingAmount > 0 &&
              item.isDueInMonth(month),
        )
        .fold<double>(0.0, (sum, item) => sum + item.effectiveDueAmount);
    final billTotal = bills
        .where(
          (bill) =>
              !bill.isArchived &&
              bill.remainingAmount > 0 &&
              bill.isDueInMonth(month),
        )
        .fold<double>(0.0, (sum, bill) => sum + bill.remainingAmount);
    final subscriptionTotal = subscriptions
        .where((item) => !item.isArchived && item.isDueInMonth(month))
        .fold<double>(0.0, (sum, item) => sum + item.amount);
    final rentTotal = rents
        .where(
          (rent) =>
              !rent.isArchived &&
              rent.remainingAmount > 0 &&
              rent.isDueInMonth(month),
        )
        .fold<double>(0.0, (sum, rent) => sum + rent.remainingAmount);
    return bankTotal +
        personalTotal +
        billTotal +
        subscriptionTotal +
        rentTotal;
  }

  int overdueCountAt(DateTime reference) {
    final debtCount = banks
        .expand((bank) => bank.products)
        .where(
          (product) => product.statusAt(reference) == PaymentStatus.overdue,
        )
        .length;
    final personalCount = personalDebts
        .where((item) => item.statusAt(reference) == PaymentStatus.overdue)
        .length;
    final billCount = bills
        .where((bill) => bill.statusAt(reference) == PaymentStatus.overdue)
        .length;
    final subscriptionCount = subscriptions
        .where((item) => item.statusAt(reference) == PaymentStatus.overdue)
        .length;
    final rentCount = rents
        .where((rent) => rent.statusAt(reference) == PaymentStatus.overdue)
        .length;
    return debtCount +
        personalCount +
        billCount +
        subscriptionCount +
        rentCount;
  }

  PersonAccount copyWith({
    String? name,
    List<BankGroup>? banks,
    List<PersonalDebtEntry>? personalDebts,
    List<BillEntry>? bills,
    List<SubscriptionEntry>? subscriptions,
    List<RentEntry>? rents,
  }) {
    return PersonAccount(
      id: id,
      name: name ?? this.name,
      banks: banks ?? this.banks,
      personalDebts: personalDebts ?? this.personalDebts,
      bills: bills ?? this.bills,
      subscriptions: subscriptions ?? this.subscriptions,
      rents: rents ?? this.rents,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'banks': banks.map((item) => item.toJson()).toList(),
    'personalDebts': personalDebts.map((item) => item.toJson()).toList(),
    'bills': bills.map((item) => item.toJson()).toList(),
    'subscriptions': subscriptions.map((item) => item.toJson()).toList(),
    'rents': rents.map((item) => item.toJson()).toList(),
  };

  factory PersonAccount.fromJson(Map<String, dynamic> json) {
    return PersonAccount(
      id: _string(json['id']),
      name: _string(json['name']),
      banks: ((json['banks'] as List?) ?? const [])
          .whereType<Map>()
          .map((item) => BankGroup.fromJson(Map<String, dynamic>.from(item)))
          .toList(growable: false),
      personalDebts: ((json['personalDebts'] as List?) ?? const [])
          .whereType<Map>()
          .map(
            (item) =>
                PersonalDebtEntry.fromJson(Map<String, dynamic>.from(item)),
          )
          .toList(growable: false),
      bills: ((json['bills'] as List?) ?? const [])
          .whereType<Map>()
          .map((item) => BillEntry.fromJson(Map<String, dynamic>.from(item)))
          .toList(growable: false),
      subscriptions: ((json['subscriptions'] as List?) ?? const [])
          .whereType<Map>()
          .map(
            (item) =>
                SubscriptionEntry.fromJson(Map<String, dynamic>.from(item)),
          )
          .toList(growable: false),
      rents: ((json['rents'] as List?) ?? const [])
          .whereType<Map>()
          .map((item) => RentEntry.fromJson(Map<String, dynamic>.from(item)))
          .toList(growable: false),
    );
  }
}

class ExpenseCategory {
  const ExpenseCategory({
    required this.id,
    required this.name,
    this.colorValue = 0xFF1F7A5A,
  });

  final String id;
  final String name;
  final int colorValue;

  ExpenseCategory copyWith({String? name, int? colorValue}) {
    return ExpenseCategory(
      id: id,
      name: name ?? this.name,
      colorValue: colorValue ?? this.colorValue,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'colorValue': colorValue,
  };

  factory ExpenseCategory.fromJson(Map<String, dynamic> json) {
    return ExpenseCategory(
      id: _string(json['id']),
      name: _string(json['name']),
      colorValue: _intOrNull(json['colorValue']) ?? 0xFF1F7A5A,
    );
  }
}

class ExpenseItem {
  const ExpenseItem({
    required this.id,
    required this.categoryId,
    required this.name,
    required this.quantity,
    required this.unitPrice,
    required this.spentAt,
    this.note = '',
  });

  final String id;
  final String categoryId;
  final String name;
  final double quantity;
  final double unitPrice;
  final DateTime spentAt;
  final String note;

  double get totalAmount =>
      double.parse((quantity * unitPrice).toStringAsFixed(2));

  ExpenseItem copyWith({
    String? categoryId,
    String? name,
    double? quantity,
    double? unitPrice,
    DateTime? spentAt,
    String? note,
  }) {
    return ExpenseItem(
      id: id,
      categoryId: categoryId ?? this.categoryId,
      name: name ?? this.name,
      quantity: quantity ?? this.quantity,
      unitPrice: unitPrice ?? this.unitPrice,
      spentAt: spentAt ?? this.spentAt,
      note: note ?? this.note,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'categoryId': categoryId,
    'name': name,
    'quantity': quantity,
    'unitPrice': unitPrice,
    'spentAt': spentAt.toIso8601String(),
    'note': note,
  };

  factory ExpenseItem.fromJson(Map<String, dynamic> json) {
    return ExpenseItem(
      id: _string(json['id']),
      categoryId: _string(json['categoryId']),
      name: _string(json['name']),
      quantity: (json['quantity'] as num?)?.toDouble() ?? 1,
      unitPrice: _safeAmount(json['unitPrice'] as num?),
      spentAt: _date(json['spentAt']),
      note: _string(json['note']),
    );
  }
}

class NotificationSlot {
  const NotificationSlot({
    required this.id,
    required this.label,
    required this.hour,
    required this.minute,
    required this.message,
    this.enabled = true,
  });

  final String id;
  final String label;
  final int hour;
  final int minute;
  final String message;
  final bool enabled;

  NotificationSlot copyWith({
    int? hour,
    int? minute,
    String? message,
    bool? enabled,
  }) {
    return NotificationSlot(
      id: id,
      label: label,
      hour: hour ?? this.hour,
      minute: minute ?? this.minute,
      message: message ?? this.message,
      enabled: enabled ?? this.enabled,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'label': label,
    'hour': hour,
    'minute': minute,
    'message': message,
    'enabled': enabled,
  };

  factory NotificationSlot.fromJson(Map<String, dynamic> json) {
    return NotificationSlot(
      id: _string(json['id']),
      label: _string(json['label']),
      hour: (_intOrNull(json['hour']) ?? 7).clamp(0, 23).toInt(),
      minute: (_intOrNull(json['minute']) ?? 0).clamp(0, 59).toInt(),
      message: _string(json['message']),
      enabled: json['enabled'] as bool? ?? true,
    );
  }
}

class RecordReference {
  const RecordReference({
    required this.type,
    required this.personId,
    required this.sourceId,
    this.bankId,
    required this.title,
    required this.subtitle,
    required this.amount,
    required this.dueDate,
    required this.status,
  });

  final RecordType type;
  final String personId;
  final String sourceId;
  final String? bankId;
  final String title;
  final String subtitle;
  final double amount;
  final DateTime dueDate;
  final PaymentStatus status;
}

class MizanState {
  const MizanState({
    required this.people,
    required this.expenseCategories,
    required this.expenses,
    required this.notificationSlots,
    this.notificationsEnabled = true,
    this.schemaVersion = currentSchemaVersion,
  });

  final int schemaVersion;
  final List<PersonAccount> people;
  final List<ExpenseCategory> expenseCategories;
  final List<ExpenseItem> expenses;
  final List<NotificationSlot> notificationSlots;
  final bool notificationsEnabled;

  double get totalDebt =>
      people.fold<double>(0.0, (sum, person) => sum + person.totalDebt);

  double get bankDebtTotal => allDebtProducts
      .where((item) => !item.isArchived)
      .fold<double>(0.0, (sum, item) => sum + item.remainingAmount);

  double get personalCorporateDebtTotal => allPersonalDebts
      .where((item) => !item.isArchived)
      .fold<double>(0.0, (sum, item) => sum + item.remainingAmount);

  double get billTotal => allBills
      .where((item) => !item.isArchived)
      .fold<double>(0.0, (sum, item) => sum + item.remainingAmount);

  double get subscriptionTotal => allSubscriptions
      .where((item) => !item.isArchived)
      .fold<double>(0.0, (sum, item) => sum + item.remainingAmount);

  double get rentInstallmentTotal => allRents
      .where((item) => !item.isArchived)
      .fold<double>(0.0, (sum, item) => sum + item.remainingAmount);

  double overdueTotalAt(DateTime reference) => recordReferencesAt(reference)
      .where((item) => item.status == PaymentStatus.overdue)
      .fold<double>(0.0, (sum, item) => sum + item.amount);

  double dueWithinDaysTotal(DateTime reference, int days) {
    final end = _dateOnly(reference).add(Duration(days: days));
    return recordReferencesAt(reference)
        .where(
          (item) =>
              item.amount > 0 &&
              item.status != PaymentStatus.completed &&
              item.status != PaymentStatus.passive &&
              !_dateOnly(item.dueDate).isBefore(_dateOnly(reference)) &&
              !_dateOnly(item.dueDate).isAfter(end),
        )
        .fold<double>(0.0, (sum, item) => sum + item.amount);
  }

  double monthlyDebtLoadFor(DateTime month) => people.fold<double>(
    0.0,
    (sum, person) => sum + person.monthlyLoadFor(month),
  );

  Map<RecordType, double> actualPaymentTotals({
    DateTime? month,
    String? personId,
  }) {
    final totals = <RecordType, double>{
      for (final type in RecordType.values) type: 0,
    };
    bool included(PaymentRecord payment) =>
        month == null ||
        (payment.paidAt.year == month.year &&
            payment.paidAt.month == month.month);
    for (final person in people) {
      if (personId != null && person.id != personId) continue;
      for (final bank in person.banks) {
        for (final debt in bank.products) {
          totals[RecordType.debt] =
              (totals[RecordType.debt] ?? 0) +
              debt.payments
                  .where(included)
                  .fold<double>(0.0, (sum, item) => sum + item.amount);
        }
      }
      for (final debt in person.personalDebts) {
        totals[RecordType.personalDebt] =
            (totals[RecordType.personalDebt] ?? 0) +
            debt.payments
                .where(included)
                .fold<double>(0.0, (sum, item) => sum + item.amount);
      }
      for (final bill in person.bills) {
        totals[RecordType.bill] =
            (totals[RecordType.bill] ?? 0) +
            bill.payments
                .where(included)
                .fold<double>(0.0, (sum, item) => sum + item.amount);
      }
      for (final subscription in person.subscriptions) {
        totals[RecordType.subscription] =
            (totals[RecordType.subscription] ?? 0) +
            subscription.payments
                .where(included)
                .fold<double>(0.0, (sum, item) => sum + item.amount);
      }
      for (final rent in person.rents) {
        totals[RecordType.rent] =
            (totals[RecordType.rent] ?? 0) +
            rent.payments
                .where(included)
                .fold<double>(0.0, (sum, item) => sum + item.amount);
      }
    }
    return totals;
  }

  double actualPaymentTotal({DateTime? month, String? personId}) =>
      actualPaymentTotals(
        month: month,
        personId: personId,
      ).values.fold<double>(0.0, (sum, item) => sum + item);

  double expenseTotalForDay(DateTime day) => expenses
      .where(
        (item) =>
            item.spentAt.year == day.year &&
            item.spentAt.month == day.month &&
            item.spentAt.day == day.day,
      )
      .fold<double>(0.0, (sum, item) => sum + item.totalAmount);

  double expenseTotalForMonth(DateTime month) => expenses
      .where(
        (item) =>
            item.spentAt.year == month.year &&
            item.spentAt.month == month.month,
      )
      .fold<double>(0.0, (sum, item) => sum + item.totalAmount);

  double expenseTotalForRange(DateTime start, DateTime endInclusive) => expenses
      .where((item) {
        final day = _dateOnly(item.spentAt);
        return !day.isBefore(_dateOnly(start)) &&
            !day.isAfter(_dateOnly(endInclusive));
      })
      .fold<double>(0.0, (sum, item) => sum + item.totalAmount);

  List<DebtProduct> get allDebtProducts => people
      .expand((person) => person.banks)
      .expand((bank) => bank.products)
      .toList(growable: false);

  List<PersonalDebtEntry> get allPersonalDebts =>
      people.expand((person) => person.personalDebts).toList(growable: false);

  List<BillEntry> get allBills =>
      people.expand((person) => person.bills).toList(growable: false);

  List<SubscriptionEntry> get allSubscriptions =>
      people.expand((person) => person.subscriptions).toList(growable: false);

  List<RentEntry> get allRents =>
      people.expand((person) => person.rents).toList(growable: false);

  List<RecordReference> recordReferencesAt(DateTime reference) {
    final items = <RecordReference>[];
    for (final person in people) {
      for (final bank in person.banks) {
        for (final product in bank.products) {
          items.add(
            RecordReference(
              type: RecordType.debt,
              personId: person.id,
              sourceId: product.id,
              bankId: bank.id,
              title: product.title,
              subtitle:
                  '${person.name} · ${bank.userWrittenName} · ${product.displayKind}',
              amount: product.dueAmountAt(reference),
              dueDate: product.effectiveDueDateAt(reference),
              status: product.statusAt(reference),
            ),
          );
        }
      }
      for (final debt in person.personalDebts) {
        items.add(
          RecordReference(
            type: RecordType.personalDebt,
            personId: person.id,
            sourceId: debt.id,
            title: debt.title,
            subtitle:
                '${person.name} · ${debt.creditorType.label} · ${debt.displayCreditor}',
            amount: debt.effectiveDueAmount,
            dueDate: debt.effectiveDueDate,
            status: debt.statusAt(reference),
          ),
        );
      }
      for (final bill in person.bills) {
        items.add(
          RecordReference(
            type: RecordType.bill,
            personId: person.id,
            sourceId: bill.id,
            title: bill.kind.label,
            subtitle: '${person.name} · ${bill.institutionName}',
            amount: bill.remainingAmount,
            dueDate: bill.dueDate,
            status: bill.statusAt(reference),
          ),
        );
      }
      for (final subscription in person.subscriptions) {
        items.add(
          RecordReference(
            type: RecordType.subscription,
            personId: person.id,
            sourceId: subscription.id,
            title: subscription.title,
            subtitle: '${person.name} · ${subscription.providerName}',
            amount: subscription.remainingAmount,
            dueDate: subscription.nextDueDate,
            status: subscription.statusAt(reference),
          ),
        );
      }
      for (final rent in person.rents) {
        items.add(
          RecordReference(
            type: RecordType.rent,
            personId: person.id,
            sourceId: rent.id,
            title: rent.title,
            subtitle: '${person.name} · ${rent.receiverName}',
            amount: rent.remainingAmount,
            dueDate: rent.dueDate,
            status: rent.statusAt(reference),
          ),
        );
      }
    }
    return items;
  }

  double expenseTotalForCategory(
    String categoryId, {
    Iterable<ExpenseItem>? source,
  }) {
    return (source ?? expenses)
        .where((item) => item.categoryId == categoryId)
        .fold<double>(0.0, (sum, item) => sum + item.totalAmount);
  }

  List<ExpenseItem> expensesForCategory(String categoryId) {
    final result = expenses
        .where((item) => item.categoryId == categoryId)
        .toList(growable: false);
    return result..sort((a, b) => b.spentAt.compareTo(a.spentAt));
  }

  MizanState copyWith({
    List<PersonAccount>? people,
    List<ExpenseCategory>? expenseCategories,
    List<ExpenseItem>? expenses,
    List<NotificationSlot>? notificationSlots,
    bool? notificationsEnabled,
    int? schemaVersion,
  }) {
    return MizanState(
      people: people ?? this.people,
      expenseCategories: expenseCategories ?? this.expenseCategories,
      expenses: expenses ?? this.expenses,
      notificationSlots: notificationSlots ?? this.notificationSlots,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      schemaVersion: schemaVersion ?? this.schemaVersion,
    );
  }

  Map<String, dynamic> toJson() => {
    'schemaVersion': schemaVersion,
    'people': people.map((item) => item.toJson()).toList(),
    'expenseCategories': expenseCategories
        .map((item) => item.toJson())
        .toList(),
    'expenses': expenses.map((item) => item.toJson()).toList(),
    'notificationSlots': notificationSlots
        .map((item) => item.toJson())
        .toList(),
    'notificationsEnabled': notificationsEnabled,
  };

  factory MizanState.fromJson(Map<String, dynamic> json) {
    final slots = ((json['notificationSlots'] as List?) ?? const [])
        .whereType<Map>()
        .map(
          (item) => NotificationSlot.fromJson(Map<String, dynamic>.from(item)),
        )
        .toList(growable: false);
    return MizanState(
      schemaVersion: _intOrNull(json['schemaVersion']) ?? 1,
      people: ((json['people'] as List?) ?? const [])
          .whereType<Map>()
          .map(
            (item) => PersonAccount.fromJson(Map<String, dynamic>.from(item)),
          )
          .toList(growable: false),
      expenseCategories: ((json['expenseCategories'] as List?) ?? const [])
          .whereType<Map>()
          .map(
            (item) => ExpenseCategory.fromJson(Map<String, dynamic>.from(item)),
          )
          .toList(growable: false),
      expenses: ((json['expenses'] as List?) ?? const [])
          .whereType<Map>()
          .map((item) => ExpenseItem.fromJson(Map<String, dynamic>.from(item)))
          .toList(growable: false),
      notificationSlots: slots.isEmpty ? defaultNotificationSlots : slots,
      notificationsEnabled: json['notificationsEnabled'] as bool? ?? true,
    ).copyWith(schemaVersion: currentSchemaVersion);
  }

  factory MizanState.empty() => const MizanState(
    people: [],
    expenseCategories: [],
    expenses: [],
    notificationSlots: defaultNotificationSlots,
  );

  factory MizanState.seed() => MizanState.empty();
}

const List<NotificationSlot> defaultNotificationSlots = [
  NotificationSlot(
    id: 'morning',
    label: 'Sabah gider',
    hour: 7,
    minute: 0,
    message: 'Bugünkü giderlerini işlemeyi unutma.',
  ),
  NotificationSlot(
    id: 'noon',
    label: 'Öğlen gider',
    hour: 12,
    minute: 0,
    message: 'Öğlene kadar yaptığın harcamaları ekleyebilirsin.',
  ),
  NotificationSlot(
    id: 'evening',
    label: 'Akşam gider',
    hour: 21,
    minute: 0,
    message: 'Günü kapatmadan giderlerini kontrol et.',
  ),
];

List<PaymentRecord> _paymentList(dynamic value) =>
    ((value as List?) ?? const [])
        .whereType<Map>()
        .map((item) => PaymentRecord.fromJson(Map<String, dynamic>.from(item)))
        .toList(growable: false);

List<RecordNote> _noteList(dynamic value) => ((value as List?) ?? const [])
    .whereType<Map>()
    .map((item) => RecordNote.fromJson(Map<String, dynamic>.from(item)))
    .toList(growable: false);
